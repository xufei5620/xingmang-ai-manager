[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
param(
    [string]$InstallRoot = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter',
    [string]$BackupConfig = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\backups\20260812-060734\config.toml'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$liveConfig = 'C:\Users\<USER>\.codex\config.toml'
$expectedRoot = [IO.Path]::GetFullPath('C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter')
$resolvedRoot = [IO.Path]::GetFullPath($InstallRoot)
$resolvedBackup = [IO.Path]::GetFullPath($BackupConfig)
if ($resolvedRoot -ne $expectedRoot -or
    -not $resolvedBackup.StartsWith((Join-Path $expectedRoot 'backups') + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Rollback paths are outside the expected CodexDualRouter installation.'
}
if (-not (Test-Path -LiteralPath $resolvedBackup -PathType Leaf)) {
    throw "Backup config not found: $resolvedBackup"
}

if (-not $PSCmdlet.ShouldProcess($liveConfig, 'Stop router, remove autostart, and restore backed-up Codex config')) {
    return
}

& (Join-Path $InstallRoot 'stop-router.ps1') -InstallRoot $InstallRoot
Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'CodexDualRouter' -ErrorAction SilentlyContinue

$preRollback = Join-Path $InstallRoot ('backups\pre-rollback-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $preRollback -Force | Out-Null
Copy-Item -LiteralPath $liveConfig -Destination (Join-Path $preRollback 'config.toml')
Copy-Item -LiteralPath $resolvedBackup -Destination $liveConfig -Force

if ((Get-FileHash -Algorithm SHA256 -LiteralPath $resolvedBackup).Hash -ne
    (Get-FileHash -Algorithm SHA256 -LiteralPath $liveConfig).Hash) {
    throw 'Restored config hash does not match the backup.'
}

Write-Output 'Original Codex configuration restored. Restart the desktop app to return to the direct subscription route.'
