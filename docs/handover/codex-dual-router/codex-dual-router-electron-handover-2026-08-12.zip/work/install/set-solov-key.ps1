[CmdletBinding()]
param(
    [string]$InstallRoot = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter',
    [switch]$SkipRestart
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$secretDirectory = Join-Path $InstallRoot 'secrets'
$secretPath = Join-Path $secretDirectory 'solov.dpapi'
$secureSecret = Read-Host '请粘贴已轮换的新 Solov API 密钥（输入不会显示）' -AsSecureString
$secretPointer = [IntPtr]::Zero
$plainSecret = $null

try {
    $secretPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureSecret)
    $plainSecret = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($secretPointer)
    if ([string]::IsNullOrWhiteSpace($plainSecret) -or $plainSecret.Length -lt 20) {
        throw '密钥为空或长度异常，未保存。'
    }

    New-Item -ItemType Directory -Path $secretDirectory -Force | Out-Null
    $encrypted = ConvertFrom-SecureString $secureSecret
    [IO.File]::WriteAllText($secretPath, $encrypted, [Text.UTF8Encoding]::new($false))

    $identity = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    & icacls.exe $secretPath /inheritance:r /grant:r "${identity}:(F)" 'SYSTEM:(F)' | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw '密钥已加密，但无法收紧文件权限。'
    }
}
finally {
    $plainSecret = $null
    if ($secretPointer -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secretPointer)
    }
}

if (-not $SkipRestart) {
    & (Join-Path $InstallRoot 'stop-router.ps1') -InstallRoot $InstallRoot
    & (Join-Path $InstallRoot 'start-router.ps1') -InstallRoot $InstallRoot
}

Write-Output 'Solov 密钥已使用 Windows DPAPI 加密保存；明文未写入配置或日志。'
