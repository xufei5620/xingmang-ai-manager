[CmdletBinding()]
param(
    [string]$InstallRoot = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter',
    [int]$Port = 43120
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$routerEntry = Join-Path $InstallRoot 'router\src\main.mjs'
$catalogPath = Join-Path $InstallRoot 'models.json'
$secretPath = Join-Path $InstallRoot 'secrets\solov.dpapi'
$runDirectory = Join-Path $InstallRoot 'run'
$logDirectory = Join-Path $InstallRoot 'logs'
$pidPath = Join-Path $runDirectory 'router.pid'
$stdoutPath = Join-Path $logDirectory 'router.stdout.log'
$stderrPath = Join-Path $logDirectory 'router.stderr.log'

function Test-RouterHealth {
    try {
        $health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -Method Get -TimeoutSec 2
        return $health.status -eq 'ok'
    }
    catch {
        return $false
    }
}

function Get-LoopbackHttpsProxy {
    $settings = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction SilentlyContinue
    if ($null -eq $settings -or $settings.ProxyEnable -ne 1 -or [string]::IsNullOrWhiteSpace([string]$settings.ProxyServer)) {
        return $null
    }

    $rawProxy = ([string]$settings.ProxyServer).Trim()
    $candidate = $rawProxy
    if ($rawProxy.Contains(';') -or $rawProxy.Contains('=')) {
        $entries = @{}
        foreach ($entry in $rawProxy.Split(';', [StringSplitOptions]::RemoveEmptyEntries)) {
            $parts = $entry.Split('=', 2)
            if ($parts.Count -eq 2) {
                $entries[$parts[0].Trim().ToLowerInvariant()] = $parts[1].Trim()
            }
        }
        if ($entries.ContainsKey('https')) {
            $candidate = $entries['https']
        }
        elseif ($entries.ContainsKey('http')) {
            $candidate = $entries['http']
        }
        else {
            return $null
        }
    }

    if (-not $candidate.Contains('://')) {
        $candidate = 'http://' + $candidate
    }
    $proxyUri = $null
    if (-not [Uri]::TryCreate($candidate, [UriKind]::Absolute, [ref]$proxyUri) -or
        $proxyUri.Scheme -ne 'http' -or
        $proxyUri.Host -ne '127.0.0.1' -or
        $proxyUri.Port -lt 1 -or $proxyUri.Port -gt 65535 -or
        -not [string]::IsNullOrEmpty($proxyUri.UserInfo) -or
        $proxyUri.AbsolutePath -ne '/' -or
        -not [string]::IsNullOrEmpty($proxyUri.Query) -or
        -not [string]::IsNullOrEmpty($proxyUri.Fragment)) {
        throw 'The enabled Windows HTTPS proxy is not a plain 127.0.0.1 HTTP proxy.'
    }
    return "http://127.0.0.1:$($proxyUri.Port)"
}

function Get-ValidatedRouterProcess {
    if (-not (Test-Path -LiteralPath $pidPath -PathType Leaf)) {
        return $null
    }

    $storedPid = 0
    if (-not [int]::TryParse(([IO.File]::ReadAllText($pidPath)).Trim(), [ref]$storedPid)) {
        return $null
    }

    $process = Get-CimInstance Win32_Process -Filter "ProcessId = $storedPid" -ErrorAction SilentlyContinue
    if ($null -eq $process -or $process.Name -ne 'node.exe') {
        return $null
    }

    $expectedFragment = [IO.Path]::GetFullPath($routerEntry)
    if ([string]::IsNullOrWhiteSpace($process.CommandLine) -or
        $process.CommandLine.IndexOf($expectedFragment, [StringComparison]::OrdinalIgnoreCase) -lt 0) {
        return $null
    }
    return $process
}

if (Test-RouterHealth) {
    Write-Output "Codex dual router is already healthy on 127.0.0.1:$Port."
    exit 0
}

$existingProcess = Get-ValidatedRouterProcess
if ($null -ne $existingProcess) {
    Stop-Process -Id $existingProcess.ProcessId -Force
    Start-Sleep -Milliseconds 300
}

if (-not (Test-Path -LiteralPath $routerEntry -PathType Leaf)) {
    throw "Router entry point not found: $routerEntry"
}
if (-not (Test-Path -LiteralPath $catalogPath -PathType Leaf)) {
    throw "Model catalog not found: $catalogPath"
}

$nodeCommand = Get-Command node.exe -ErrorAction Stop
$nodePath = $nodeCommand.Source
if ([version](& $nodePath --version).TrimStart('v') -lt [version]'24.0.0') {
    throw 'Node.js 24 or newer is required for native zstd support.'
}

New-Item -ItemType Directory -Path $runDirectory -Force | Out-Null
New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null

$plainSecret = $null
$secretPointer = [IntPtr]::Zero
try {
    if (Test-Path -LiteralPath $secretPath -PathType Leaf) {
        $encrypted = [IO.File]::ReadAllText($secretPath).Trim()
        if (-not [string]::IsNullOrWhiteSpace($encrypted)) {
            $secureSecret = ConvertTo-SecureString $encrypted
            $secretPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureSecret)
            $plainSecret = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($secretPointer)
            $env:SOLOV_API_KEY = $plainSecret
        }
    }

    $env:DUAL_ROUTER_PORT = [string]$Port
    $env:DUAL_ROUTER_CATALOG = $catalogPath
    $loopbackProxy = Get-LoopbackHttpsProxy
    if ($null -ne $loopbackProxy) {
        $env:DUAL_ROUTER_HTTPS_PROXY = $loopbackProxy
    }
    $routerProcess = Start-Process -FilePath $nodePath `
        -ArgumentList @($routerEntry) `
        -WorkingDirectory (Join-Path $InstallRoot 'router') `
        -WindowStyle Hidden `
        -RedirectStandardOutput $stdoutPath `
        -RedirectStandardError $stderrPath `
        -PassThru
    [IO.File]::WriteAllText($pidPath, [string]$routerProcess.Id, [Text.UTF8Encoding]::new($false))
}
finally {
    Remove-Item Env:SOLOV_API_KEY -ErrorAction SilentlyContinue
    Remove-Item Env:DUAL_ROUTER_PORT -ErrorAction SilentlyContinue
    Remove-Item Env:DUAL_ROUTER_CATALOG -ErrorAction SilentlyContinue
    Remove-Item Env:DUAL_ROUTER_HTTPS_PROXY -ErrorAction SilentlyContinue
    $plainSecret = $null
    if ($secretPointer -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secretPointer)
    }
}

$healthy = $false
for ($attempt = 0; $attempt -lt 20; $attempt++) {
    Start-Sleep -Milliseconds 250
    if (Test-RouterHealth) {
        $healthy = $true
        break
    }
}

if (-not $healthy) {
    $validatedProcess = Get-ValidatedRouterProcess
    if ($null -ne $validatedProcess) {
        Stop-Process -Id $validatedProcess.ProcessId -Force
    }
    throw "Router did not become healthy on 127.0.0.1:$Port. See $stderrPath"
}

Write-Output "Codex dual router started on 127.0.0.1:$Port."
