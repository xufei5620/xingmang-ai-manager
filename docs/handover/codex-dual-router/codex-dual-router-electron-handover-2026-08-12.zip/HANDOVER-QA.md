# CodexDualRouter Electron 移植事实问答

生成日期：2026-08-12  
证据快照：本机工作区、正式路由结构化日志、部署备份、合成回环测试与官方 OpenAI 文档。  
边界：本次只做只读核对与独立交付副本导出；没有修改源工作区、正式安装、运行进程、用户配置或认证状态，也没有发出真实付费请求。

## 先读：证据等级

- **本轮实测**：本次在回环伪上游、合成身份和临时目录中重跑。
- **历史真实证据**：已有文件记录了真实上游结果；本轮没有联网复验。
- **源码可证**：可由当前实现直接确定，但没有做破坏性或外部状态演练。
- **未观察 / 未验证**：没有足够事实，不作推断。

本交付包使用 `C:\Users\<USER>` 作为所有 Windows 用户目录占位符。测试中的 token、account、session、thread、API key 和 prompt 均已替换为显式占位符或删除。

---

## 最关键的三条

## Q1. 白名单外，桌面端与 CLI 还会请求哪些路径？被拒后怎样？

### 实际观察到的路径快照

当前正式路由日志窗口中实际出现的 pathname 只有：

| 方法与路径 | 次数 | 结果 |
| --- | ---: | --- |
| `GET /models` | 154 | 115 次 `200 completed`；39 次 `502 upstream_unavailable` |
| `POST /responses` | 200 | 178 次 `200 completed`；21 次 `200 upstream_error`；1 次 `502 upstream_error` |
| `GET /responses` | 16 | 2 次 `404 unknown_path`；14 次 `426 websocket_not_supported` |
| `POST /alpha/search` | 4 | 全部 `404 unknown_path` |
| `GET /favicon.ico` | 2 | 全部 `404 unknown_path` |

另有 1 条畸形 HTTP 记录为 `400 malformed_http`。`/health` 成功分支不写访问日志，因此日志里没有它不能证明它未被调用。

白名单外的实际观察：

- `POST /alpha/search`：4 次，均被拒绝。本次 OpenAI 官方文档搜索工具在当前环境中也实际收到了 `404 unknown_path` 并显式失败；但日志不记录 User-Agent，不能证明历史 4 次来自桌面端还是 CLI。
- `GET /favicon.ico`：2 次，均被拒绝；更像浏览器打开本机 URL 后的图标请求，但来源**未验证**。
- `GET /responses` 普通请求：2 次 `404`。
- WebSocket Upgrade `/responses`：14 次 `426`，随后日志中存在 HTTP `POST /responses` 成功。当前实现要求客户端改用 HTTP streaming；“WebSocket 探测失败后能够走 HTTP/SSE”有运行日志和合成测试证据。

当前日志中**未观察**到 login、token refresh、account、任务/会话列表、遥测或限额查询路径。因此不能提供“Codex 桌面端和 CLI 的完整路径全集”。

以下具体客户端表现**未验证**：

- 桌面端或 CLI 对 `/alpha/search` 被拒后的 UI/功能表现；
- 普通 `GET /responses` 与 `/favicon.ico` 被拒后的表现；
- 被拒路径属于桌面端、bundled CLI、独立 CLI 或其他本机工具的准确归因。

证据：`work/router/src/config.mjs`、`work/router/src/router.mjs:1945-2235`；正式日志只用于本次路径聚合，原日志未进入交付包。

## Q2. ChatGPT token 刷新是否经过路由？会掉登录吗？

- **token 刷新是否经过本机路由：未观察。**
- **token 过期后当前桌面端是否自动续期：没有在本机经历可确认的到期周期；本机实测未验证。**
- [官方 OpenAI 认证文档](https://learn.chatgpt.com/docs/auth)说明，ChatGPT 登录会在使用中于过期前自动刷新 token，活跃会话通常不需要再次打开浏览器登录；这是产品文档事实，不是本路由实测结论。
- 路由器只验证并转发客户端已经提供的 `Bearer` 或 `AgentAssertion`。它不签发、不刷新、不持久化 ChatGPT token。
- 当前日志窗口内官方 `/models` 与 `/responses` 有大量成功，未观察到官方 401/403；部署与记录只覆盖同一天，**不足以证明**长期自动续期。
- 部署至今是否发生过掉登录：现有材料中**未观察到**，但没有跨 token 生命周期的证明。

### 客户端完全未登录时

源码可确定：

- `/health` 仍返回健康状态，不要求身份。
- `GET /models` 及所有业务 `POST` 在本机先要求 `Authorization` 符合 `Bearer <value>` 或 `AgentAssertion <value>`。
- 未携带有效形状的认证头时，本机返回 HTTP `401`：

```json
{
  "error": {
    "code": "missing_local_auth",
    "message": "ChatGPT/OpenAI authentication is required by the local router."
  }
}
```

- 该请求不会触达 OpenAI 或第三方上游；单元测试覆盖了这一点。

桌面客户端在未登录状态下显示登录页、错误气泡还是禁用模型菜单：**未实际登出验证**。终端 CLI 的具体交互提示也**未验证**。官方文档给出的产品路径是通过 ChatGPT 登录或 API key 登录；本路由不会替代登录。

证据：`work/router/src/router.mjs:369-380,1952-1961,2021-2029`；`work/router/test/router.test.mjs` 的 unauthenticated case。

## Q3. `openai_base_url` 对终端 Codex CLI 是否同样生效？

部分已验证，不能写成完全未测试：

- 桌面包 bundled `codex.exe exec` 已实际接受 `--config openai_base_url=...`。
- 已验证版本：`codex-cli 0.147.0-alpha.6.6`。
- 官方 `gpt-5.4-mini` 经本机路由取得过真实成功响应。
- `solov::gpt-5.4-mini` 被 CLI 接受并正确进入第三方路由；当次真实上游因额度返回 403。因此“CLI 能通过第三方路由获得成功文字输出”在当前部署状态下**未验证**。
- app-server `model/list` 已验证 11 个第三方条目可见，但这不等同于终端交互式 CLI 的下拉菜单。

未验证：

- 终端交互式 CLI 是否列出全部 `solov::` 模型；
- 系统 PATH 中独立安装的 CLI；
- 不传 `--config`、只依赖用户全局 `config.toml` 的独立 CLI 实测。现有验证器使用 `--ignore-user-config` 后显式注入相同配置；
- 当前额度状态下获得成功的第三方文字输出。

证据：`work/install/validate-live-responses.ps1`、`work/install/validate-live-picker.ps1`、`outputs/Codex双路由使用与恢复说明.md`。

---

## 运行时与依赖

## Q4. 是否有 npm 运行时依赖？

没有。`package.json` 没有 `dependencies` 或 `devDependencies`，也不存在 `package-lock.json`。路由只使用 Node 内置模块：`node:http`、`node:https`、`node:tls`、`node:net`、`node:fs`、`node:path`、`node:url`、`node:crypto`、`node:zlib`、`node:util` 等。

## Q5. Node 24+ 是硬要求吗？Node 22 能否运行？

对**当前提供的启动脚本和 package 契约**是硬门槛：

- `package.json` 声明 `node >=24.0.0`；
- `start-router.ps1` 会拒绝低于 24 的版本；
- 当前实测环境为 Node `24.13.0`。

使用的关键新 API：

- `node:zlib.zstdDecompress`：解码 Codex 图片路由收到的 zstd Responses 请求；
- `node:zlib.crc32`：校验 PNG chunk CRC；
- 单测另使用 `zstdCompress`。

zstd 不是 npm/WASM/外部可执行文件，而是 Node 内置 `node:zlib` 实现。

Node 22：**未运行验证**。在没有同时提供这两个 API 的 Node 22 小版本上会在模块导入阶段失败；本项目没有兼容分支或 polyfill。移植方不应在未实测前降低门槛。

## Q6. 43120 被占用时怎样？是否自协商或互斥？

- 默认端口固定为 `43120`；环境变量可显式给出另一个单一端口。
- 没有自动端口协商；`server.listen()` 出现 `EADDRINUSE` 时启动失败退出。
- 没有 OS mutex 或独占锁文件。现有多实例保护主要是 PID 文件与命令行归属核验。
- `start-router.ps1` 会先请求 `/health`。如果端口上的任意服务返回精确 `{status:"ok"}`，脚本会直接认为路由已经健康；该早退分支未先验证 PID/命令行，存在误认风险。
- 健康检查不通过时，只会停止 PID 文件指向且命令行核实属于本路由的旧进程，然后仍在同一端口启动；约 5 秒不健康即报错，不换端口。

第三方程序真实占用 43120 的端到端演练：**未验证**。

## Q7. 官方 `/models` 的认证如何转发？

直接从客户端入站请求中按 allowlist 复制：

- `Authorization: Bearer ...` 或 `Authorization: AgentAssertion ...` 原样转发；
- 允许的 ChatGPT/Codex 一方身份头也按白名单转发；
- 覆盖 `Host`，强制 `Accept: application/json`、`Accept-Encoding: identity`，并重算连接相关头；
- 不使用第三方 key，也没有单独的服务端 OpenAI token。

如果客户端根本没有认证头，本机在发起官方 `/models` 之前返回 `401 missing_local_auth`。

证据：`work/router/src/router.mjs:55-71,231-276,369-380,1958-1973`。

---

## 配置契约

## Q8. 实施前后 `config.toml` 完整 diff；已有自定义配置如何处理？

对 2026-08-12 初次实施前备份与当前配置做了逐行脱敏比较。完整差异只有下列三组，其余原配置行保持：

```diff
-model = "gpt-5.6-sol"
+model = "solov::gpt-5.6-terra"

 model_provider = "openai"
+openai_base_url = "http://127.0.0.1:43120"

+[projects.'c:\users\<USER>\documents\codex\2026-08-12\ni-shi']
+trust_level = "trusted"
```

说明：

- 第三处项目 trust stanza 与路由本身没有必然关系；现有证据不能证明由哪一步加入。
- 当前 `apply-image-picker.ps1` **不修改** `config.toml`，它要求现有配置已满足 `model_provider="openai"` 和固定回环 `openai_base_url`，然后对完整配置 length+SHA-256 做 CAS。配置不符合或部署期间漂移就拒绝。
- 当前图片选择器部署不会覆盖或合并用户的 provider、MCP、审批策略等其他设置；它保持整个文件不变并以哈希保护。
- 最初把 `openai_base_url` 加入现有配置的初始实施器不在当前交付材料中。因此对任意用户已有复杂配置的**通用初次安装策略未验证**，不能宣称总是自动合并。
- 历史 `apply-catalog-expansion.ps1` 会读写配置，但不是当前最终图片选择器部署入口。

注意：diff 中的默认 `model` 改动不是双路由成立的必要条件；移植方不应照抄为产品默认值。

## Q9. 路由未运行时客户端怎样？有自动直连回退吗？

- 桌面端具体错误文字和 UI：**未验证**。本次禁止停路由，没有做故障注入。
- 终端 CLI 具体错误文字：**未验证**。
- 配置将 `openai_base_url` 固定为回环地址，源码未发现连接失败后自动改回官方直连的机制；进程已挂时本机路由也无法执行回退。
- HKCU 登录启动项只在 Windows 用户登录时调用启动脚本；没有 watchdog、Windows Service recovery 或崩溃自动重启。
- 回官方直连需要操作者显式运行 `rollback.ps1` 恢复实施前配置并重启客户端。这不是运行时自动回退。

---

## 目录与模型

## Q10. `models.json` 的 schema 与字段来源

顶层 schema：

```json
{
  "models": [ /* ModelInfo objects */ ]
}
```

当前每个模型对象包含 41 个字段：

```text
slug, prefer_websockets, support_verbosity, default_verbosity,
apply_patch_tool_type, web_search_tool_type, input_modalities,
supports_image_detail_original, truncation_policy,
supports_parallel_tool_calls, tool_mode, multi_agent_version,
use_responses_lite, include_skills_usage_instructions,
include_plugin_usage_instructions, auto_review_model_override,
context_window, max_context_window, auto_compact_token_limit,
comp_hash, reasoning_summary_format, default_reasoning_summary,
display_name, description, default_reasoning_level,
supported_reasoning_levels, shell_type, visibility,
minimal_client_version, supported_in_api, availability_nux, upgrade,
priority, model_messages, experimental_supported_tools,
available_in_plans, supports_search_tool, default_service_tier,
service_tiers, additional_speed_tiers, supports_reasoning_summaries
```

当前 11 个本地条目的完整结构类型如下。带 `null` 的字段表示当前目录中至少有一个条目使用 `null`；数组元素均为同一列出的结构。字符串内容（尤其 `model_messages` 下的 bundled 指令模板）在交付副本中已统一脱敏，不改变键和类型：

```text
slug: string
prefer_websockets: boolean
support_verbosity: boolean
default_verbosity: string
apply_patch_tool_type: string
web_search_tool_type: string
input_modalities: string[]
supports_image_detail_original: boolean
truncation_policy: { mode: string, limit: number }
supports_parallel_tool_calls: boolean
tool_mode: string | null
multi_agent_version: string | null
use_responses_lite: boolean
include_skills_usage_instructions: boolean
include_plugin_usage_instructions: boolean
auto_review_model_override: null
context_window: number
max_context_window: number
auto_compact_token_limit: null
comp_hash: string | null
reasoning_summary_format: string
default_reasoning_summary: string
display_name: string
description: string
default_reasoning_level: string
supported_reasoning_levels: Array<{ effort: string, description: string }>
shell_type: string
visibility: string
minimal_client_version: string
supported_in_api: boolean
availability_nux: null
upgrade: null
priority: number
model_messages: {
  instructions_template: string,
  instructions_variables: {
    personality_default: string,
    personality_friendly: string,
    personality_pragmatic: string
  },
  approvals: null | { never: string },
  auto_review?: { policy: string, policy_template: string },
  permissions?: {
    danger_full_access: string,
    read_only: string,
    workspace_write: string
  }
}
experimental_supported_tools: []
available_in_plans: string[]
supports_search_tool: boolean
default_service_tier: null
service_tiers: Array<{ id: string, name: string, description: string }>
additional_speed_tiers: string[]
supports_reasoning_summaries: boolean
```

其中 `auto_review` 和 `permissions` 只出现在 `codex-auto-review` 模板变体；普通模板没有这两组键。`experimental_supported_tools` 在当前 11 项中都是空数组，但字段类型仍是数组。

来源规则：

### 七个文字条目

1. 从当前 bundled Codex catalog 选择 metadata source：六项使用同名 slug；`gpt-5.3-codex-spark` 使用 bundled `gpt-5.4-mini` 兼容模板，因为当前 embedded catalog 没有对应的同名 metadata source。
2. 对整个对象做深拷贝，所以能力、上下文、工具、推理、服务层、消息模板等字段来自 bundled catalog。
3. 手工覆盖：
   - `slug = "solov::" + upstream id`
   - `display_name = 固定映射 + " · Solov"`
   - `description = "Solov Responses route for <id>."`
   - `visibility = "list"`
   - `supported_in_api = true`
   - `priority = 1001..1007`

### 四个图片条目

1. 全部深拷贝 bundled `gpt-5.4-mini` 的完整对象作为 schema 模板；这并不表示图片上游实际具有 gpt-5.4-mini 的全部能力。
2. 手工覆盖：slug、显示名、description、text-only 输入、关闭并行工具/搜索/verbosity/skills/plugin 指令、`use_responses_lite=true`、`tool_mode=code_mode_only`、低 reasoning、list visibility、API 可见以及 `priority=2001..2004`。
3. 客户端仍可能发送工具字段，路由实际只抽取最后一条 user `input_text`；目录元数据不是强制请求 schema。

`model-catalog.json` 只是 11 个第三方本地条目；运行时 `GET /models` 先获取官方完整目录，逐对象原样保留，再把这 11 项追加到尾部。因此正式返回 schema 的官方部分以实时上游为准。

字段的语义契约来自当前 bundled app-server `ModelInfo`，本项目没有独立 JSON Schema 文件。升级后必须重新用 `validate_catalog.ps1` 与 `model/list` 验证。

## Q11. 7 个文字 + 4 个图片模型的验证等级

| 本地模型 | 类别 | 历史真实上游证据 | 目录/适配证据 | 当前结论 |
| --- | --- | --- | --- | --- |
| `solov::gpt-5.6-sol` | 文字 | `/v1/responses` HTTP 200 | visible | 历史真实成功过 |
| `solov::gpt-5.6-terra` | 文字 | HTTP 200 | visible | 历史真实成功过 |
| `solov::gpt-5.5` | 文字 | HTTP 200 | visible | 历史真实成功过 |
| `solov::gpt-5.4` | 文字 | HTTP 200 | visible | 历史真实成功过 |
| `solov::gpt-5.4-mini` | 文字 | HTTP 200；CLI 正确路由但后续额度 403 | visible | 历史真实成功过；当前成功未复验 |
| `solov::gpt-5.3-codex-spark` | 文字 | HTTP 200 | visible | 历史真实成功过 |
| `solov::codex-auto-review` | 文字 | HTTP 200 | visible | 历史真实成功过 |
| `solov::gpt-image-1` | 图片 | `/v1/images/generations` HTTP 200、1024×1024 PNG | visible；合成全链成功 | 历史真实成功过 |
| `solov::gpt-image-1.5` | 图片 | 未运行；仅上游 advertised | visible；固定适配合成验证 | 未取得真实成功 |
| `solov::gpt-image-2` | 图片 | 未运行；仅上游 advertised | visible；固定适配合成验证 | 未取得真实成功 |
| `solov::gpt-image-2-2026-04-21` | 图片 | 未运行；仅上游 advertised | visible；固定适配合成验证 | 未取得真实成功 |

七个文字模型的 manifest HTTP 200 是 2026-08-12 历史探测证据，本轮未发真实请求，不能代表当前仍可用。manifest 还记录了其余 10 个文字候选两轮均 503，因此未进入目录。

---

## 兼容边界

## Q12. 实际验证过哪些 Codex 版本？升级失效经历？

实际验证基线：

- Windows Codex 桌面包版本：`26.803.10989.0`；
- bundled core：`codex-cli 0.147.0-alpha.6.6`；
- Node：`24.13.0`。

在其他桌面/core 版本上的运行：**未验证**。没有完成跨两个版本的升级回归，因此“升级过程中实际失效过”没有正式版本对照证据。

开发过程中确实发现过一个协议兼容边界：

- 原方案把 Images API 结果转换为 Responses `image_generation_call`。
- 当前 0.147 core 能解析 raw `image_generation_call`，但不会把它提升为桌面消费的 `item/completed:imageGeneration`；桌面收不到可渲染 item。
- 最终改为：严格 PNG 落盘，然后通过正常 assistant `message/output_text` 返回绝对本机 Markdown 图片路径。该方式在当前 app-server 得到 `item/completed:agentMessage` 并被全链验证。

这不是已发布版本 A 升到版本 B 后的回归，而是针对当前版本的协议探测后改方案。目录协议、SSE 形状及 Markdown 本地路径都可能随新版 core 变化，升级必须重跑 model/list、37 单测、29 黑盒和 bundled 全链。

## Q13. macOS 是否可行？哪些模块可复用？

可行性分析：核心路由协议可移植，现有运维/密钥/路径层不能原样使用。macOS **未实际运行验证**。

可较大程度复用：

- Node ESM 路由核心和模型分流；
- 官方目录动态合并；
- header allowlist 与身份隔离；
- Responses/Images API 转换；
- SSE、失败语义、限长、重定向和 SSRF 约束；
- Base64 和 PNG 结构校验；
- Node 单测与 Python 黑盒的多数协议用例；
- catalog JSON/manifest 的概念与生成逻辑（PowerShell 实现需改写或要求 `pwsh`）。

需要平台适配或重写：

- DPAPI → macOS Keychain；
- HKCU Run → LaunchAgent 或产品内登录启动机制；
- PowerShell install/start/stop/status/rollback/validators → Electron/Node 或 shell/launchd 实现；
- Windows PID/WMI/路径/盘符/UNC/junction 检查 → POSIX PID、realpath、symlink、权限和锁；
- `chmod`/ACL 策略、输出目录（应放 `app.getPath("userData")` 或等价私有目录）；
- 本地绝对文件路径 Markdown 在目标 Electron renderer 的 CSP、`file:`/自定义协议和 sandbox 下需重新验证；更稳妥的是产品自有安全协议，如 `app-image://<id>`；
- 自动端口、多实例与应用生命周期应由 Electron 主进程管理。

不能直接复制“Windows 上的安全结论”到 macOS。尤其图片原子发布、链接竞态、文件权限和客户端本地图片加载必须重新做平台安全测试。

---

## 证据

## Q14. 成功图片与确定性 403 的脱敏日志、SSE 序列

### 本轮合成成功（非真实付费）

条件：bundled `codex-cli 0.147.0-alpha.6.6`、回环伪 OpenAI/图片服务、合成身份、临时输出根、1×1 68-byte PNG；第三方请求 1 次，未读取真实认证。

结构化日志（耗时值归一化为占位符）：

```json
{"event":"proxy_request","route":"openai","method":"GET","path":"/models","status":200,"outcome":"completed","duration_ms":"<integer>"}
{"event":"proxy_request","route":"solov_image","method":"POST","path":"/responses","status":200,"outcome":"completed","duration_ms":"<integer>"}
```

SSE 事件顺序：

```text
response.created
response.output_item.added
response.output_item.done
response.completed
```

app-server 可观察结果：

```text
item/completed:agentMessage
turn/completed:completed
```

图片 Markdown 中的本机路径已剔除；SSE 中没有 Base64 或用户 prompt。

### 本轮合成确定性 403（非真实付费）

```json
{"event":"proxy_request","route":"openai","method":"GET","path":"/models","status":200,"outcome":"completed","duration_ms":"<integer>"}
{"event":"proxy_request","route":"solov_image","method":"POST","path":"/responses","status":403,"outcome":"terminal_upstream_status","duration_ms":"<integer>"}
```

SSE：

```text
response.created
response.failed
```

稳定终态：

```json
{
  "status": "failed",
  "error": {
    "code": "invalid_prompt",
    "message": "image_provider_access_denied: The image provider denied this request. Check provider access and balance."
  }
}
```

结果：伪第三方只收到 1 次请求；turn failed；没有 `Reconnecting`；没有 agentMessage；没有文件；私有上游正文不可见。

### 真实成功边界

**当前部署从未通过最终“图片下拉”版本取得真实成功图片。** 最终图片下拉部署后的真实验收被第三方 HTTP 403 拒绝，输出目录没有新文件。

历史真实证据发生在 2026-08-12：

- `gpt-image-1` 直接 Images API smoke 曾返回 HTTP 200 和 1024×1024 PNG；
- 同模型通过当时的独立本机 `/images/generations` 路由曾返回 HTTP 200；
- 直连探测首次解析器误判后重试，因此直连阶段实际触发 2 次；独立路由验证只触发 1 次；
- 现有记录只有日期，没有可信的更精确时间；当前在线可用性未验证。

因此历史成功证明上游和独立图片路由曾可用，不证明最终下拉适配在真实上游当前成功。

## Q15. 37 项单测 + 29 项安全黑盒最近输出

本轮均只使用本机合成夹具/回环伪上游，没有真实认证和付费请求。

### Node 单测

结果：`37 passed, 0 failed, 0 skipped, 0 todo`

```text
> codex-dual-upstream-router@0.1.0 test
> node --test --test-concurrency=1

✔ production upstream override is rejected unless it is an explicit loopback test upstream
✔ HTTPS proxy configuration accepts only an unauthenticated loopback HTTP URL
✔ catalog loader accepts only a bounded Solov-only models.json
✔ router binds only to 127.0.0.1
✔ OpenAI route preserves a valid zstd body and required first-party headers
✔ Solov route strips its prefix, removes OpenAI headers, and injects only the Solov bearer
✔ image picker model saves a PNG and returns a desktop-consumable Markdown message
✔ image picker accepts an explicit identity Image API response encoding
✔ image picker converts deterministic upstream 4xx failures into terminal Responses SSE
✔ image picker preserves retryable 429 and 5xx HTTP failure semantics
✔ image picker route rejects ambiguous or multimodal prompts before Image API
✔ image picker route validates a single PNG and rejects malformed Image API success
✔ image picker rejects unsafe PNG semantics and critical chunk ordering
✔ image output state cannot be forged and linked ancestors are rejected
✔ Solov image generation accepts only its four fixed models and strips their route prefix
✔ Solov image generation rejects official and unknown models, queries, and adjacent paths before forwarding
✔ Solov image generation blocks redirects without exposing Location
✔ Solov image generation streams base64 JSON responses larger than the catalog limit
✔ Solov image generation fails closed when its key is not configured
✔ Solov image generation uses only the fixed Solov CONNECT authority and path
✔ CONNECT proxy uses only the fixed OpenAI and Solov authorities with verified SNI
✔ GET /models uses the fixed OpenAI CONNECT authority and verified SNI
✔ SSE response chunks are streamed before the upstream response completes
✔ SSE remains streaming through CONNECT and client cancellation closes the TLS upstream
✔ redirects are blocked and Location is not exposed to the client
✔ authentication and throttling statuses keep only safe diagnostic headers
✔ unknown models, paths, encodings, and unauthenticated requests fail before any upstream call
✔ WebSocket probe gets an explicit HTTP fallback response without upstream forwarding
✔ Solov route fails closed when its key is not configured
✔ responses/compact is the only additional allowed endpoint
✔ Solov responses/compact fails closed until compatibility is verified
✔ GET /models preserves the official catalog, appends Solov, and refreshes route allowlists
✔ GET /models passes through official errors without exposing a Solov-only catalog
▶ GET /models rejects malformed, redirected, and oversized official catalogs
  ✔ malformed
  ✔ redirected
  ✔ oversized
✔ GET /models rejects malformed, redirected, and oversized official catalogs
ℹ tests 37
ℹ suites 0
ℹ pass 37
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
```

### 安全黑盒

结果：`29 passed, 0 failed`

```text
[PASS] loopback-only listener
[PASS] unknown path rejected
[PASS] unknown model rejected
[PASS] official catalog preserved and Solov models appended
[PASS] catalog-discovered official model POST
[PASS] official catalog error has no Solov fallback
[PASS] Solov identity-header isolation
[PASS] four Solov image models strip prefix and isolate identity
[PASS] image route rejects unknown and official models
[PASS] image route SSRF and redirect resistance
[PASS] image response and error pass-through
[PASS] Responses image text prompt, isolation, and SSE contract
[PASS] Responses image extracts only latest user input_text
[PASS] Responses image rejects ambiguous and multimodal prompts
[PASS] Responses image invalid-upstream and status semantics
[PASS] Responses image prompt cannot choose an output path
[PASS] Responses image output-root replacement fails closed
[PASS] Responses image cancellation leaves no file
[PASS] Responses image files remain private regular files
[PASS] Responses image concurrency publishes unique atomic files
[PASS] Responses image logs exclude prompt, base64, and credentials
[PASS] OpenAI never receives Solov key
[PASS] AgentAssertion pass-through
[PASS] SSRF override resistance
[PASS] upstream redirect not followed
[PASS] SSE streaming pass-through
[PASS] client cancellation propagation
[PASS] 401 pass-through
[PASS] 429 pass-through

Summary: 29 passed, 0 failed
```

说明：以上是脱敏副本最近一次运行 stdout；唯一省略的是 Node TAP 每项易变的毫秒耗时与总时长。测试夹具中的具体合成输入值已泛化为不可用占位符，但测试名称中的术语 `prompt` 只是功能描述，不是任何真实输入内容。

---

## 未验证 / 未观察总表

1. 桌面端与 CLI 可归因的完整额外路径全集。
2. `/alpha/search`、普通 `GET /responses`、`/favicon.ico` 被拒后的桌面/CLI 具体表现。
3. token 刷新是否经过本机路由（未观察）；本机实际 token 到期后的自动续期行为。
4. 客户端完全未登录时桌面 UI 和终端 CLI 的具体呈现。
5. 终端交互式 CLI 模型菜单、独立安装 PATH CLI、只依赖全局配置的 CLI。
6. 当前第三方状态下 CLI 成功取得文字输出。
7. 第三方程序真实占用 43120 的端到端启动行为。
8. 路由完全下线时桌面端与 CLI 的具体错误文案。
9. 任意复杂既有 `config.toml` 的通用初次安装合并策略。
10. Node 22 运行。
11. 三个额外图片模型的真实付费成功。
12. 最终图片下拉版本的真实成功生成。
13. 其他 Codex 桌面/core 版本及真实升级回归。
14. macOS 运行、Keychain/LaunchAgent、本地图片渲染和文件系统安全。
15. 第三方 Images API 幂等能力及“上游成功、回程失败”后的完全防重复计费。
