[CmdletBinding()]
param(
    [int]$Port = 43120,
    [string]$Model = 'solov::gpt-image-1',
    [string]$Prompt = '<SYNTHETIC_IMAGE_INPUT>',
    [int]$TimeoutSeconds = 180
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

function Send-AppMessage {
    param([Diagnostics.Process]$Process, [hashtable]$Message)
    $Process.StandardInput.WriteLine(($Message | ConvertTo-Json -Compress -Depth 30))
    $Process.StandardInput.Flush()
}

function Read-AppLine {
    param(
        [Diagnostics.Process]$Process,
        [Collections.Generic.List[object]]$Messages,
        [DateTime]$Deadline
    )
    $remaining = [Math]::Max(1, [int]($Deadline - [DateTime]::UtcNow).TotalMilliseconds)
    $task = $Process.StandardOutput.ReadLineAsync()
    if (-not $task.Wait($remaining)) { throw 'Timed out waiting for app-server output.' }
    $line = $task.Result
    if ($null -eq $line) { throw 'app-server exited unexpectedly.' }
    try { $message = $line | ConvertFrom-Json -Depth 100 } catch { return $null }
    $Messages.Add($message) | Out-Null
    return $message
}

function Read-AppResponse {
    param(
        [Diagnostics.Process]$Process,
        [Collections.Generic.List[object]]$Messages,
        [int]$Id,
        [DateTime]$Deadline
    )
    while ([DateTime]::UtcNow -lt $Deadline) {
        $message = Read-AppLine -Process $Process -Messages $Messages -Deadline $Deadline
        if ($null -ne $message -and $message.PSObject.Properties['id'] -and $message.id -eq $Id) {
            return $message
        }
    }
    throw "Timed out waiting for app-server response $Id."
}

function Read-AppNotification {
    param(
        [Diagnostics.Process]$Process,
        [Collections.Generic.List[object]]$Messages,
        [string]$Method,
        [DateTime]$Deadline
    )
    $existing = $Messages | Where-Object {
        $_.PSObject.Properties['method'] -and $_.method -ceq $Method
    } | Select-Object -Last 1
    if ($null -ne $existing) { return $existing }
    while ([DateTime]::UtcNow -lt $Deadline) {
        $message = Read-AppLine -Process $Process -Messages $Messages -Deadline $Deadline
        if ($null -ne $message -and $message.PSObject.Properties['method'] -and $message.method -ceq $Method) {
            return $message
        }
    }
    throw "Timed out waiting for app-server notification $Method."
}

$health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -TimeoutSec 3
Assert-True ($health.status -ceq 'ok') "Router is not healthy on 127.0.0.1:$Port."

$authPath = Join-Path $env:USERPROFILE '.codex\auth.json'
Assert-True (Test-Path -LiteralPath $authPath -PathType Leaf) "Codex login cache was not found: $authPath"
$package = Get-AppxPackage -Name 'OpenAI.Codex' | Sort-Object Version -Descending | Select-Object -First 1
Assert-True ($null -ne $package) 'OpenAI.Codex is not installed.'
$sourceExe = Join-Path $package.InstallLocation 'app\resources\codex.exe'
Assert-True (Test-Path -LiteralPath $sourceExe -PathType Leaf) "Bundled codex.exe not found: $sourceExe"

$tempBase = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
$tempRoot = Join-Path $tempBase ('codex-live-image-picker-' + [Guid]::NewGuid().ToString('N'))
$isolatedHome = Join-Path $tempRoot 'home'
$copiedExe = Join-Path $tempRoot 'codex.exe'
$appServer = $null
$messages = [Collections.Generic.List[object]]::new()

try {
    [IO.Directory]::CreateDirectory($isolatedHome) | Out-Null
    [IO.File]::WriteAllBytes($copiedExe, [IO.File]::ReadAllBytes($sourceExe))
    [IO.File]::WriteAllBytes((Join-Path $isolatedHome 'auth.json'), [IO.File]::ReadAllBytes($authPath))

    $appInfo = [Diagnostics.ProcessStartInfo]::new()
    $appInfo.FileName = $copiedExe
    $appInfo.WorkingDirectory = $tempRoot
    $appInfo.UseShellExecute = $false
    $appInfo.CreateNoWindow = $true
    $appInfo.RedirectStandardInput = $true
    $appInfo.RedirectStandardOutput = $true
    $appInfo.RedirectStandardError = $true
    $appInfo.Environment['CODEX_HOME'] = $isolatedHome
    $appInfo.Environment['DO_NOT_TRACK'] = '1'
    $appInfo.Environment['OTEL_SDK_DISABLED'] = 'true'
    foreach ($argument in @(
        '--config', 'model_provider="openai"',
        '--config', ('openai_base_url="http://127.0.0.1:' + $Port + '"'),
        'app-server'
    )) { $appInfo.ArgumentList.Add($argument) }

    $appServer = [Diagnostics.Process]::new()
    $appServer.StartInfo = $appInfo
    Assert-True ($appServer.Start()) 'Failed to start the isolated bundled app-server.'
    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)

    Send-AppMessage -Process $appServer -Message ([ordered]@{
        id = 1; method = 'initialize'; params = [ordered]@{
            clientInfo = [ordered]@{ name = 'live-image-picker-check'; title = 'Live Image Picker Check'; version = '1.0.0' }
            capabilities = [ordered]@{ experimentalApi = $true }
        }
    })
    $initialize = Read-AppResponse -Process $appServer -Messages $messages -Id 1 -Deadline $deadline
    Assert-True ($null -eq $initialize.PSObject.Properties['error']) 'initialize returned an error.'
    Send-AppMessage -Process $appServer -Message ([ordered]@{ method = 'initialized'; params = @{} })

    Send-AppMessage -Process $appServer -Message ([ordered]@{
        id = 2; method = 'model/list'; params = [ordered]@{ cursor = $null; includeHidden = $false; limit = 200 }
    })
    $modelList = Read-AppResponse -Process $appServer -Messages $messages -Id 2 -Deadline $deadline
    Assert-True ($null -eq $modelList.PSObject.Properties['error']) 'model/list returned an error.'
    $selected = @($modelList.result.data | Where-Object model -ceq $Model)
    Assert-True ($selected.Count -eq 1 -and $selected[0].hidden -eq $false) "Image model was not visible: $Model"

    Send-AppMessage -Process $appServer -Message ([ordered]@{
        id = 3; method = 'thread/start'; params = [ordered]@{
            model = $Model; modelProvider = 'openai'; cwd = $tempRoot
            approvalPolicy = 'never'; ephemeral = $true
        }
    })
    $threadStart = Read-AppResponse -Process $appServer -Messages $messages -Id 3 -Deadline $deadline
    Assert-True ($null -eq $threadStart.PSObject.Properties['error']) 'thread/start returned an error.'
    Assert-True ([string]$threadStart.result.model -ceq $Model) 'thread/start changed the selected model.'
    $threadId = [string]$threadStart.result.thread.id

    Send-AppMessage -Process $appServer -Message ([ordered]@{
        id = 4; method = 'turn/start'; params = [ordered]@{
            threadId = $threadId
            input = @([ordered]@{ type = 'text'; text = $Prompt })
        }
    })
    $turnStart = Read-AppResponse -Process $appServer -Messages $messages -Id 4 -Deadline $deadline
    Assert-True ($null -eq $turnStart.PSObject.Properties['error']) 'turn/start returned an error.'
    $turnCompleted = Read-AppNotification -Process $appServer -Messages $messages -Method 'turn/completed' -Deadline $deadline

    $safeErrors = @($messages | Where-Object {
        $_.PSObject.Properties['method'] -and $_.method -ceq 'error'
    } | ForEach-Object {
        $text = if ($_.params.PSObject.Properties['error']) { [string]$_.params.error.message } else { [string]$_.params.message }
        if ($text.Length -gt 500) { $text.Substring(0, 500) } else { $text }
    })
    Assert-True ($turnCompleted.params.turn.status -ceq 'completed') "Image turn failed: $($safeErrors -join ' | ')"

    $agentEvents = @($messages | Where-Object {
        $_.PSObject.Properties['method'] -and $_.method -ceq 'item/completed' -and $_.params.item.type -ceq 'agentMessage'
    })
    Assert-True ($agentEvents.Count -eq 1) "Expected one completed image agentMessage, got $($agentEvents.Count)."
    $markdown = [string]$agentEvents[0].params.item.text
    Assert-True ($markdown.StartsWith('![Generated image](<', [StringComparison]::Ordinal) -and $markdown.EndsWith('>)', [StringComparison]::Ordinal)) 'Image response did not contain the expected local-image Markdown.'
    $imagePath = $markdown.Substring('![Generated image](<'.Length, $markdown.Length - '![Generated image](<'.Length - 2).Replace('/', '\')
    $imagePath = [IO.Path]::GetFullPath($imagePath)
    $expectedOutputRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'OpenAI\CodexDualRouter\generated-images'))
    Assert-True ($imagePath.StartsWith($expectedOutputRoot.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) 'Generated image escaped the installed output directory.'
    Assert-True (Test-Path -LiteralPath $imagePath -PathType Leaf) 'Generated image file does not exist.'
    $imageBytes = [IO.File]::ReadAllBytes($imagePath)
    Assert-True ($imageBytes.Length -gt 8) 'Generated image file was empty.'
    Assert-True ([Convert]::ToHexString($imageBytes[0..7]) -ceq '89504E470D0A1A0A') 'Generated image did not have a PNG signature.'

    [pscustomobject]@{
        ExitCode = 0
        RouterStatus = [string]$health.status
        PackageVersion = $package.Version.ToString()
        AppServerBinaryVersion = (& $copiedExe --version | Out-String).Trim()
        SelectedModel = [string]$threadStart.result.model
        ModelVisible = $true
        NotificationMethod = [string]$agentEvents[0].method
        ItemType = [string]$agentEvents[0].params.item.type
        TurnStatus = [string]$turnCompleted.params.turn.status
        ImagePath = $imagePath
        ImageBytes = $imageBytes.Length
        PngSignatureValid = $true
        PaidImageRequestsExpected = 1
    }
}
finally {
    if ($null -ne $appServer -and -not $appServer.HasExited) {
        $appServer.Kill($true)
        $appServer.WaitForExit(5000) | Out-Null
    }
    $resolvedRoot = [IO.Path]::GetFullPath($tempRoot)
    $expectedPrefix = $tempBase.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if ($resolvedRoot.StartsWith($expectedPrefix, [StringComparison]::OrdinalIgnoreCase) -and
        [IO.Path]::GetFileName($resolvedRoot).StartsWith('codex-live-image-picker-', [StringComparison]::Ordinal) -and
        [IO.Directory]::Exists($resolvedRoot)) {
        Get-ChildItem -LiteralPath $resolvedRoot -Force -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
            try { $_.Attributes = [IO.FileAttributes]::Normal } catch {}
        }
        [IO.Directory]::Delete($resolvedRoot, $true)
    }
}
