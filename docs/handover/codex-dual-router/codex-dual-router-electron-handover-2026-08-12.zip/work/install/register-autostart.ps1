[CmdletBinding()]
param(
    [string]$InstallRoot = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$startScript = Join-Path $InstallRoot 'start-router.ps1'
if (-not (Test-Path -LiteralPath $startScript -PathType Leaf)) {
    throw "Start script not found: $startScript"
}

$runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$command = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $startScript + '"'
New-Item -Path $runKey -Force | Out-Null
New-ItemProperty -Path $runKey -Name 'CodexDualRouter' -Value $command -PropertyType String -Force | Out-Null
Write-Output 'Codex dual router will start automatically when this Windows user signs in.'
