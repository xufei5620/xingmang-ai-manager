[CmdletBinding()]
param(
    [int]$Port = 43120,
    [string]$OfficialModel = 'gpt-5.4-mini',
    [string]$SolovModel = 'solov::gpt-5.4-mini',
    [int]$TimeoutSeconds = 120
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) {
        throw $Message
    }
}

function Invoke-CodexSmoke {
    param(
        [string]$Executable,
        [string]$CodexHome,
        [string]$WorkingDirectory,
        [string]$Model,
        [int]$RouterPort,
        [int]$Timeout
    )

    $processInfo = [Diagnostics.ProcessStartInfo]::new()
    $processInfo.FileName = $Executable
    $processInfo.WorkingDirectory = $WorkingDirectory
    $processInfo.UseShellExecute = $false
    $processInfo.CreateNoWindow = $true
    $processInfo.RedirectStandardOutput = $true
    $processInfo.RedirectStandardError = $true
    $processInfo.Environment['CODEX_HOME'] = $CodexHome
    foreach ($argument in @(
        'exec',
        '--ignore-user-config',
        '--config', 'model_provider="openai"',
        '--config', ('openai_base_url="http://127.0.0.1:' + $RouterPort + '"'),
        '--config', 'approval_policy="never"',
        '--model', $Model,
        '--sandbox', 'read-only',
        '--skip-git-repo-check',
        '--ephemeral',
        '--color', 'never',
        '<SYNTHETIC_TEXT_INPUT>'
    )) {
        $processInfo.ArgumentList.Add($argument)
    }

    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $processInfo
    Assert-True ($process.Start()) "Failed to start Codex smoke test for $Model."
    $stdoutTask = $process.StandardOutput.ReadToEndAsync()
    $stderrTask = $process.StandardError.ReadToEndAsync()
    if (-not $process.WaitForExit($Timeout * 1000)) {
        $process.Kill($true)
        $process.WaitForExit(5000) | Out-Null
        throw "Codex smoke test timed out for $Model."
    }
    $stdout = $stdoutTask.GetAwaiter().GetResult()
    $stderr = $stderrTask.GetAwaiter().GetResult()
    if ($process.ExitCode -ne 0) {
        $safeError = if ([string]::IsNullOrWhiteSpace($stderr)) { $stdout } else { $stderr }
        if ($safeError.Length -gt 2000) {
            $safeError = $safeError.Substring(0, 2000)
        }
        throw "Codex smoke test failed for $Model (exit $($process.ExitCode)): $safeError"
    }

    $nonEmptyLines = @($stdout -split "`r?`n" | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    $lastLine = if ($nonEmptyLines.Count -eq 0) { '' } else { $nonEmptyLines[-1].Trim() }
    [pscustomobject]@{
        Model = $Model
        ExitCode = $process.ExitCode
        LastLine = $lastLine
    }
}

$health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -Method Get -TimeoutSec 3
Assert-True ($health.status -ceq 'ok') "Router is not healthy on 127.0.0.1:$Port."

$authPath = 'C:\Users\<USER>\.codex\auth.json'
Assert-True (Test-Path -LiteralPath $authPath -PathType Leaf) "Codex login cache was not found: $authPath"
$package = Get-AppxPackage -Name 'OpenAI.Codex' | Sort-Object Version -Descending | Select-Object -First 1
Assert-True ($null -ne $package) 'OpenAI.Codex is not installed.'
$sourceExe = Join-Path $package.InstallLocation 'app\resources\codex.exe'
Assert-True (Test-Path -LiteralPath $sourceExe -PathType Leaf) "Bundled codex.exe not found: $sourceExe"

$tempBase = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
$tempRoot = Join-Path $tempBase ('codex-dual-router-response-' + [Guid]::NewGuid().ToString('N'))
$isolatedHome = Join-Path $tempRoot 'home'
$copiedExe = Join-Path $tempRoot 'codex.exe'

try {
    [IO.Directory]::CreateDirectory($isolatedHome) | Out-Null
    [IO.File]::WriteAllBytes($copiedExe, [IO.File]::ReadAllBytes($sourceExe))
    [IO.File]::WriteAllBytes((Join-Path $isolatedHome 'auth.json'), [IO.File]::ReadAllBytes($authPath))

    $official = Invoke-CodexSmoke `
        -Executable $copiedExe `
        -CodexHome $isolatedHome `
        -WorkingDirectory $tempRoot `
        -Model $OfficialModel `
        -RouterPort $Port `
        -Timeout $TimeoutSeconds
    $solov = Invoke-CodexSmoke `
        -Executable $copiedExe `
        -CodexHome $isolatedHome `
        -WorkingDirectory $tempRoot `
        -Model $SolovModel `
        -RouterPort $Port `
        -Timeout $TimeoutSeconds

    [pscustomobject]@{
        RouterStatus = $health.status
        Official = $official
        Solov = $solov
    }
}
finally {
    $resolvedTempRoot = [IO.Path]::GetFullPath($tempRoot)
    $expectedPrefix = $tempBase.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $leaf = [IO.Path]::GetFileName($resolvedTempRoot)
    if ($resolvedTempRoot.StartsWith($expectedPrefix, [StringComparison]::OrdinalIgnoreCase) -and
        $leaf.StartsWith('codex-dual-router-response-', [StringComparison]::Ordinal)) {
        [IO.Directory]::Delete($resolvedTempRoot, $true)
    }
}
