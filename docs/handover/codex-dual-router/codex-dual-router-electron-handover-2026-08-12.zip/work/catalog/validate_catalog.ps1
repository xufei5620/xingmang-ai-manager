[CmdletBinding()]
param(
    [string]$CatalogPath,
    [string]$ManifestPath,
    [switch]$SkipRuntime
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if ([string]::IsNullOrWhiteSpace($CatalogPath)) {
    $CatalogPath = Join-Path $PSScriptRoot 'model-catalog.json'
}
if ([string]::IsNullOrWhiteSpace($ManifestPath)) {
    $ManifestPath = Join-Path $PSScriptRoot 'solov-model-manifest.json'
}

function Assert-True {
    param(
        [bool]$Condition,
        [string]$Message
    )
    if (-not $Condition) {
        throw $Message
    }
}

function Read-AppServerResponse {
    param(
        [System.Diagnostics.Process]$Process,
        [int]$RequestId,
        [int]$TimeoutMilliseconds = 15000
    )

    $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMilliseconds)
    while ([DateTime]::UtcNow -lt $deadline) {
        $remaining = [Math]::Max(1, [int]($deadline - [DateTime]::UtcNow).TotalMilliseconds)
        $readTask = $Process.StandardOutput.ReadLineAsync()
        if (-not $readTask.Wait($remaining)) {
            throw "Timed out waiting for app-server response id $RequestId."
        }
        $line = $readTask.Result
        if ($null -eq $line) {
            throw "app-server exited before response id $RequestId."
        }
        try {
            $message = $line | ConvertFrom-Json
        }
        catch {
            continue
        }
        $idProperty = $message.PSObject.Properties['id']
        if ($null -ne $idProperty -and $idProperty.Value -eq $RequestId) {
            return $message
        }
    }
    throw "Timed out waiting for app-server response id $RequestId."
}

$resolvedCatalog = [System.IO.Path]::GetFullPath($CatalogPath)
$resolvedManifest = [System.IO.Path]::GetFullPath($ManifestPath)
Assert-True (Test-Path -LiteralPath $resolvedCatalog -PathType Leaf) "Catalog not found: $resolvedCatalog"
Assert-True (Test-Path -LiteralPath $resolvedManifest -PathType Leaf) "Manifest not found: $resolvedManifest"

$utf8 = New-Object System.Text.UTF8Encoding($false, $true)
$catalog = [System.IO.File]::ReadAllText($resolvedCatalog, $utf8) | ConvertFrom-Json
$manifest = [System.IO.File]::ReadAllText($resolvedManifest, $utf8) | ConvertFrom-Json
Assert-True ($null -ne $catalog.models) 'Top-level models array is required.'

$middleDot = [char]0x00B7
$solovSuffix = ' ' + $middleDot + ' Solov'
$solovImageSuffix = $solovSuffix + ' Image'
$textExpectations = [ordered]@{
    'solov::gpt-5.6-sol' = 'GPT-5.6 Sol' + $solovSuffix
    'solov::gpt-5.6-terra' = 'GPT-5.6 Terra' + $solovSuffix
    'solov::gpt-5.5' = 'GPT-5.5' + $solovSuffix
    'solov::gpt-5.4' = 'GPT-5.4' + $solovSuffix
    'solov::gpt-5.4-mini' = 'GPT-5.4 Mini' + $solovSuffix
    'solov::gpt-5.3-codex-spark' = 'GPT-5.3 Codex Spark' + $solovSuffix
    'solov::codex-auto-review' = 'Codex Auto Review' + $solovSuffix
}
$imageExpectations = [ordered]@{
    'solov::gpt-image-1' = 'GPT Image 1' + $solovImageSuffix
    'solov::gpt-image-1.5' = 'GPT Image 1.5' + $solovImageSuffix
    'solov::gpt-image-2' = 'GPT Image 2' + $solovImageSuffix
    'solov::gpt-image-2-2026-04-21' = 'GPT Image 2 (2026-04-21)' + $solovImageSuffix
}
$expectations = [ordered]@{}
foreach ($entry in $textExpectations.GetEnumerator()) {
    $expectations[$entry.Key] = $entry.Value
}
foreach ($entry in $imageExpectations.GetEnumerator()) {
    $expectations[$entry.Key] = $entry.Value
}

$includedTextManifestIds = @(
    $manifest.models |
        Where-Object { $_.category -ceq 'text' -and $_.include -eq $true } |
        ForEach-Object { 'solov::' + [string]$_.id }
)
$includedImageManifestIds = @(
    $manifest.models |
        Where-Object { $_.category -ceq 'image' -and $_.image_picker_include -eq $true } |
        ForEach-Object { 'solov::' + [string]$_.id }
)
$includedManifestIds = @($includedTextManifestIds + $includedImageManifestIds)

Assert-True ($catalog.models.Count -eq $expectations.Count) "Catalog must contain exactly $($expectations.Count) Solov models."
Assert-True ($includedTextManifestIds.Count -eq $textExpectations.Count) "Manifest must select exactly $($textExpectations.Count) text picker models."
Assert-True ($includedImageManifestIds.Count -eq $imageExpectations.Count) "Manifest must select exactly $($imageExpectations.Count) image picker models."
Assert-True (@($manifest.models | Where-Object { $_.category -ceq 'image' -and $_.include -eq $true }).Count -eq 0) 'Image models must never use the text include flag.'
Assert-True (@($manifest.models | Where-Object {
    $_.category -ne 'image' -and
    $null -ne $_.PSObject.Properties['image_picker_include'] -and
    $_.image_picker_include -eq $true
}).Count -eq 0) 'Only image models may use image_picker_include.'
Assert-True (($catalog.models.slug | Select-Object -Unique).Count -eq $catalog.models.Count) 'Duplicate catalog slugs are not allowed.'
Assert-True (@($catalog.models | Where-Object { -not ([string]$_.slug).StartsWith('solov::', [System.StringComparison]::Ordinal) }).Count -eq 0) 'The Solov-only catalog must not contain official/non-prefixed entries.'
Assert-True (@($includedManifestIds | Where-Object { $_ -notin $catalog.models.slug }).Count -eq 0) 'Every included manifest model must be present in the catalog.'
Assert-True (@($catalog.models.slug | Where-Object { $_ -notin $includedManifestIds }).Count -eq 0) 'Every catalog model must be marked include=true in the manifest.'

foreach ($modelId in $expectations.Keys) {
    $model = $catalog.models | Where-Object slug -eq $modelId | Select-Object -First 1
    Assert-True ($null -ne $model) "Missing model: $modelId"
    Assert-True ($model.display_name -ceq $expectations[$modelId]) "Unexpected display_name for $modelId"
    if ($imageExpectations.Contains($modelId)) {
        Assert-True ($model.display_name.EndsWith($solovImageSuffix, [System.StringComparison]::Ordinal)) "Solov Image suffix is required for $modelId"
    }
    else {
        Assert-True ($model.display_name.EndsWith($solovSuffix, [System.StringComparison]::Ordinal)) "Solov suffix is required for $modelId"
    }
    Assert-True (-not [string]::IsNullOrWhiteSpace($model.description)) "description is required for $modelId"
    Assert-True ($model.visibility -ceq 'list') "visibility must be list for picker model $modelId"
    Assert-True ($model.supported_in_api -eq $true) "supported_in_api must be true for $modelId"
    Assert-True (-not [string]::IsNullOrWhiteSpace($model.default_reasoning_level)) "default_reasoning_level is required for $modelId"
    Assert-True ($model.supported_reasoning_levels.Count -gt 0) "supported_reasoning_levels is required for $modelId"
    Assert-True (($model.supported_reasoning_levels.effort) -contains $model.default_reasoning_level) "default reasoning level is not supported for $modelId"
    Assert-True ($model.shell_type -ceq 'shell_command') "shell_type must be shell_command for $modelId"
    Assert-True ($model.context_window -gt 0) "context_window must be positive for $modelId"
    Assert-True ($model.max_context_window -ge $model.context_window) "max_context_window must cover context_window for $modelId"
    Assert-True (-not [string]::IsNullOrWhiteSpace($model.model_messages.instructions_template)) "model_messages.instructions_template is required for $modelId"
}

foreach ($modelId in $imageExpectations.Keys) {
    $model = $catalog.models | Where-Object slug -eq $modelId | Select-Object -First 1
    Assert-True (@($model.input_modalities).Count -eq 1 -and $model.input_modalities[0] -ceq 'text') "image input_modalities must be text-only for $modelId"
    Assert-True ($model.default_reasoning_level -ceq 'low') "image reasoning must default to low for $modelId"
    Assert-True ($model.supported_reasoning_levels.Count -eq 1 -and $model.supported_reasoning_levels[0].effort -ceq 'low') "image reasoning choices must contain only low for $modelId"
    Assert-True ($model.support_verbosity -eq $false) "image verbosity must be disabled for $modelId"
    Assert-True ($model.supports_parallel_tool_calls -eq $false) "image parallel tools must be disabled for $modelId"
    Assert-True ($model.supports_search_tool -eq $false) "image search must be disabled for $modelId"
    Assert-True ($model.include_skills_usage_instructions -eq $false) "image skills instructions must be disabled for $modelId"
    Assert-True ($model.include_plugin_usage_instructions -eq $false) "image plugin instructions must be disabled for $modelId"
    Assert-True ($model.use_responses_lite -eq $true) "image entries must use the lightweight request profile for $modelId"
    Assert-True ($model.tool_mode -ceq 'code_mode_only') "image tool_mode must use the only restricted Codex mode for $modelId"
    Assert-True (@($model.experimental_supported_tools).Count -eq 0) "image experimental_supported_tools must be empty for $modelId"
}

$staticResult = [pscustomobject]@{
    JsonParsed = $true
    SolovOnly = $true
    Models = $catalog.models.Count
    TextModels = $textExpectations.Count
    ImageModels = $imageExpectations.Count
    ManifestMatched = $true
    PickerVisibilityFields = $true
    InstructionsPresent = $true
}

if ($SkipRuntime) {
    $staticResult
    return
}

$package = Get-AppxPackage -Name 'OpenAI.Codex' | Sort-Object Version -Descending | Select-Object -First 1
Assert-True ($null -ne $package) 'OpenAI.Codex is not installed.'
$sourceExe = Join-Path $package.InstallLocation 'app\resources\codex.exe'
Assert-True (Test-Path -LiteralPath $sourceExe -PathType Leaf) "Bundled codex.exe not found: $sourceExe"

$tempRoot = Join-Path $PSScriptRoot ('.runtime-validation-' + [Guid]::NewGuid().ToString('N'))
$isolatedCodexHome = Join-Path $tempRoot 'home'
$copiedExe = Join-Path $tempRoot 'codex.exe'
$process = $null

try {
    New-Item -ItemType Directory -Path $isolatedCodexHome -Force | Out-Null
    # AppX files carry encryption metadata that Copy-Item cannot reapply outside WindowsApps.
    [System.IO.File]::WriteAllBytes($copiedExe, [System.IO.File]::ReadAllBytes($sourceExe))
    $codexVersion = (& $copiedExe --version | Out-String).Trim()
    $isolatedConfig = Join-Path $isolatedCodexHome 'config.toml'
    Assert-True (-not $resolvedCatalog.Contains("'")) 'The catalog path cannot be represented safely in the isolated TOML config.'
    [System.IO.File]::WriteAllText(
        $isolatedConfig,
        "model_catalog_json = '$resolvedCatalog'`r`n",
        [System.Text.UTF8Encoding]::new($false)
    )

    $processInfo = [System.Diagnostics.ProcessStartInfo]::new()
    $processInfo.FileName = $copiedExe
    $processInfo.Arguments = 'app-server'
    $processInfo.WorkingDirectory = $PSScriptRoot
    $processInfo.UseShellExecute = $false
    $processInfo.CreateNoWindow = $true
    $processInfo.RedirectStandardInput = $true
    $processInfo.RedirectStandardOutput = $true
    $processInfo.RedirectStandardError = $true
    $processInfo.EnvironmentVariables['CODEX_HOME'] = $isolatedCodexHome

    $process = [System.Diagnostics.Process]::new()
    $process.StartInfo = $processInfo
    Assert-True ($process.Start()) 'Failed to start the isolated Codex app-server.'

    $initialize = [ordered]@{
        id = 1
        method = 'initialize'
        params = [ordered]@{
            clientInfo = [ordered]@{
                name = 'catalog-validator'
                title = 'Catalog Validator'
                version = '1.0.0'
            }
            capabilities = [ordered]@{
                experimentalApi = $true
            }
        }
    } | ConvertTo-Json -Compress -Depth 20
    $process.StandardInput.WriteLine($initialize)
    $process.StandardInput.Flush()
    $initializeResponse = Read-AppServerResponse -Process $process -RequestId 1
    $initializeErrorProperty = $initializeResponse.PSObject.Properties['error']
    $initializeError = if ($null -eq $initializeErrorProperty) { $null } else { $initializeErrorProperty.Value }
    Assert-True ($null -eq $initializeError) ('initialize failed: ' + ($initializeError | ConvertTo-Json -Compress))

    $process.StandardInput.WriteLine('{"method":"initialized","params":{}}')
    $modelListRequest = [ordered]@{
        id = 2
        method = 'model/list'
        params = [ordered]@{
            cursor = $null
            includeHidden = $true
            limit = 100
        }
    } | ConvertTo-Json -Compress -Depth 20
    $process.StandardInput.WriteLine($modelListRequest)
    $process.StandardInput.Flush()

    $modelListResponse = Read-AppServerResponse -Process $process -RequestId 2
    $modelListErrorProperty = $modelListResponse.PSObject.Properties['error']
    $modelListError = if ($null -eq $modelListErrorProperty) { $null } else { $modelListErrorProperty.Value }
    Assert-True ($null -eq $modelListError) ('model/list failed: ' + ($modelListError | ConvertTo-Json -Compress))

    $listedModels = @($modelListResponse.result.data)
    Assert-True ($listedModels.Count -eq $expectations.Count) "0.147 model/list must return all $($expectations.Count) isolated catalog entries."
    foreach ($modelId in $expectations.Keys) {
        $listed = $listedModels | Where-Object model -eq $modelId | Select-Object -First 1
        Assert-True ($null -ne $listed) "0.147 model/list did not return $modelId"
        Assert-True ($listed.displayName -ceq $expectations[$modelId]) "0.147 model/list returned the wrong displayName for $modelId"
        Assert-True ($listed.hidden -eq $false) "0.147 marked $modelId hidden; the desktop picker would filter it out"
    }

    foreach ($modelId in $imageExpectations.Keys) {
        $listed = $listedModels | Where-Object model -eq $modelId | Select-Object -First 1
        Assert-True ($listed.defaultReasoningEffort -ceq 'low') "0.147 returned the wrong default reasoning effort for $modelId"
        Assert-True ($listed.supportedReasoningEfforts.Count -eq 1 -and $listed.supportedReasoningEfforts[0].reasoningEffort -ceq 'low') "0.147 returned unexpected reasoning choices for $modelId"
    }

    [pscustomobject]@{
        JsonParsed = $true
        SolovOnly = $true
        InstalledPackageVersion = $package.Version.ToString()
        AppServerBinaryVersion = $codexVersion
        ModelListReturned = $listedModels.Count
        TextModelsVisible = $textExpectations.Count
        ImageModelsVisible = $imageExpectations.Count
        PickerModelsVisible = $true
        ModelIds = @($expectations.Keys)
    }
}
finally {
    if ($null -ne $process -and -not $process.HasExited) {
        Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
        $process.WaitForExit(5000) | Out-Null
    }
    $resolvedTempRoot = [System.IO.Path]::GetFullPath($tempRoot)
    $catalogRoot = [System.IO.Path]::GetFullPath($PSScriptRoot) + [System.IO.Path]::DirectorySeparatorChar
    if ($resolvedTempRoot.StartsWith($catalogRoot, [System.StringComparison]::OrdinalIgnoreCase) -and
        ([System.IO.Path]::GetFileName($resolvedTempRoot)).StartsWith('.runtime-validation-', [System.StringComparison]::Ordinal) -and
        [System.IO.Directory]::Exists($resolvedTempRoot)) {
        [System.IO.Directory]::Delete($resolvedTempRoot, $true)
    }
}
