import http from "node:http";
import https from "node:https";
import tls from "node:tls";
import { randomBytes } from "node:crypto";
import {
  chmod,
  link,
  lstat,
  mkdir,
  open,
  readFile,
  realpath,
  stat,
  unlink,
} from "node:fs/promises";
import { basename, dirname, isAbsolute, join, parse, resolve, sep } from "node:path";
import { pipeline } from "node:stream";
import { promisify } from "node:util";
import { crc32, zstdDecompress } from "node:zlib";

import {
  ALLOWED_PATHS,
  DEFAULT_MAX_BODY_BYTES,
  DEFAULT_MAX_DECODED_BODY_BYTES,
  DEFAULT_MAX_IMAGE_RESPONSE_BYTES,
  DEFAULT_OPENAI_MODELS,
  DEFAULT_UPSTREAM_IDLE_TIMEOUT_MS,
  LISTEN_HOST,
  PRODUCTION_UPSTREAMS,
  SOLOV_IMAGE_GENERATION_MODELS,
} from "./config.mjs";

const decompressZstd = promisify(zstdDecompress);
const SOLOV_PREFIX = "solov::";
const JSON_CONTENT_TYPE = /^application\/(?:json|[^;]+\+json)(?:\s*;|$)/i;
const REDIRECT_STATUS_MIN = 300;
const REDIRECT_STATUS_MAX = 399;
const MAX_CATALOG_BYTES = 8 * 1024 * 1024;
const MAX_IMAGE_PROMPT_CHARS = 32_000;
const MAX_PNG_DIMENSION = 16_384;
const PNG_SIGNATURE = Buffer.from([
  0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
]);
const PNG_CRITICAL_CHUNKS = new Set(["IHDR", "PLTE", "IDAT", "IEND"]);
const PNG_ALLOWED_BIT_DEPTHS = new Map([
  [0, new Set([1, 2, 4, 8, 16])],
  [2, new Set([8, 16])],
  [3, new Set([1, 2, 4, 8])],
  [4, new Set([8, 16])],
  [6, new Set([8, 16])],
]);
const TERMINAL_IMAGE_UPSTREAM_STATUSES = new Set([400, 401, 403, 404, 409, 422]);
const preparedImageOutputStates = new WeakSet();

const OPENAI_EXACT_REQUEST_HEADERS = new Set([
  "accept",
  "accept-encoding",
  "accept-language",
  "authorization",
  "baggage",
  "chatgpt-account-id",
  "openai-beta",
  "originator",
  "session-id",
  "thread-id",
  "traceparent",
  "tracestate",
  "user-agent",
  "version",
  "x-client-request-id",
]);

const SOLOV_REQUEST_HEADERS = new Set([
  "accept",
  "accept-language",
  "user-agent",
]);

const EXACT_RESPONSE_HEADERS = new Set([
  "cache-control",
  "content-encoding",
  "content-type",
  "openai-processing-ms",
  "request-id",
  "retry-after",
  "www-authenticate",
  "x-request-id",
]);

class RouterError extends Error {
  constructor(status, code, publicMessage) {
    super(code);
    this.status = status;
    this.code = code;
    this.publicMessage = publicMessage;
  }
}

function normalizeBaseUrl(value) {
  const url = new URL(value);
  url.hash = "";
  url.search = "";
  url.pathname = url.pathname.replace(/\/+$/, "");
  return url;
}

function isSameBase(actual, expected) {
  return (
    actual.protocol === expected.protocol &&
    actual.hostname === expected.hostname &&
    actual.port === expected.port &&
    actual.username === "" &&
    actual.password === "" &&
    actual.pathname === expected.pathname
  );
}

function validateUpstreams(upstreams, allowTestUpstreams) {
  const actual = {
    openai: normalizeBaseUrl(upstreams.openai),
    solov: normalizeBaseUrl(upstreams.solov),
  };

  if (allowTestUpstreams) {
    const expectedTestHosts = {
      openai: "openai.test",
      solov: "solov.test",
    };
    for (const [name, url] of Object.entries(actual)) {
      const isPlainLoopback =
        url.protocol === "http:" && url.hostname === LISTEN_HOST;
      const isTlsConnectFixture =
        url.protocol === "https:" &&
        url.hostname === expectedTestHosts[name] &&
        (url.port === "" || url.port === "443");
      if (
        (!isPlainLoopback && !isTlsConnectFixture) ||
        url.username !== "" ||
        url.password !== ""
      ) {
        throw new Error(
          "Test upstreams must be HTTP on 127.0.0.1 or the fixed TLS test hosts.",
        );
      }
    }
    return actual;
  }

  const expected = {
    openai: normalizeBaseUrl(PRODUCTION_UPSTREAMS.openai),
    solov: normalizeBaseUrl(PRODUCTION_UPSTREAMS.solov),
  };

  if (
    !isSameBase(actual.openai, expected.openai) ||
    !isSameBase(actual.solov, expected.solov)
  ) {
    throw new Error("Production upstream hosts and paths are fixed.");
  }

  return actual;
}

export function validateHttpsProxy(value) {
  if (value === undefined || value === null || value === "") {
    return null;
  }
  if (typeof value !== "string") {
    throw new Error("DUAL_ROUTER_HTTPS_PROXY must be a URL string.");
  }

  let proxy;
  try {
    proxy = new URL(value);
  } catch {
    throw new Error("DUAL_ROUTER_HTTPS_PROXY is not a valid URL.");
  }

  const port = Number(proxy.port);
  if (
    proxy.protocol !== "http:" ||
    proxy.hostname !== LISTEN_HOST ||
    proxy.port === "" ||
    !Number.isInteger(port) ||
    port < 1 ||
    port > 65_535 ||
    proxy.username !== "" ||
    proxy.password !== "" ||
    proxy.pathname !== "/" ||
    proxy.search !== "" ||
    proxy.hash !== ""
  ) {
    throw new Error(
      "DUAL_ROUTER_HTTPS_PROXY must be http://127.0.0.1:<port> with no authentication, path, query, or fragment.",
    );
  }

  return proxy;
}

function appendAllowedPath(base, pathname) {
  if (!ALLOWED_PATHS.has(pathname)) {
    throw new RouterError(404, "unknown_path", "The local router path is not allowed.");
  }

  const url = new URL(base.href);
  url.pathname = `${base.pathname}${pathname}`;
  return url;
}

function safePathnameForLog(pathname) {
  if (typeof pathname !== "string" || !pathname.startsWith("/")) {
    return "MALFORMED";
  }

  // URL.pathname excludes the query string. Bound the remaining untrusted
  // value so a malformed client cannot create oversized or multiline logs.
  const sanitized = pathname.replace(/[\u0000-\u001f\u007f]/g, "?");
  return sanitized.length <= 512
    ? sanitized
    : `${sanitized.slice(0, 512)}...`;
}

function safeHeaderValue(value) {
  if (Array.isArray(value)) {
    return value.join(", ");
  }
  return typeof value === "string" ? value : undefined;
}

function isOpenAiRequestHeaderAllowed(name) {
  return (
    OPENAI_EXACT_REQUEST_HEADERS.has(name) ||
    name.startsWith("oai-") ||
    name.startsWith("openai-") ||
    name.startsWith("x-codex-") ||
    name.startsWith("x-oai-") ||
    name.startsWith("x-openai-") ||
    name.startsWith("x-stainless-")
  );
}

function buildOpenAiHeaders(incomingHeaders, body, contentEncoding) {
  const headers = copyOpenAiRequestHeaders(incomingHeaders);

  headers["content-type"] = "application/json";
  headers["content-length"] = String(body.length);
  if (contentEncoding === "zstd") {
    headers["content-encoding"] = "zstd";
  }
  return headers;
}

function copyOpenAiRequestHeaders(incomingHeaders) {
  const headers = {};
  for (const [rawName, rawValue] of Object.entries(incomingHeaders)) {
    const name = rawName.toLowerCase();
    if (!isOpenAiRequestHeaderAllowed(name)) {
      continue;
    }
    const value = safeHeaderValue(rawValue);
    if (value !== undefined) {
      headers[name] = value;
    }
  }

  return headers;
}

function buildOpenAiCatalogHeaders(incomingHeaders) {
  const headers = copyOpenAiRequestHeaders(incomingHeaders);
  // The catalog must be parsed and merged locally, so request an identity body
  // even when the desktop client accepts compressed responses.
  headers.accept = "application/json";
  headers["accept-encoding"] = "identity";
  return headers;
}

function buildSolovHeaders(incomingHeaders, body, apiKey) {
  const headers = {};
  for (const [rawName, rawValue] of Object.entries(incomingHeaders)) {
    const name = rawName.toLowerCase();
    if (!SOLOV_REQUEST_HEADERS.has(name)) {
      continue;
    }
    const value = safeHeaderValue(rawValue);
    if (value !== undefined) {
      headers[name] = value;
    }
  }

  headers.authorization = `Bearer ${apiKey}`;
  headers["content-type"] = "application/json";
  headers["content-length"] = String(body.length);
  return headers;
}

function copySafeResponseHeaders(upstreamHeaders, response) {
  for (const [rawName, rawValue] of Object.entries(upstreamHeaders)) {
    const name = rawName.toLowerCase();
    if (!EXACT_RESPONSE_HEADERS.has(name) && !name.startsWith("x-ratelimit-")) {
      continue;
    }
    if (rawValue !== undefined) {
      response.setHeader(name, rawValue);
    }
  }
}

function writeJson(response, status, code, message) {
  if (response.headersSent || response.destroyed) {
    response.destroy();
    return;
  }

  const body = Buffer.from(
    JSON.stringify({ error: { code, message } }),
    "utf8",
  );
  response.writeHead(status, {
    "cache-control": "no-store",
    "content-type": "application/json; charset=utf-8",
    "content-length": String(body.length),
  });
  response.end(body);
}

function writeHealth(response) {
  const body = Buffer.from('{"status":"ok"}', "utf8");
  response.writeHead(200, {
    "cache-control": "no-store",
    "content-type": "application/json; charset=utf-8",
    "content-length": String(body.length),
  });
  response.end(body);
}

function isWebSocketResponsesProbe(request, requestUrl) {
  return (
    request.method === "GET" &&
    requestUrl.pathname === "/responses" &&
    requestUrl.search === "" &&
    safeHeaderValue(request.headers.upgrade)?.trim().toLowerCase() ===
      "websocket"
  );
}

function endSocketJson(socket, status, code, message) {
  const body = Buffer.from(
    JSON.stringify({ error: { code, message } }),
    "utf8",
  );
  const statusText = http.STATUS_CODES[status] ?? "Error";
  socket.end(
    Buffer.concat([
      Buffer.from(
        `HTTP/1.1 ${status} ${statusText}\r\n` +
          "Cache-Control: no-store\r\n" +
          "Content-Type: application/json; charset=utf-8\r\n" +
          `Content-Length: ${body.length}\r\n` +
          "Connection: close\r\n\r\n",
        "ascii",
      ),
      body,
    ]),
  );
}

function requireLocalOpenAiAuth(headers) {
  const authorization = safeHeaderValue(headers.authorization);
  if (
    authorization === undefined ||
    !/^(?:Bearer|AgentAssertion)\s+\S+$/.test(authorization)
  ) {
    throw new RouterError(
      401,
      "missing_local_auth",
      "ChatGPT/OpenAI authentication is required by the local router.",
    );
  }
}

function validateModelsQuery(requestUrl) {
  const keys = [...requestUrl.searchParams.keys()];
  if (keys.some((key) => key !== "client_version")) {
    throw new RouterError(404, "unknown_query", "The local router query is not allowed.");
  }

  const versions = requestUrl.searchParams.getAll("client_version");
  if (versions.length > 1) {
    throw new RouterError(400, "invalid_client_version", "Invalid client version query.");
  }
  if (
    versions.length === 1 &&
    (versions[0].length === 0 ||
      versions[0].length > 128 ||
      !/^[A-Za-z0-9._+\-]+$/.test(versions[0]))
  ) {
    throw new RouterError(400, "invalid_client_version", "Invalid client version query.");
  }
}

function writeCatalog(response, catalogBody) {
  response.writeHead(200, {
    "cache-control": "no-store",
    "content-type": "application/json; charset=utf-8",
    "content-length": String(catalogBody.length),
  });
  response.end(catalogBody);
}

function parseLocalSolovCatalog(catalogBody) {
  if (!Buffer.isBuffer(catalogBody)) {
    throw new Error("The local Solov catalog must be a JSON buffer.");
  }
  if (catalogBody.length > MAX_CATALOG_BYTES) {
    throw new Error("The local Solov catalog exceeded the safety limit.");
  }

  let parsed;
  try {
    parsed = JSON.parse(catalogBody.toString("utf8"));
  } catch {
    throw new Error("The model catalog is not valid JSON.");
  }

  if (
    parsed === null ||
    Array.isArray(parsed) ||
    typeof parsed !== "object" ||
    !Array.isArray(parsed.models)
  ) {
    throw new Error("The model catalog does not match the Codex models schema.");
  }

  const upstreamModels = new Set();
  for (const model of parsed.models) {
    if (
      model === null ||
      Array.isArray(model) ||
      typeof model !== "object" ||
      typeof model.slug !== "string" ||
      model.slug.length <= SOLOV_PREFIX.length ||
      model.slug.length > 256 ||
      !model.slug.startsWith(SOLOV_PREFIX)
    ) {
      throw new Error(
        "The local catalog must contain only solov:: model slugs.",
      );
    }

    const upstreamModel = model.slug.slice(SOLOV_PREFIX.length);
    if (upstreamModels.has(upstreamModel)) {
      throw new Error("The local Solov catalog contains duplicate model slugs.");
    }
    upstreamModels.add(upstreamModel);
  }

  return {
    parsed,
    body: Buffer.from(JSON.stringify(parsed), "utf8"),
    upstreamModels,
  };
}

export async function loadCatalogFile(catalogPath) {
  if (typeof catalogPath !== "string" || catalogPath.trim() === "") {
    throw new Error("DUAL_ROUTER_CATALOG must point to models.json.");
  }

  const requestedPath = resolve(catalogPath);
  if (basename(requestedPath).toLowerCase() !== "models.json") {
    throw new Error("DUAL_ROUTER_CATALOG must point to a file named models.json.");
  }

  const canonicalPath = await realpath(requestedPath);
  if (basename(canonicalPath).toLowerCase() !== "models.json") {
    throw new Error("The resolved catalog must be a file named models.json.");
  }
  const metadata = await stat(canonicalPath);
  if (!metadata.isFile() || metadata.size > MAX_CATALOG_BYTES) {
    throw new Error("The model catalog is not a regular file of an allowed size.");
  }

  const raw = await readFile(canonicalPath);
  return parseLocalSolovCatalog(raw).body;
}

export { prepareImageOutputRoot };

function validateContentType(headers) {
  const contentType = safeHeaderValue(headers["content-type"]);
  if (contentType === undefined || !JSON_CONTENT_TYPE.test(contentType)) {
    throw new RouterError(
      415,
      "unsupported_content_type",
      "Only JSON request bodies are accepted.",
    );
  }
}

async function readRequestBody(request, maxBodyBytes) {
  const contentLength = safeHeaderValue(request.headers["content-length"]);
  if (contentLength !== undefined) {
    const parsedLength = Number(contentLength);
    if (!Number.isSafeInteger(parsedLength) || parsedLength < 0) {
      throw new RouterError(400, "invalid_content_length", "Invalid request length.");
    }
    if (parsedLength > maxBodyBytes) {
      throw new RouterError(413, "request_too_large", "The request body is too large.");
    }
  }

  const chunks = [];
  let length = 0;
  for await (const chunk of request) {
    length += chunk.length;
    if (length > maxBodyBytes) {
      throw new RouterError(413, "request_too_large", "The request body is too large.");
    }
    chunks.push(chunk);
  }
  return Buffer.concat(chunks, length);
}

function requestContentEncoding(headers) {
  const value = safeHeaderValue(headers["content-encoding"]);
  if (value === undefined || value.trim() === "" || value.trim().toLowerCase() === "identity") {
    return "identity";
  }
  if (value.trim().toLowerCase() === "zstd") {
    return "zstd";
  }
  throw new RouterError(
    415,
    "unsupported_content_encoding",
    "Only identity and zstd request encodings are accepted.",
  );
}

async function decodeJsonBody(rawBody, encoding, maxDecodedBodyBytes) {
  let decodedBody;
  try {
    decodedBody =
      encoding === "zstd"
        ? await decompressZstd(rawBody, { maxOutputLength: maxDecodedBodyBytes })
        : rawBody;
  } catch {
    throw new RouterError(400, "invalid_zstd", "The zstd request body is invalid.");
  }

  if (decodedBody.length > maxDecodedBodyBytes) {
    throw new RouterError(413, "decoded_body_too_large", "The decoded request is too large.");
  }

  let payload;
  try {
    payload = JSON.parse(decodedBody.toString("utf8"));
  } catch {
    throw new RouterError(400, "invalid_json", "The request body is not valid JSON.");
  }

  if (payload === null || Array.isArray(payload) || typeof payload !== "object") {
    throw new RouterError(400, "invalid_json_object", "The request body must be a JSON object.");
  }

  if (
    typeof payload.model !== "string" ||
    payload.model.length === 0 ||
    payload.model.length > 256
  ) {
    throw new RouterError(400, "invalid_model", "A valid top-level model is required.");
  }

  return payload;
}

function resolveRoute(model, allowedOpenAiModels, allowedSolovModels) {
  if (model.startsWith(SOLOV_PREFIX)) {
    const upstreamModel = model.slice(SOLOV_PREFIX.length);
    if (!allowedSolovModels.has(upstreamModel)) {
      throw new RouterError(
        400,
        "unknown_model",
        "The model is not allowed by the local router.",
      );
    }
    return { name: "solov", upstreamModel };
  }

  if (!allowedOpenAiModels.has(model)) {
    throw new RouterError(
      400,
      "unknown_model",
      "The model is not allowed by the local router.",
    );
  }
  return { name: "openai", upstreamModel: model };
}

function isSolovImageModel(model) {
  return (
    typeof model === "string" &&
    model.startsWith(SOLOV_PREFIX) &&
    SOLOV_IMAGE_GENERATION_MODELS.has(model.slice(SOLOV_PREFIX.length))
  );
}

function resolveSolovImageRoute(model) {
  if (!model.startsWith(SOLOV_PREFIX)) {
    throw new RouterError(
      400,
      "unknown_model",
      "The image model is not allowed by the local router.",
    );
  }

  const upstreamModel = model.slice(SOLOV_PREFIX.length);
  if (!SOLOV_IMAGE_GENERATION_MODELS.has(upstreamModel)) {
    throw new RouterError(
      400,
      "unknown_model",
      "The image model is not allowed by the local router.",
    );
  }

  return { name: "solov", upstreamModel };
}

function extractImagePrompt(payload) {
  if (payload.stream !== true) {
    throw new RouterError(
      400,
      "image_prompt_unsupported",
      "Image picker requests must use Responses streaming.",
    );
  }

  const input = payload.input;
  let prompt;
  if (typeof input === "string") {
    prompt = input;
  } else if (Array.isArray(input)) {
    const userMessages = input.filter(
      (item) =>
        item !== null &&
        !Array.isArray(item) &&
        typeof item === "object" &&
        item.type === "message" &&
        item.role === "user",
    );
    if (userMessages.length === 0) {
      throw new RouterError(
        400,
        "image_prompt_unsupported",
        "A single text-only user message is required for image generation.",
      );
    }

    const latest = userMessages[userMessages.length - 1];
    if (!Array.isArray(latest.content) || latest.content.length === 0) {
      throw new RouterError(
        400,
        "image_prompt_unsupported",
        "A text-only user message is required for image generation.",
      );
    }
    const promptParts = [];
    for (const content of latest.content) {
      if (
        content === null ||
        Array.isArray(content) ||
        typeof content !== "object" ||
        content.type !== "input_text" ||
        typeof content.text !== "string" ||
        content.text.trim().length === 0
      ) {
        throw new RouterError(
          400,
          "image_prompt_unsupported",
          "Image, file, and structured inputs are not supported by this image model route.",
        );
      }
      promptParts.push(content.text);
    }
    prompt = promptParts.join("\n");
  }

  if (
    typeof prompt !== "string" ||
    prompt.trim().length === 0 ||
    prompt.length > MAX_IMAGE_PROMPT_CHARS
  ) {
    throw new RouterError(
      400,
      "image_prompt_unsupported",
      "The image prompt must be non-empty text within 32,000 characters.",
    );
  }
  return prompt;
}

function buildImageGenerationBody(payload, upstreamModel) {
  const prompt = extractImagePrompt(payload);
  return Buffer.from(
    JSON.stringify({
      model: upstreamModel,
      prompt,
      n: 1,
      size: "1024x1024",
      quality: "low",
      output_format: "png",
    }),
    "utf8",
  );
}

function readSolovImageGeneration({
  request,
  response,
  upstreamUrl,
  headers,
  body,
  idleTimeoutMs,
  httpsProxy,
  tlsCa,
  maxBytes,
}) {
  return new Promise((resolvePromise, rejectPromise) => {
    const transport = upstreamUrl.protocol === "https:" ? https : http;
    const requestOptions = upstreamRequestOptions(
      upstreamUrl,
      "POST",
      headers,
      httpsProxy,
      idleTimeoutMs,
      tlsCa,
    );
    const requestAgent = requestOptions.agent;
    let settled = false;
    let upstreamRequest;

    const cleanup = () => {
      request.off("aborted", onClientAborted);
      response.off("close", onClientClosed);
      requestAgent?.destroy();
    };
    const finish = (error, result) => {
      if (settled) {
        return;
      }
      settled = true;
      cleanup();
      if (error) {
        rejectPromise(error);
      } else {
        resolvePromise(result);
      }
    };
    const onClientAborted = () => {
      upstreamRequest?.destroy(new Error("client_aborted"));
    };
    const onClientClosed = () => {
      if (!response.writableEnded) {
        upstreamRequest?.destroy(new Error("client_closed"));
      }
    };

    request.once("aborted", onClientAborted);
    response.once("close", onClientClosed);
    upstreamRequest = transport.request(requestOptions, (upstreamResponse) => {
      const status = upstreamResponse.statusCode ?? 502;
      if (status >= REDIRECT_STATUS_MIN && status <= REDIRECT_STATUS_MAX) {
        upstreamResponse.resume();
        finish(
          new RouterError(
            502,
            "upstream_redirect_blocked",
            "The upstream attempted a redirect, which the local router blocks.",
          ),
        );
        return;
      }

      const chunks = [];
      let length = 0;
      upstreamResponse.on("data", (chunk) => {
        length += chunk.length;
        if (length > maxBytes) {
          upstreamResponse.destroy();
          finish(
            new RouterError(
              502,
              "invalid_image_response",
              "The image response exceeded the local safety limit.",
            ),
          );
          return;
        }
        chunks.push(chunk);
      });
      upstreamResponse.once("end", () => {
        finish(null, {
          status,
          headers: upstreamResponse.headers,
          body: Buffer.concat(chunks, length),
        });
      });
      upstreamResponse.once("error", () => {
        finish(
          new RouterError(
            502,
            "upstream_unavailable",
            "The selected upstream is unavailable.",
          ),
        );
      });
    });
    upstreamRequest.setTimeout(idleTimeoutMs, () => {
      upstreamRequest.destroy(new Error("upstream_idle_timeout"));
    });
    upstreamRequest.once("error", () => {
      finish(
        new RouterError(
          502,
          "upstream_unavailable",
          "The selected upstream is unavailable.",
        ),
      );
    });
    upstreamRequest.end(body);
  });
}

function parseSolovImageResponse(upstreamResult) {
  const contentType = safeHeaderValue(upstreamResult.headers["content-type"]);
  const contentEncoding = safeHeaderValue(
    upstreamResult.headers["content-encoding"],
  );
  if (
    contentType === undefined ||
    !JSON_CONTENT_TYPE.test(contentType) ||
    (contentEncoding !== undefined &&
      contentEncoding.trim() !== "" &&
      contentEncoding.trim().toLowerCase() !== "identity")
  ) {
    throw new RouterError(
      502,
      "invalid_image_response",
      "The image upstream returned an unsupported response.",
    );
  }

  let parsed;
  try {
    parsed = JSON.parse(upstreamResult.body.toString("utf8"));
  } catch {
    throw new RouterError(
      502,
      "invalid_image_response",
      "The image upstream returned invalid JSON.",
    );
  }
  const image = parsed?.data?.[0]?.b64_json;
  if (
    !Array.isArray(parsed?.data) ||
    parsed.data.length !== 1 ||
    typeof image !== "string" ||
    image.length === 0
  ) {
    throw new RouterError(
      502,
      "invalid_image_response",
      "The image upstream did not return exactly one base64 image.",
    );
  }
  if (
    image.length % 4 !== 0 ||
    !/^[A-Za-z0-9+/]*={0,2}$/u.test(image)
  ) {
    throw new RouterError(
      502,
      "invalid_image_response",
      "The image upstream returned invalid base64 data.",
    );
  }
  let decoded;
  try {
    decoded = Buffer.from(image, "base64");
  } catch {
    throw new RouterError(
      502,
      "invalid_image_response",
      "The image upstream returned invalid base64 data.",
    );
  }
  const canonical = decoded.toString("base64");
  if (
    decoded.length < 45 ||
    canonical !== image ||
    !decoded.subarray(0, 8).equals(PNG_SIGNATURE)
  ) {
    throw new RouterError(
      502,
      "invalid_image_response",
      "The image upstream response was not a valid PNG.",
    );
  }
  validatePngStructure(decoded);
  return { bytes: decoded };
}

function validatePngStructure(bytes) {
  let offset = PNG_SIGNATURE.length;
  let chunkIndex = 0;
  let bitDepth;
  let colorType;
  let sawIdat = false;
  let idatEnded = false;
  let sawIend = false;
  let sawPlte = false;
  while (offset < bytes.length) {
    if (bytes.length - offset < 12) {
      throw new RouterError(502, "invalid_image_response", "The image upstream returned an invalid PNG.");
    }
    const length = bytes.readUInt32BE(offset);
    const typeStart = offset + 4;
    const dataStart = offset + 8;
    const dataEnd = dataStart + length;
    const crcEnd = dataEnd + 4;
    if (dataEnd < dataStart || crcEnd > bytes.length) {
      throw new RouterError(502, "invalid_image_response", "The image upstream returned an invalid PNG.");
    }
    const typeBytes = bytes.subarray(typeStart, dataStart);
    const type = typeBytes.toString("ascii");
    if (
      !/^[A-Za-z]{4}$/.test(type) ||
      // The third byte is reserved by PNG and must be uppercase.
      (typeBytes[2] & 0x20) !== 0
    ) {
      throw new RouterError(502, "invalid_image_response", "The image upstream returned an invalid PNG.");
    }
    const isCritical = (typeBytes[0] & 0x20) === 0;
    if (isCritical && !PNG_CRITICAL_CHUNKS.has(type)) {
      throw new RouterError(502, "invalid_image_response", "The image upstream returned an unsupported critical PNG chunk.");
    }
    const expectedCrc = bytes.readUInt32BE(dataEnd);
    const actualCrc = crc32(bytes.subarray(typeStart, dataEnd)) >>> 0;
    if (expectedCrc !== actualCrc) {
      throw new RouterError(502, "invalid_image_response", "The image upstream returned an invalid PNG checksum.");
    }
    if (chunkIndex === 0) {
      if (type !== "IHDR" || length !== 13) {
        throw new RouterError(502, "invalid_image_response", "The image upstream returned an invalid PNG header.");
      }
      const width = bytes.readUInt32BE(dataStart);
      const height = bytes.readUInt32BE(dataStart + 4);
      bitDepth = bytes[dataStart + 8];
      colorType = bytes[dataStart + 9];
      const compressionMethod = bytes[dataStart + 10];
      const filterMethod = bytes[dataStart + 11];
      const interlaceMethod = bytes[dataStart + 12];
      if (
        width < 1 ||
        height < 1 ||
        width > MAX_PNG_DIMENSION ||
        height > MAX_PNG_DIMENSION
      ) {
        throw new RouterError(502, "invalid_image_response", "The image dimensions exceeded the local safety limit.");
      }
      if (
        !PNG_ALLOWED_BIT_DEPTHS.get(colorType)?.has(bitDepth) ||
        compressionMethod !== 0 ||
        filterMethod !== 0 ||
        (interlaceMethod !== 0 && interlaceMethod !== 1)
      ) {
        throw new RouterError(502, "invalid_image_response", "The image upstream returned an invalid PNG header.");
      }
    } else if (type === "IHDR") {
      throw new RouterError(502, "invalid_image_response", "The image upstream returned duplicate PNG headers.");
    }
    if (sawIdat && type !== "IDAT") {
      idatEnded = true;
    }
    if (type === "PLTE") {
      if (
        sawPlte ||
        sawIdat ||
        length < 3 ||
        length > 768 ||
        length % 3 !== 0 ||
        colorType === 0 ||
        colorType === 4 ||
        (colorType === 3 && length / 3 > 2 ** bitDepth)
      ) {
        throw new RouterError(502, "invalid_image_response", "The image upstream returned an invalid PNG palette.");
      }
      sawPlte = true;
    }
    if (type === "IDAT") {
      if (idatEnded || (colorType === 3 && !sawPlte)) {
        throw new RouterError(502, "invalid_image_response", "The image upstream returned invalid PNG image data ordering.");
      }
      sawIdat = true;
    }
    if (type === "IEND") {
      if (length !== 0 || !sawIdat || crcEnd !== bytes.length) {
        throw new RouterError(502, "invalid_image_response", "The image upstream returned an invalid PNG terminator.");
      }
      sawIend = true;
    }
    offset = crcEnd;
    chunkIndex += 1;
  }
  if (!sawIend) {
    throw new RouterError(502, "invalid_image_response", "The image upstream returned an incomplete PNG.");
  }
}

function sameCanonicalPath(left, right) {
  return process.platform === "win32"
    ? left.toLowerCase() === right.toLowerCase()
    : left === right;
}

function metadataIdentity(metadata) {
  return Object.freeze({
    dev: metadata.dev,
    ino: metadata.ino,
    birthtimeMs: metadata.birthtimeMs,
    size: metadata.size,
  });
}

function sameMetadataIdentity(metadata, identity, includeSize = true) {
  return (
    metadata.dev === identity.dev &&
    metadata.ino === identity.ino &&
    metadata.birthtimeMs === identity.birthtimeMs &&
    (!includeSize || metadata.size === identity.size)
  );
}

async function ensureNormalDirectoryTree(requestedRoot) {
  const parsedPath = parse(requestedRoot);
  let current = parsedPath.root;
  const segments = requestedRoot
    .slice(parsedPath.root.length)
    .split(/[\\/]+/u)
    .filter(Boolean);

  const rootMetadata = await lstat(current);
  if (!rootMetadata.isDirectory() || rootMetadata.isSymbolicLink()) {
    throw new Error("The image output path must be on a normal local directory tree.");
  }

  for (const segment of segments) {
    current = join(current, segment);
    try {
      await mkdir(current, { mode: 0o700 });
    } catch (error) {
      if (error?.code !== "EEXIST") {
        throw error;
      }
    }
    const metadata = await lstat(current);
    if (!metadata.isDirectory() || metadata.isSymbolicLink()) {
      throw new Error("The image output path cannot contain links or junctions.");
    }
  }
}

async function prepareImageOutputRoot(outputRoot) {
  if (
    typeof outputRoot !== "string" ||
    !isAbsolute(outputRoot) ||
    /[\u0000-\u001f<>]/u.test(outputRoot)
  ) {
    throw new Error("The image output directory must be a safe absolute path.");
  }
  const requestedRoot = resolve(outputRoot);
  const parsed = parse(requestedRoot);
  if (
    process.platform === "win32" &&
    (!/^[A-Za-z]:[\\/]/u.test(requestedRoot) ||
      requestedRoot.startsWith("\\\\") ||
      requestedRoot.startsWith("\\\\?\\") ||
      requestedRoot.startsWith("\\\\.\\"))
  ) {
    throw new Error("The image output directory must be on a local drive.");
  }
  if (requestedRoot === parsed.root) {
    throw new Error("The image output directory cannot be a drive root.");
  }
  await ensureNormalDirectoryTree(requestedRoot);
  const initialMetadata = await lstat(requestedRoot);
  if (!initialMetadata.isDirectory() || initialMetadata.isSymbolicLink()) {
    throw new Error("The image output location must be a normal directory.");
  }
  await chmod(requestedRoot, 0o700);
  const canonicalRoot = await realpath(requestedRoot);
  const finalMetadata = await lstat(requestedRoot);
  if (
    !sameCanonicalPath(canonicalRoot, requestedRoot) ||
    !finalMetadata.isDirectory() ||
    finalMetadata.isSymbolicLink() ||
    !sameMetadataIdentity(finalMetadata, metadataIdentity(initialMetadata), false)
  ) {
    throw new Error("The image output directory cannot be redirected.");
  }
  const state = Object.freeze({
    requestedRoot,
    canonicalRoot,
    identity: Object.freeze({
      dev: finalMetadata.dev,
      ino: finalMetadata.ino,
      birthtimeMs: finalMetadata.birthtimeMs,
    }),
  });
  preparedImageOutputStates.add(state);
  return state;
}

async function assertImageOutputRoot(outputState) {
  const initialMetadata = await lstat(outputState.requestedRoot);
  if (
    !initialMetadata.isDirectory() ||
    initialMetadata.isSymbolicLink() ||
    initialMetadata.dev !== outputState.identity.dev ||
    initialMetadata.ino !== outputState.identity.ino ||
    initialMetadata.birthtimeMs !== outputState.identity.birthtimeMs
  ) {
    throw new Error("image_output_unavailable");
  }
  const currentCanonical = await realpath(outputState.requestedRoot);
  const finalMetadata = await lstat(outputState.requestedRoot);
  if (
    !sameCanonicalPath(currentCanonical, outputState.canonicalRoot) ||
    !finalMetadata.isDirectory() ||
    finalMetadata.isSymbolicLink() ||
    !sameMetadataIdentity(finalMetadata, metadataIdentity(initialMetadata), false)
  ) {
    throw new Error("image_output_unavailable");
  }
}

// Node does not expose a Windows equivalent of openat/unlinkat with a
// directory handle and no-follow flags. The identity checks below fail closed
// for observable replacements, but cannot make an absolute guarantee against
// a same-user reparse-point swap in the microseconds between lstat and unlink.
async function unlinkOwnedImage(outputState, imagePath, identity) {
  try {
    await assertImageOutputRoot(outputState);
    const metadata = await lstat(imagePath);
    if (
      !metadata.isFile() ||
      metadata.isSymbolicLink() ||
      !sameMetadataIdentity(metadata, identity)
    ) {
      return false;
    }
    await unlink(imagePath);
    return true;
  } catch {
    // A mismatch is intentionally left behind. Deleting by pathname after an
    // output-root or file replacement would be less safe than a small leak.
    return false;
  }
}

async function persistGeneratedImage(outputState, bytes) {
  const suffix = randomBytes(16).toString("hex");
  const tempPath = join(outputState.canonicalRoot, `.solov-image-${suffix}.tmp`);
  const finalPath = join(outputState.canonicalRoot, `solov-image-${suffix}.png`);
  let handle;
  let tempIdentity;
  let finalIdentity;
  let finalPublished = false;
  try {
    await assertImageOutputRoot(outputState);
    handle = await open(tempPath, "wx", 0o600);
    await handle.writeFile(bytes);
    await handle.sync();
    const handleMetadata = await handle.stat();
    if (!handleMetadata.isFile() || handleMetadata.size !== bytes.length) {
      throw new Error("image_output_unavailable");
    }
    tempIdentity = metadataIdentity(handleMetadata);
    await handle.close();
    handle = undefined;
    await assertImageOutputRoot(outputState);
    await link(tempPath, finalPath);
    finalPublished = true;
    const finalMetadata = await lstat(finalPath);
    if (
      !finalMetadata.isFile() ||
      finalMetadata.isSymbolicLink() ||
      !sameMetadataIdentity(finalMetadata, tempIdentity)
    ) {
      throw new Error("image_output_unavailable");
    }
    finalIdentity = metadataIdentity(finalMetadata);
    if (!(await unlinkOwnedImage(outputState, tempPath, tempIdentity))) {
      throw new Error("image_output_unavailable");
    }
    const publishedMetadata = await lstat(finalPath);
    if (
      !publishedMetadata.isFile() ||
      publishedMetadata.isSymbolicLink() ||
      publishedMetadata.size !== bytes.length ||
      publishedMetadata.nlink !== 1 ||
      !sameMetadataIdentity(publishedMetadata, finalIdentity)
    ) {
      throw new Error("image_output_unavailable");
    }
    finalIdentity = metadataIdentity(publishedMetadata);
    const canonicalFinal = await realpath(finalPath);
    const expectedPrefix = outputState.canonicalRoot + sep;
    if (
      !sameCanonicalPath(dirname(canonicalFinal), outputState.canonicalRoot) ||
      !sameCanonicalPath(canonicalFinal.slice(0, expectedPrefix.length), expectedPrefix) ||
      !sameCanonicalPath(basename(canonicalFinal), basename(finalPath))
    ) {
      throw new Error("image_output_unavailable");
    }
    return Object.freeze({ path: canonicalFinal, identity: finalIdentity });
  } catch {
    if (handle !== undefined) {
      if (tempIdentity === undefined) {
        const metadata = await handle.stat().catch(() => null);
        if (metadata?.isFile()) {
          tempIdentity = metadataIdentity(metadata);
        }
      }
      await handle.close().catch(() => {});
    }
    if (tempIdentity !== undefined) {
      await unlinkOwnedImage(outputState, tempPath, tempIdentity);
    }
    if (finalPublished && finalIdentity !== undefined) {
      await unlinkOwnedImage(outputState, finalPath, finalIdentity);
    }
    throw new RouterError(
      500,
      "image_output_unavailable",
      "The generated image could not be saved safely.",
    );
  }
}

function writeResponsesImageStream(response, model, imageArtifact, outputState) {
  const suffix = randomBytes(12).toString("hex");
  const responseId = `resp_solov_image_${suffix}`;
  const itemId = `msg_solov_${suffix}`;
  const createdAt = Math.floor(Date.now() / 1000);
  const markdownPath = imageArtifact.path.replaceAll("\\", "/");
  const outputText = `![Generated image](<${markdownPath}>)`;
  const baseResponse = {
    id: responseId,
    object: "response",
    created_at: createdAt,
    status: "in_progress",
    completed_at: null,
    error: null,
    incomplete_details: null,
    instructions: null,
    max_output_tokens: null,
    model,
    output: [],
    parallel_tool_calls: false,
    previous_response_id: null,
    reasoning: null,
    store: false,
    temperature: null,
    text: { format: { type: "text" } },
    tool_choice: "none",
    tools: [],
    top_p: null,
    truncation: "disabled",
    usage: null,
    user: null,
    metadata: {},
  };
  const item = {
    id: itemId,
    type: "message",
    status: "completed",
    role: "assistant",
    content: [
      {
        type: "output_text",
        text: outputText,
        annotations: [],
        logprobs: [],
      },
    ],
  };
  const completed = {
    ...baseResponse,
    status: "completed",
    completed_at: Math.floor(Date.now() / 1000),
    output: [item],
    usage: {
      input_tokens: 0,
      input_tokens_details: { cached_tokens: 0 },
      output_tokens: 0,
      output_tokens_details: { reasoning_tokens: 0 },
      total_tokens: 0,
    },
  };
  const events = [
    { type: "response.created", response: baseResponse, sequence_number: 0 },
    {
      type: "response.output_item.added",
      output_index: 0,
      item,
      sequence_number: 1,
    },
    {
      type: "response.output_item.done",
      output_index: 0,
      item,
      sequence_number: 2,
    },
    { type: "response.completed", response: completed, sequence_number: 3 },
  ];
  let delivered = false;
  const removeIfUndelivered = () => {
    if (!delivered) {
      void unlinkOwnedImage(outputState, imageArtifact.path, imageArtifact.identity);
    }
  };
  response.once("error", removeIfUndelivered);
  response.once("close", removeIfUndelivered);
  response.once("finish", () => {
    delivered = true;
    response.off("error", removeIfUndelivered);
  });
  response.writeHead(200, {
    "cache-control": "no-store",
    "content-type": "text/event-stream; charset=utf-8",
    connection: "keep-alive",
  });
  for (const event of events) {
    response.write(`event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`);
  }
  response.end();
}

function terminalImageFailure(upstreamResult) {
  const failures = new Map([
    [
      400,
      {
        code: "image_provider_bad_request",
        message: "The image provider rejected this request.",
      },
    ],
    [
      401,
      {
        code: "image_provider_authentication_failed",
        message: "The image provider rejected the configured credentials.",
      },
    ],
    [
      403,
      {
        code: "image_provider_access_denied",
        message: "The image provider denied this request. Check provider access and balance.",
      },
    ],
    [
      404,
      {
        code: "image_provider_model_unavailable",
        message: "The selected image model is unavailable from the provider.",
      },
    ],
    [
      409,
      {
        code: "image_provider_conflict",
        message: "The image provider could not accept this request in its current state.",
      },
    ],
    [
      422,
      {
        code: "image_provider_invalid_request",
        message: "The image provider rejected the image request parameters.",
      },
    ],
  ]);
  if (TERMINAL_IMAGE_UPSTREAM_STATUSES.has(upstreamResult.status)) {
    return failures.get(upstreamResult.status);
  }
  return null;
}

function writeResponsesImageFailure(response, model, failure) {
  const suffix = randomBytes(12).toString("hex");
  const createdAt = Math.floor(Date.now() / 1000);
  const baseResponse = {
    id: `resp_solov_image_${suffix}`,
    object: "response",
    created_at: createdAt,
    status: "in_progress",
    completed_at: null,
    error: null,
    incomplete_details: null,
    instructions: null,
    max_output_tokens: null,
    model,
    output: [],
    parallel_tool_calls: false,
    previous_response_id: null,
    reasoning: null,
    store: false,
    temperature: null,
    text: { format: { type: "text" } },
    tool_choice: "none",
    tools: [],
    top_p: null,
    truncation: "disabled",
    usage: null,
    user: null,
    metadata: {},
  };
  const failed = {
    ...baseResponse,
    status: "failed",
    completed_at: Math.floor(Date.now() / 1000),
    error: {
      code: "invalid_prompt",
      message: `${failure.code}: ${failure.message}`,
    },
  };
  const events = [
    { type: "response.created", response: baseResponse, sequence_number: 0 },
    { type: "response.failed", response: failed, sequence_number: 1 },
  ];
  response.writeHead(200, {
    "cache-control": "no-store",
    "content-type": "text/event-stream; charset=utf-8",
    connection: "keep-alive",
  });
  for (const event of events) {
    response.write(`event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`);
  }
  response.end();
}

class FixedConnectProxyAgent extends https.Agent {
  constructor({ proxy, target, idleTimeoutMs, tlsCa }) {
    super({ keepAlive: false, maxSockets: 8 });
    this.proxy = proxy;
    this.target = target;
    this.idleTimeoutMs = idleTimeoutMs;
    this.tlsCa = tlsCa;
  }

  createConnection(options, callback) {
    const requestedHost = options.hostname ?? options.host;
    const requestedPort = Number(options.port ?? 443);
    const targetPort = Number(this.target.port || 443);
    let settled = false;

    const finish = (error, socket) => {
      if (settled) {
        if (error && socket) {
          socket.destroy();
        }
        return;
      }
      settled = true;
      callback(error, socket);
    };

    if (requestedHost !== this.target.hostname || requestedPort !== targetPort) {
      process.nextTick(() => finish(new Error("connect_target_not_allowlisted")));
      return undefined;
    }

    const authority = `${this.target.hostname}:${targetPort}`;
    const connectRequest = http.request({
      hostname: this.proxy.hostname,
      port: this.proxy.port,
      method: "CONNECT",
      path: authority,
      headers: { host: authority },
      agent: false,
    });

    connectRequest.setTimeout(this.idleTimeoutMs, () => {
      connectRequest.destroy(new Error("connect_proxy_timeout"));
    });
    connectRequest.once("error", (error) => finish(error));
    connectRequest.once("connect", (connectResponse, socket, head) => {
      if (connectResponse.statusCode !== 200) {
        socket.destroy();
        finish(new Error("connect_proxy_rejected"));
        return;
      }

      if (head.length > 0) {
        socket.unshift(head);
      }

      const secureSocket = tls.connect({
        socket,
        servername: this.target.hostname,
        rejectUnauthorized: true,
        ca: this.tlsCa,
        ALPNProtocols: ["http/1.1"],
      });
      secureSocket.once("secureConnect", () => finish(null, secureSocket));
      secureSocket.once("error", (error) => finish(error, secureSocket));
    });
    connectRequest.end();
    return undefined;
  }
}

function upstreamRequestOptions(
  url,
  method,
  headers,
  httpsProxy,
  idleTimeoutMs,
  tlsCa,
) {
  const agent =
    httpsProxy !== null && url.protocol === "https:"
      ? new FixedConnectProxyAgent({
          proxy: httpsProxy,
          target: url,
          idleTimeoutMs,
          tlsCa,
        })
      : undefined;

  return {
    protocol: url.protocol,
    hostname: url.hostname,
    port: url.port || undefined,
    method,
    path: `${url.pathname}${url.search}`,
    headers,
    agent,
    rejectUnauthorized: true,
    servername: url.protocol === "https:" ? url.hostname : undefined,
    ca: tlsCa,
  };
}

function buildModelsUpstreamUrl(base, requestUrl) {
  const url = new URL(base.href);
  url.pathname = `${base.pathname}/models`;
  url.search = requestUrl.search;
  return url;
}

function readUpstreamBuffer({
  request,
  response,
  upstreamUrl,
  headers,
  idleTimeoutMs,
  httpsProxy,
  tlsCa,
  maxBytes,
}) {
  return new Promise((resolvePromise, rejectPromise) => {
    const transport = upstreamUrl.protocol === "https:" ? https : http;
    const requestOptions = upstreamRequestOptions(
      upstreamUrl,
      "GET",
      headers,
      httpsProxy,
      idleTimeoutMs,
      tlsCa,
    );
    const requestAgent = requestOptions.agent;
    let settled = false;
    let upstreamRequest;

    const cleanup = () => {
      request.off("aborted", onClientAborted);
      response.off("close", onClientClosed);
      requestAgent?.destroy();
    };
    const finish = (error, result) => {
      if (settled) {
        return;
      }
      settled = true;
      cleanup();
      if (error) {
        rejectPromise(error);
      } else {
        resolvePromise(result);
      }
    };
    const onClientAborted = () => {
      upstreamRequest?.destroy(new Error("client_aborted"));
    };
    const onClientClosed = () => {
      if (!response.writableEnded) {
        upstreamRequest?.destroy(new Error("client_closed"));
      }
    };

    request.once("aborted", onClientAborted);
    response.once("close", onClientClosed);

    upstreamRequest = transport.request(requestOptions, (upstreamResponse) => {
      const status = upstreamResponse.statusCode ?? 502;
      if (status >= REDIRECT_STATUS_MIN && status <= REDIRECT_STATUS_MAX) {
        upstreamResponse.resume();
        finish(
          new RouterError(
            502,
            "upstream_redirect_blocked",
            "The upstream attempted a redirect, which the local router blocks.",
          ),
        );
        return;
      }

      const contentLength = safeHeaderValue(
        upstreamResponse.headers["content-length"],
      );
      if (contentLength !== undefined) {
        const parsedLength = Number(contentLength);
        if (
          !Number.isSafeInteger(parsedLength) ||
          parsedLength < 0 ||
          parsedLength > maxBytes
        ) {
          upstreamResponse.destroy();
          finish(
            new RouterError(
              502,
              "upstream_catalog_too_large",
              "The upstream model catalog exceeded the local safety limit.",
            ),
          );
          return;
        }
      }

      const chunks = [];
      let length = 0;
      upstreamResponse.on("data", (chunk) => {
        length += chunk.length;
        if (length > maxBytes) {
          upstreamResponse.destroy();
          finish(
            new RouterError(
              502,
              "upstream_catalog_too_large",
              "The upstream model catalog exceeded the local safety limit.",
            ),
          );
          return;
        }
        chunks.push(chunk);
      });
      upstreamResponse.once("end", () => {
        finish(null, {
          status,
          headers: upstreamResponse.headers,
          body: Buffer.concat(chunks, length),
        });
      });
      upstreamResponse.once("error", () => {
        finish(
          new RouterError(
            502,
            "upstream_unavailable",
            "The official model catalog is unavailable.",
          ),
        );
      });
    });

    upstreamRequest.setTimeout(idleTimeoutMs, () => {
      upstreamRequest.destroy(new Error("upstream_idle_timeout"));
    });
    upstreamRequest.once("error", () => {
      finish(
        new RouterError(
          502,
          "upstream_unavailable",
          "The official model catalog is unavailable.",
        ),
      );
    });
    upstreamRequest.end();
  });
}

function mergeOfficialAndSolovCatalog(upstreamResult, localCatalog) {
  const contentType = safeHeaderValue(upstreamResult.headers["content-type"]);
  const contentEncoding = safeHeaderValue(
    upstreamResult.headers["content-encoding"],
  );
  if (
    contentType === undefined ||
    !JSON_CONTENT_TYPE.test(contentType) ||
    (contentEncoding !== undefined &&
      contentEncoding.trim() !== "" &&
      contentEncoding.trim().toLowerCase() !== "identity")
  ) {
    throw new RouterError(
      502,
      "invalid_upstream_catalog",
      "The official model catalog response is not parseable JSON.",
    );
  }

  let officialCatalog;
  try {
    officialCatalog = JSON.parse(upstreamResult.body.toString("utf8"));
  } catch {
    throw new RouterError(
      502,
      "invalid_upstream_catalog",
      "The official model catalog response is not valid JSON.",
    );
  }

  if (
    officialCatalog === null ||
    Array.isArray(officialCatalog) ||
    typeof officialCatalog !== "object" ||
    !Array.isArray(officialCatalog.models)
  ) {
    throw new RouterError(
      502,
      "invalid_upstream_catalog",
      "The official model catalog does not match the expected schema.",
    );
  }

  const officialModels = new Set();
  for (const model of officialCatalog.models) {
    if (
      model === null ||
      Array.isArray(model) ||
      typeof model !== "object" ||
      typeof model.slug !== "string" ||
      model.slug.length === 0 ||
      model.slug.length > 256 ||
      model.slug.startsWith(SOLOV_PREFIX)
    ) {
      throw new RouterError(
        502,
        "invalid_upstream_catalog",
        "The official model catalog contains an invalid model entry.",
      );
    }
    officialModels.add(model.slug);
  }

  const mergedCatalog = {
    ...officialCatalog,
    models: [...officialCatalog.models, ...localCatalog.parsed.models],
  };
  const mergedBody = Buffer.from(JSON.stringify(mergedCatalog), "utf8");
  if (mergedBody.length > MAX_CATALOG_BYTES) {
    throw new RouterError(
      502,
      "upstream_catalog_too_large",
      "The merged model catalog exceeded the local safety limit.",
    );
  }

  return { body: mergedBody, officialModels };
}

function replaceSetContents(target, source) {
  target.clear();
  for (const value of source) {
    target.add(value);
  }
}

function writeBufferedUpstreamResponse(response, upstreamResult) {
  copySafeResponseHeaders(upstreamResult.headers, response);
  response.statusCode = upstreamResult.status;
  response.setHeader("content-length", String(upstreamResult.body.length));
  response.end(upstreamResult.body);
}

function proxyToUpstream({
  request,
  response,
  upstreamUrl,
  headers,
  body,
  routeName,
  pathname,
  idleTimeoutMs,
  httpsProxy,
  tlsCa,
  logger,
  startedAt,
}) {
  const transport = upstreamUrl.protocol === "https:" ? https : http;
  const requestOptions = upstreamRequestOptions(
    upstreamUrl,
    "POST",
    headers,
    httpsProxy,
    idleTimeoutMs,
    tlsCa,
  );
  const requestAgent = requestOptions.agent;
  let completed = false;

  const finishLog = (status, outcome) => {
    if (completed) {
      return;
    }
    completed = true;
    requestAgent?.destroy();
    logger({
      event: "proxy_request",
      route: routeName,
      method: "POST",
      path: pathname,
      status,
      outcome,
      duration_ms: Date.now() - startedAt,
    });
  };

  const upstreamRequest = transport.request(
    requestOptions,
    (upstreamResponse) => {
      const status = upstreamResponse.statusCode ?? 502;
      if (status >= REDIRECT_STATUS_MIN && status <= REDIRECT_STATUS_MAX) {
        upstreamResponse.resume();
        writeJson(
          response,
          502,
          "upstream_redirect_blocked",
          "The upstream attempted a redirect, which the local router blocks.",
        );
        finishLog(502, "redirect_blocked");
        return;
      }

      copySafeResponseHeaders(upstreamResponse.headers, response);
      response.statusCode = status;
      response.flushHeaders();

      pipeline(upstreamResponse, response, (error) => {
        if (error) {
          if (!response.destroyed) {
            response.destroy();
          }
          finishLog(status, "stream_error");
          return;
        }
        finishLog(status, "completed");
      });
    },
  );

  upstreamRequest.setTimeout(idleTimeoutMs, () => {
    upstreamRequest.destroy(new Error("upstream_idle_timeout"));
  });

  upstreamRequest.on("error", () => {
    writeJson(
      response,
      502,
      "upstream_unavailable",
      "The selected upstream is unavailable.",
    );
    finishLog(response.headersSent ? response.statusCode : 502, "upstream_error");
  });

  request.once("aborted", () => {
    upstreamRequest.destroy(new Error("client_aborted"));
  });
  response.once("close", () => {
    if (!response.writableEnded) {
      upstreamRequest.destroy(new Error("client_closed"));
    }
  });

  upstreamRequest.end(body);
}

export function createRouter({
  solovApiKey,
  catalogBody = null,
  imageOutputState = null,
  upstreams = PRODUCTION_UPSTREAMS,
  allowTestUpstreams = false,
  allowedOpenAiModels = DEFAULT_OPENAI_MODELS,
  maxBodyBytes = DEFAULT_MAX_BODY_BYTES,
  maxDecodedBodyBytes = DEFAULT_MAX_DECODED_BODY_BYTES,
  maxImageResponseBytes = DEFAULT_MAX_IMAGE_RESPONSE_BYTES,
  upstreamIdleTimeoutMs = DEFAULT_UPSTREAM_IDLE_TIMEOUT_MS,
  httpsProxy,
  testTlsCa,
  logger = (entry) => process.stderr.write(`${JSON.stringify(entry)}\n`),
} = {}) {
  const validatedUpstreams = validateUpstreams(upstreams, allowTestUpstreams);
  const validatedHttpsProxy = validateHttpsProxy(httpsProxy);
  if (testTlsCa !== undefined && !allowTestUpstreams) {
    throw new Error("A custom TLS CA is allowed only for test upstreams.");
  }
  if (
    validatedHttpsProxy !== null &&
    Object.values(validatedUpstreams).some((url) => url.protocol !== "https:")
  ) {
    throw new Error("DUAL_ROUTER_HTTPS_PROXY requires HTTPS upstreams.");
  }
  const tlsCa = allowTestUpstreams ? testTlsCa : undefined;
  const openAiModels = new Set(allowedOpenAiModels);
  const localCatalog = parseLocalSolovCatalog(
    catalogBody === null
      ? Buffer.from('{"models":[]}', "utf8")
      : Buffer.from(catalogBody),
  );
  const solovModels = new Set(localCatalog.upstreamModels);
  const hasImagePickerModels = [...solovModels].some((model) =>
    SOLOV_IMAGE_GENERATION_MODELS.has(model),
  );
  if (
    hasImagePickerModels &&
    (imageOutputState === null ||
      typeof imageOutputState !== "object" ||
      !preparedImageOutputStates.has(imageOutputState))
  ) {
    throw new Error("Image picker models require a prepared output directory.");
  }

  const server = http.createServer(async (request, response) => {
    const startedAt = Date.now();
    let logPath = "MALFORMED";
    try {
      const requestUrl = new URL(request.url ?? "/", "http://127.0.0.1");
      logPath = safePathnameForLog(requestUrl.pathname);

      if (request.method === "GET") {
        if (requestUrl.pathname === "/health" && requestUrl.search === "") {
          writeHealth(response);
          return;
        }

        if (requestUrl.pathname === "/models") {
          validateModelsQuery(requestUrl);
          requireLocalOpenAiAuth(request.headers);
          const upstreamUrl = buildModelsUpstreamUrl(
            validatedUpstreams.openai,
            requestUrl,
          );
          const upstreamResult = await readUpstreamBuffer({
            request,
            response,
            upstreamUrl,
            headers: buildOpenAiCatalogHeaders(request.headers),
            idleTimeoutMs: upstreamIdleTimeoutMs,
            httpsProxy: validatedHttpsProxy,
            tlsCa,
            maxBytes: MAX_CATALOG_BYTES,
          });

          if (upstreamResult.status !== 200) {
            writeBufferedUpstreamResponse(response, upstreamResult);
            logger({
              event: "proxy_request",
              route: "openai",
              method: "GET",
              path: "/models",
              status: upstreamResult.status,
              outcome: "upstream_status",
              duration_ms: Date.now() - startedAt,
            });
            return;
          }

          const mergedCatalog = mergeOfficialAndSolovCatalog(
            upstreamResult,
            localCatalog,
          );
          // Replace the seed allowlist only after a complete, valid official
          // response has been parsed and the merged response is ready.
          replaceSetContents(openAiModels, mergedCatalog.officialModels);
          writeCatalog(response, mergedCatalog.body);
          logger({
            event: "proxy_request",
            route: "openai",
            method: "GET",
            path: "/models",
            status: 200,
            outcome: "completed",
            duration_ms: Date.now() - startedAt,
          });
          return;
        }

        if (isWebSocketResponsesProbe(request, requestUrl)) {
          throw new RouterError(
            426,
            "websocket_not_supported",
            "WebSocket transport is unavailable; retry with HTTP streaming.",
          );
        }

        throw new RouterError(404, "unknown_path", "The local router path is not allowed.");
      }

      if (request.method !== "POST") {
        throw new RouterError(405, "method_not_allowed", "Only GET and POST are allowed.");
      }

      if (requestUrl.search !== "" || !ALLOWED_PATHS.has(requestUrl.pathname)) {
        throw new RouterError(404, "unknown_path", "The local router path is not allowed.");
      }
      requireLocalOpenAiAuth(request.headers);
      validateContentType(request.headers);
      const encoding = requestContentEncoding(request.headers);
      const rawBody = await readRequestBody(request, maxBodyBytes);
      const payload = await decodeJsonBody(rawBody, encoding, maxDecodedBodyBytes);
      const route =
        requestUrl.pathname === "/images/generations"
          ? resolveSolovImageRoute(payload.model)
          : resolveRoute(payload.model, openAiModels, solovModels);

      if (
        requestUrl.pathname === "/responses" &&
        isSolovImageModel(payload.model)
      ) {
        if (typeof solovApiKey !== "string" || solovApiKey.length === 0) {
          throw new RouterError(
            503,
            "solov_not_configured",
            "The Solov route is not configured.",
          );
        }
        const imageBody = buildImageGenerationBody(payload, route.upstreamModel);
        const imageUpstreamUrl = appendAllowedPath(
          validatedUpstreams.solov,
          "/images/generations",
        );
        const upstreamResult = await readSolovImageGeneration({
          request,
          response,
          upstreamUrl: imageUpstreamUrl,
          headers: buildSolovHeaders(request.headers, imageBody, solovApiKey),
          body: imageBody,
          idleTimeoutMs: upstreamIdleTimeoutMs,
          httpsProxy: validatedHttpsProxy,
          tlsCa,
          maxBytes: maxImageResponseBytes,
        });
        if (upstreamResult.status !== 200) {
          const terminalFailure = terminalImageFailure(upstreamResult);
          if (terminalFailure !== null) {
            writeResponsesImageFailure(response, payload.model, terminalFailure);
            logger({
              event: "proxy_request",
              route: "solov_image",
              method: "POST",
              path: "/responses",
              status: upstreamResult.status,
              outcome: "terminal_upstream_status",
              duration_ms: Date.now() - startedAt,
            });
            return;
          }
          writeBufferedUpstreamResponse(response, upstreamResult);
          logger({
            event: "proxy_request",
            route: "solov_image",
            method: "POST",
            path: "/responses",
            status: upstreamResult.status,
            outcome: "upstream_status",
            duration_ms: Date.now() - startedAt,
          });
          return;
        }
        const imageResult = parseSolovImageResponse(upstreamResult);
        const imageArtifact = await persistGeneratedImage(
          imageOutputState,
          imageResult.bytes,
        );
        if (request.aborted || (response.destroyed && !response.writableEnded)) {
          await unlinkOwnedImage(
            imageOutputState,
            imageArtifact.path,
            imageArtifact.identity,
          );
          return;
        }
        try {
          writeResponsesImageStream(
            response,
            payload.model,
            imageArtifact,
            imageOutputState,
          );
        } catch (error) {
          await unlinkOwnedImage(
            imageOutputState,
            imageArtifact.path,
            imageArtifact.identity,
          );
          throw error;
        }
        logger({
          event: "proxy_request",
          route: "solov_image",
          method: "POST",
          path: "/responses",
          status: 200,
          outcome: "completed",
          duration_ms: Date.now() - startedAt,
        });
        return;
      }

      if (route.name === "solov" && requestUrl.pathname === "/responses/compact") {
        throw new RouterError(
          501,
          "solov_compaction_unverified",
          "Solov compaction is disabled until protocol compatibility is verified.",
        );
      }

      let outboundBody;
      let outboundHeaders;
      if (route.name === "openai") {
        outboundBody = rawBody;
        outboundHeaders = buildOpenAiHeaders(request.headers, outboundBody, encoding);
      } else {
        if (typeof solovApiKey !== "string" || solovApiKey.length === 0) {
          throw new RouterError(
            503,
            "solov_not_configured",
            "The Solov route is not configured.",
          );
        }
        payload.model = route.upstreamModel;
        outboundBody = Buffer.from(JSON.stringify(payload), "utf8");
        outboundHeaders = buildSolovHeaders(
          request.headers,
          outboundBody,
          solovApiKey,
        );
      }

      const upstreamUrl = appendAllowedPath(
        validatedUpstreams[route.name],
        requestUrl.pathname,
      );
      proxyToUpstream({
        request,
        response,
        upstreamUrl,
        headers: outboundHeaders,
        body: outboundBody,
        routeName: route.name,
        pathname: requestUrl.pathname,
        idleTimeoutMs: upstreamIdleTimeoutMs,
        httpsProxy: validatedHttpsProxy,
        tlsCa,
        logger,
        startedAt,
      });
    } catch (error) {
      const routerError =
        error instanceof RouterError
          ? error
          : new RouterError(500, "internal_error", "The local router failed safely.");
      writeJson(
        response,
        routerError.status,
        routerError.code,
        routerError.publicMessage,
      );
      logger({
        event: "router_rejection",
        method: request.method ?? "UNKNOWN",
        // Deliberately log only URL.pathname: never include query parameters,
        // headers, authorization, or request content.
        path: logPath,
        status: routerError.status,
        outcome: routerError.code,
        duration_ms: Date.now() - startedAt,
      });
    }
  });

  server.on("upgrade", (request, socket) => {
    const startedAt = Date.now();
    socket.once("error", () => socket.destroy());
    let logPath = "MALFORMED";
    let status = 404;
    let code = "unknown_path";
    let message = "The local router path is not allowed.";

    try {
      const requestUrl = new URL(request.url ?? "/", "http://127.0.0.1");
      logPath = safePathnameForLog(requestUrl.pathname);
      if (isWebSocketResponsesProbe(request, requestUrl)) {
        status = 426;
        code = "websocket_not_supported";
        message =
          "WebSocket transport is unavailable; retry with HTTP streaming.";
      }
    } catch {
      status = 400;
      code = "malformed_request";
      message = "The local router request is malformed.";
    }

    endSocketJson(socket, status, code, message);
    logger({
      event: "router_rejection",
      method: request.method ?? "UNKNOWN",
      path: logPath,
      status,
      outcome: code,
      duration_ms: Date.now() - startedAt,
    });
  });

  server.on("clientError", (_error, socket) => {
    if (socket.writable) {
      socket.end("HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n");
    }
    logger({
      event: "client_error",
      method: "UNKNOWN",
      path: "UNKNOWN",
      status: 400,
      outcome: "malformed_http",
      duration_ms: 0,
    });
  });

  return server;
}

export function listenRouter(server, port) {
  return new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, LISTEN_HOST, () => {
      server.off("error", reject);
      resolve(server.address());
    });
  });
}

export function closeServer(server) {
  return new Promise((resolve, reject) => {
    server.close((error) => (error ? reject(error) : resolve()));
  });
}
