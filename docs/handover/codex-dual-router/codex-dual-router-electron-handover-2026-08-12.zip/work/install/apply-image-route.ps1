[CmdletBinding()]
param(
    [string]$WorkspaceRoot = 'C:\Users\<USER>\Documents\Codex\2026-08-12\chatgpt-api',
    [string]$InstallRoot = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter',
    [string]$BackupRoot = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\backups\20260812-082045-image-route',
    [int]$Port = 43120
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Assert-File {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Required file not found: $Path"
    }
}

function Assert-Directory {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        throw "Required directory not found: $Path"
    }
}

function Assert-WithinDirectory {
    param([string]$Path, [string]$Parent, [string]$Label)
    $fullPath = [IO.Path]::GetFullPath($Path)
    $fullParent = [IO.Path]::GetFullPath($Parent).TrimEnd('\') + '\'
    if (-not $fullPath.StartsWith($fullParent, [StringComparison]::OrdinalIgnoreCase)) {
        throw "$Label is outside the expected directory: $fullPath"
    }
}

function Assert-NoReparsePoints {
    param([string]$Path, [string]$Label)
    $items = @((Get-Item -LiteralPath $Path -Force)) + @(Get-ChildItem -LiteralPath $Path -Recurse -Force)
    foreach ($item in $items) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "$Label contains a reparse point: $($item.FullName)"
        }
    }
}

function Assert-TreeMatches {
    param([string]$Source, [string]$Target, [string]$Label)
    Assert-Directory $Source
    Assert-Directory $Target
    $sourceFiles = @(
        Get-ChildItem -LiteralPath $Source -Recurse -File -Force |
            ForEach-Object { $_.FullName.Substring($Source.TrimEnd('\').Length + 1) } |
            Sort-Object
    )
    $targetFiles = @(
        Get-ChildItem -LiteralPath $Target -Recurse -File -Force |
            ForEach-Object { $_.FullName.Substring($Target.TrimEnd('\').Length + 1) } |
            Sort-Object
    )
    $difference = @(Compare-Object -ReferenceObject $sourceFiles -DifferenceObject $targetFiles)
    if ($difference.Count -ne 0) {
        throw "$Label file set differs from the source tree."
    }
    foreach ($relativePath in $sourceFiles) {
        $sourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $Source $relativePath)).Hash
        $targetHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $Target $relativePath)).Hash
        if ($sourceHash -cne $targetHash) {
            throw "$Label hash mismatch: $relativePath"
        }
    }
}

function Test-RouterHealth {
    try {
        $health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -Method Get -TimeoutSec 2
        return $health.status -ceq 'ok'
    }
    catch {
        return $false
    }
}

function Get-ValidatedRouterProcess {
    param([string]$Root)
    $pidPath = Join-Path $Root 'run\router.pid'
    $routerEntry = [IO.Path]::GetFullPath((Join-Path $Root 'router\src\main.mjs'))
    Assert-File $pidPath
    $storedPid = 0
    if (-not [int]::TryParse(([IO.File]::ReadAllText($pidPath)).Trim(), [ref]$storedPid)) {
        throw "Invalid router PID file: $pidPath"
    }
    $process = Get-CimInstance Win32_Process -Filter "ProcessId = $storedPid" -ErrorAction SilentlyContinue
    if ($null -eq $process -or $process.Name -ne 'node.exe' -or
        [string]::IsNullOrWhiteSpace($process.CommandLine) -or
        $process.CommandLine.IndexOf($routerEntry, [StringComparison]::OrdinalIgnoreCase) -lt 0) {
        throw "PID $storedPid is not the expected Codex dual router process."
    }
    return $process
}

function Invoke-LocalRejectionCheck {
    param([string]$Path, [string]$Model, [int]$ExpectedStatus)
    $client = [Net.Http.HttpClient]::new()
    $message = $null
    $response = $null
    try {
        $uri = [Uri]::new("http://127.0.0.1:$Port$Path")
        $message = [Net.Http.HttpRequestMessage]::new([Net.Http.HttpMethod]::Post, $uri)
        $message.Headers.Authorization = [Net.Http.Headers.AuthenticationHeaderValue]::new('Bearer', 'local-image-route-preflight')
        $json = @{ model = $Model; prompt = '<SYNTHETIC_REJECTED_INPUT>' } | ConvertTo-Json -Compress
        $message.Content = [Net.Http.StringContent]::new($json, [Text.Encoding]::UTF8, 'application/json')
        $response = $client.SendAsync($message).GetAwaiter().GetResult()
        if ([int]$response.StatusCode -ne $ExpectedStatus) {
            throw "Local rejection check returned $([int]$response.StatusCode), expected ${ExpectedStatus}: $Path"
        }
    }
    finally {
        if ($null -ne $response) { $response.Dispose() }
        if ($null -ne $message) { $message.Dispose() }
        $client.Dispose()
    }
}

$resolvedWorkspace = (Resolve-Path -LiteralPath $WorkspaceRoot).Path
$resolvedInstall = (Resolve-Path -LiteralPath $InstallRoot).Path
$resolvedBackup = (Resolve-Path -LiteralPath $BackupRoot).Path
$expectedInstall = [IO.Path]::GetFullPath('C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter')
if (-not $resolvedInstall.Equals($expectedInstall, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Unexpected installation target: $resolvedInstall"
}
if ($Port -ne 43120) {
    throw 'The production image route must remain on port 43120.'
}

$sourceRouter = Join-Path $resolvedWorkspace 'work\router'
$sourceInstall = Join-Path $resolvedWorkspace 'work\install'
$installedRouter = Join-Path $resolvedInstall 'router'
$installedReadme = Join-Path $resolvedInstall 'README.md'
$installedGenerator = Join-Path $resolvedInstall 'generate-solov-image.ps1'
$stopScript = Join-Path $resolvedInstall 'stop-router.ps1'
$startScript = Join-Path $resolvedInstall 'start-router.ps1'
$backupRouter = Join-Path $resolvedBackup 'router'
$runtimeBackup = Join-Path $resolvedBackup 'router-runtime-before-image-route'
$installReadmeBackup = Join-Path $resolvedBackup 'install-README.md'
$generatorAbsentMarker = Join-Path $resolvedBackup 'generate-solov-image.absent'
$nonce = [Guid]::NewGuid().ToString('N')
$stagingRouter = Join-Path $resolvedInstall ("router.next-$nonce")
$failedRouter = Join-Path $resolvedBackup ("router.failed-$nonce")
$failedGenerator = Join-Path $resolvedBackup ("generate-solov-image.failed-$nonce.ps1")

foreach ($path in @($sourceRouter, $sourceInstall, $installedRouter, $resolvedBackup, $backupRouter)) {
    Assert-Directory $path
}
foreach ($path in @($installedReadme, $stopScript, $startScript, (Join-Path $sourceInstall 'README.md'), (Join-Path $sourceInstall 'generate-solov-image.ps1'))) {
    Assert-File $path
}
foreach ($relativePath in @('package.json', 'README.md', 'src\config.mjs', 'src\main.mjs', 'src\router.mjs', 'test\router.test.mjs')) {
    Assert-File (Join-Path $sourceRouter $relativePath)
    Assert-File (Join-Path $installedRouter $relativePath)
    Assert-File (Join-Path $backupRouter $relativePath)
}

Assert-WithinDirectory -Path $stagingRouter -Parent $resolvedInstall -Label 'Staging router'
Assert-WithinDirectory -Path $runtimeBackup -Parent $resolvedBackup -Label 'Runtime backup'
Assert-WithinDirectory -Path $failedRouter -Parent $resolvedBackup -Label 'Failed router backup'
Assert-WithinDirectory -Path $installedGenerator -Parent $resolvedInstall -Label 'Installed image helper'
Assert-NoReparsePoints -Path $sourceRouter -Label 'Source router'
Assert-NoReparsePoints -Path $installedRouter -Label 'Installed router'
Assert-NoReparsePoints -Path $backupRouter -Label 'Backup router'

if (Test-Path -LiteralPath $stagingRouter) {
    throw "Unexpected staging path already exists: $stagingRouter"
}
if (Test-Path -LiteralPath $runtimeBackup) {
    throw "Runtime backup already exists: $runtimeBackup"
}
if (Test-Path -LiteralPath $installReadmeBackup) {
    throw "Install README backup already exists: $installReadmeBackup"
}
if (Test-Path -LiteralPath $generatorAbsentMarker) {
    throw "Image helper state marker already exists: $generatorAbsentMarker"
}
if (Test-Path -LiteralPath $installedGenerator) {
    throw "Unexpected pre-existing image helper: $installedGenerator"
}
if (-not (Test-RouterHealth)) {
    throw "The current router is not healthy on 127.0.0.1:$Port."
}
$oldProcess = Get-ValidatedRouterProcess -Root $resolvedInstall

$nodePath = (Get-Command node.exe -ErrorAction Stop).Source
Copy-Item -LiteralPath $sourceRouter -Destination $stagingRouter -Recurse
Assert-NoReparsePoints -Path $stagingRouter -Label 'Staging router'
Assert-TreeMatches -Source $sourceRouter -Target $stagingRouter -Label 'Staging router'
foreach ($scriptPath in @('src\config.mjs', 'src\main.mjs', 'src\router.mjs', 'test\router.test.mjs')) {
    & $nodePath --check (Join-Path $stagingRouter $scriptPath)
    if ($LASTEXITCODE -ne 0) {
        throw "Node syntax validation failed: $scriptPath"
    }
}
Push-Location $stagingRouter
try {
    & $nodePath --test --test-concurrency=1
    if ($LASTEXITCODE -ne 0) {
        throw "Staging router tests failed with exit code $LASTEXITCODE."
    }
}
finally {
    Pop-Location
}

Copy-Item -LiteralPath $installedReadme -Destination $installReadmeBackup
[IO.File]::WriteAllText($generatorAbsentMarker, 'absent before image-route installation', [Text.UTF8Encoding]::new($false))

$stopped = $false
$oldMoved = $false
$switched = $false
$supportFilesCopied = $false
try {
    & $stopScript -InstallRoot $resolvedInstall
    $stopped = $true
    for ($attempt = 0; $attempt -lt 40; $attempt++) {
        $oldStillExists = $null -ne (Get-Process -Id $oldProcess.ProcessId -ErrorAction SilentlyContinue)
        if (-not $oldStillExists -and -not (Test-RouterHealth)) {
            break
        }
        Start-Sleep -Milliseconds 100
    }
    if ($null -ne (Get-Process -Id $oldProcess.ProcessId -ErrorAction SilentlyContinue)) {
        throw "The old router process $($oldProcess.ProcessId) did not exit."
    }
    if (Test-RouterHealth) {
        throw "Port $Port still serves a router health response after shutdown."
    }

    Move-Item -LiteralPath $installedRouter -Destination $runtimeBackup
    $oldMoved = $true
    Move-Item -LiteralPath $stagingRouter -Destination $installedRouter
    $switched = $true
    Assert-TreeMatches -Source $sourceRouter -Target $installedRouter -Label 'Installed router'

    Copy-Item -LiteralPath (Join-Path $sourceInstall 'README.md') -Destination $installedReadme -Force
    Copy-Item -LiteralPath (Join-Path $sourceInstall 'generate-solov-image.ps1') -Destination $installedGenerator
    $supportFilesCopied = $true

    & $startScript -InstallRoot $resolvedInstall -Port $Port
    if (-not (Test-RouterHealth)) {
        throw "Installed router is not healthy on 127.0.0.1:$Port."
    }
    $newProcess = Get-ValidatedRouterProcess -Root $resolvedInstall
    Assert-TreeMatches -Source $sourceRouter -Target $installedRouter -Label 'Running router'

    Invoke-LocalRejectionCheck -Path '/images/generations' -Model 'gpt-image-1' -ExpectedStatus 400
    Invoke-LocalRejectionCheck -Path '/images/generations?url=https%3A%2F%2Fattacker.invalid' -Model 'solov::gpt-image-1' -ExpectedStatus 404
    Invoke-LocalRejectionCheck -Path '/images/generations/extra' -Model 'solov::gpt-image-1' -ExpectedStatus 404

    [pscustomobject]@{
        Activated = $true
        Router = "127.0.0.1:$Port"
        RouterProcessId = $newProcess.ProcessId
        ImageEndpoint = "http://127.0.0.1:$Port/images/generations"
        ImageModels = @(
            'solov::gpt-image-1',
            'solov::gpt-image-1.5',
            'solov::gpt-image-2',
            'solov::gpt-image-2-2026-04-21'
        )
        RuntimeBackup = $runtimeBackup
        HelperSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $installedGenerator).Hash
    }
}
catch {
    $activationError = $_
    try {
        if ($switched) {
            & $stopScript -InstallRoot $resolvedInstall -ErrorAction SilentlyContinue
            if (Test-Path -LiteralPath $installedRouter -PathType Container) {
                Move-Item -LiteralPath $installedRouter -Destination $failedRouter
            }
        }
        if ($oldMoved -and (Test-Path -LiteralPath $runtimeBackup -PathType Container)) {
            Move-Item -LiteralPath $runtimeBackup -Destination $installedRouter
        }
        if ($supportFilesCopied) {
            Copy-Item -LiteralPath $installReadmeBackup -Destination $installedReadme -Force
            if (Test-Path -LiteralPath $installedGenerator -PathType Leaf) {
                Move-Item -LiteralPath $installedGenerator -Destination $failedGenerator
            }
        }
        if ($stopped) {
            & $startScript -InstallRoot $resolvedInstall -Port $Port
            if (-not (Test-RouterHealth)) {
                throw 'The restored router did not become healthy.'
            }
            $null = Get-ValidatedRouterProcess -Root $resolvedInstall
        }
    }
    catch {
        throw "Activation failed and automatic rollback also failed. Activation: $($activationError.Exception.Message) Rollback: $($_.Exception.Message)"
    }
    throw "Activation failed; the previous router was restored. $($activationError.Exception.Message)"
}
