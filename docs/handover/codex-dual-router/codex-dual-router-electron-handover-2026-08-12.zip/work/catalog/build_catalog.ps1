[CmdletBinding()]
param(
    [string]$ManifestPath = (Join-Path $PSScriptRoot 'solov-model-manifest.json'),
    [string]$OutputPath = (Join-Path $PSScriptRoot 'model-catalog.json')
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Find-ByteSequence {
    param(
        [byte[]]$Bytes,
        [byte[]]$Needle
    )

    if ($Needle.Length -eq 0) {
        return 0
    }

    $searchOffset = 0
    $lastStart = $Bytes.Length - $Needle.Length
    while ($searchOffset -le $lastStart) {
        $candidate = [Array]::IndexOf($Bytes, [byte]$Needle[0], $searchOffset)
        if ($candidate -lt 0 -or $candidate -gt $lastStart) {
            return -1
        }

        $matched = $true
        for ($index = 1; $index -lt $Needle.Length; $index++) {
            if ($Bytes[$candidate + $index] -ne $Needle[$index]) {
                $matched = $false
                break
            }
        }
        if ($matched) {
            return $candidate
        }
        $searchOffset = $candidate + 1
    }
    return -1
}

function Read-EmbeddedModelCatalog {
    param([string]$CodexExePath)

    $bytes = [System.IO.File]::ReadAllBytes($CodexExePath)
    $marker = [System.Text.Encoding]::UTF8.GetBytes("{`r`n  `"models`": [")
    $start = Find-ByteSequence -Bytes $bytes -Needle $marker
    if ($start -lt 0) {
        throw "Could not find the embedded model catalog in $CodexExePath"
    }

    $depth = 0
    $inString = $false
    $escaped = $false
    $end = -1

    for ($index = $start; $index -lt $bytes.Length; $index++) {
        $value = $bytes[$index]
        if ($inString) {
            if ($escaped) {
                $escaped = $false
            }
            elseif ($value -eq 0x5c) {
                $escaped = $true
            }
            elseif ($value -eq 0x22) {
                $inString = $false
            }
            continue
        }

        if ($value -eq 0x22) {
            $inString = $true
        }
        elseif ($value -eq 0x7b) {
            $depth++
        }
        elseif ($value -eq 0x7d) {
            $depth--
            if ($depth -eq 0) {
                $end = $index
                break
            }
        }
    }

    if ($end -lt $start) {
        throw 'The embedded model catalog did not contain a complete JSON object.'
    }

    $length = $end - $start + 1
    $json = [System.Text.Encoding]::UTF8.GetString($bytes, $start, $length)
    return $json | ConvertFrom-Json -Depth 100
}

function Copy-JsonObject {
    param([object]$InputObject)
    return ($InputObject | ConvertTo-Json -Depth 100 | ConvertFrom-Json -Depth 100)
}

$resolvedManifest = [System.IO.Path]::GetFullPath($ManifestPath)
if (-not (Test-Path -LiteralPath $resolvedManifest -PathType Leaf)) {
    throw "Solov model manifest was not found: $resolvedManifest"
}

$manifest = Get-Content -Raw -LiteralPath $resolvedManifest | ConvertFrom-Json -Depth 20
$includedTextIds = @(
    $manifest.models |
        Where-Object { $_.category -ceq 'text' -and $_.include -eq $true } |
        ForEach-Object { [string]$_.id }
)
$includedImageIds = @(
    $manifest.models |
        Where-Object { $_.category -ceq 'image' -and $_.image_picker_include -eq $true } |
        ForEach-Object { [string]$_.id }
)

$textCatalogOrder = @(
    'gpt-5.6-sol',
    'gpt-5.6-terra',
    'gpt-5.5',
    'gpt-5.4',
    'gpt-5.4-mini',
    'gpt-5.3-codex-spark',
    'codex-auto-review'
)
$imageCatalogOrder = @(
    'gpt-image-1',
    'gpt-image-1.5',
    'gpt-image-2',
    'gpt-image-2-2026-04-21'
)

$unexpectedTextIds = @($includedTextIds | Where-Object { $_ -notin $textCatalogOrder })
$missingTextIds = @($textCatalogOrder | Where-Object { $_ -notin $includedTextIds })
$unexpectedImageIds = @($includedImageIds | Where-Object { $_ -notin $imageCatalogOrder })
$missingImageIds = @($imageCatalogOrder | Where-Object { $_ -notin $includedImageIds })
if ($unexpectedTextIds.Count -gt 0 -or $missingTextIds.Count -gt 0 -or
    $unexpectedImageIds.Count -gt 0 -or $missingImageIds.Count -gt 0) {
    throw ('Manifest/build mapping mismatch. Unexpected text: [{0}]. Missing text: [{1}]. Unexpected image: [{2}]. Missing image: [{3}].' -f
        ($unexpectedTextIds -join ', '), ($missingTextIds -join ', '),
        ($unexpectedImageIds -join ', '), ($missingImageIds -join ', '))
}

$sourceByModel = @{
    'gpt-5.6-sol' = 'gpt-5.6-sol'
    'gpt-5.6-terra' = 'gpt-5.6-terra'
    'gpt-5.5' = 'gpt-5.5'
    'gpt-5.4' = 'gpt-5.4'
    'gpt-5.4-mini' = 'gpt-5.4-mini'
    'gpt-5.3-codex-spark' = 'gpt-5.4-mini'
    'codex-auto-review' = 'codex-auto-review'
}

$displayByModel = @{
    'gpt-5.6-sol' = 'GPT-5.6 Sol'
    'gpt-5.6-terra' = 'GPT-5.6 Terra'
    'gpt-5.5' = 'GPT-5.5'
    'gpt-5.4' = 'GPT-5.4'
    'gpt-5.4-mini' = 'GPT-5.4 Mini'
    'gpt-5.3-codex-spark' = 'GPT-5.3 Codex Spark'
    'codex-auto-review' = 'Codex Auto Review'
}
$imageDisplayByModel = @{
    'gpt-image-1' = 'GPT Image 1 · Solov Image'
    'gpt-image-1.5' = 'GPT Image 1.5 · Solov Image'
    'gpt-image-2' = 'GPT Image 2 · Solov Image'
    'gpt-image-2-2026-04-21' = 'GPT Image 2 (2026-04-21) · Solov Image'
}

$package = Get-AppxPackage -Name 'OpenAI.Codex' | Sort-Object Version -Descending | Select-Object -First 1
if ($null -eq $package) {
    throw 'OpenAI.Codex is not installed.'
}

$codexExePath = Join-Path $package.InstallLocation 'app\resources\codex.exe'
if (-not (Test-Path -LiteralPath $codexExePath -PathType Leaf)) {
    throw "Bundled codex.exe was not found at $codexExePath"
}

$embeddedCatalog = Read-EmbeddedModelCatalog -CodexExePath $codexExePath
$outputModels = [System.Collections.Generic.List[object]]::new()

for ($index = 0; $index -lt $textCatalogOrder.Count; $index++) {
    $modelId = $textCatalogOrder[$index]
    $sourceId = $sourceByModel[$modelId]
    $source = $embeddedCatalog.models | Where-Object slug -eq $sourceId | Select-Object -First 1
    if ($null -eq $source) {
        throw "The installed Codex catalog does not contain metadata source $sourceId for Solov model $modelId."
    }

    $model = Copy-JsonObject $source
    $model.slug = 'solov::' + $modelId
    $model.display_name = $displayByModel[$modelId] + ' · Solov'
    $model.description = "Solov Responses route for $modelId."
    $model.visibility = 'list'
    $model.supported_in_api = $true
    $model.priority = 1001 + $index
    $model.availability_nux = $null
    $model.upgrade = $null
    $outputModels.Add($model)
}

$imageMetadataSource = $embeddedCatalog.models | Where-Object slug -eq 'gpt-5.4-mini' | Select-Object -First 1
if ($null -eq $imageMetadataSource) {
    throw 'The installed Codex catalog does not contain gpt-5.4-mini metadata for image picker entries.'
}

for ($index = 0; $index -lt $imageCatalogOrder.Count; $index++) {
    $modelId = $imageCatalogOrder[$index]
    $model = Copy-JsonObject $imageMetadataSource
    $model.slug = 'solov::' + $modelId
    $model.display_name = $imageDisplayByModel[$modelId]
    $model.description = "Solov image generation route for $modelId."
    $model.input_modalities = @('text')
    $model.support_verbosity = $false
    $model.default_verbosity = 'low'
    $model.supports_parallel_tool_calls = $false
    $model.supports_search_tool = $false
    $model.include_skills_usage_instructions = $false
    $model.include_plugin_usage_instructions = $false
    $model.use_responses_lite = $true
    $model.tool_mode = 'code_mode_only'
    $model.experimental_supported_tools = @()
    $model.default_reasoning_level = 'low'
    $model.supported_reasoning_levels = @(
        [pscustomobject]@{
            effort = 'low'
            description = 'Generate an image from the prompt'
        }
    )
    $model.visibility = 'list'
    $model.supported_in_api = $true
    $model.priority = 2001 + $index
    $model.availability_nux = $null
    $model.upgrade = $null
    $outputModels.Add($model)
}

$output = [ordered]@{
    models = @($outputModels)
}

$resolvedOutput = [System.IO.Path]::GetFullPath($OutputPath)
$outputDirectory = Split-Path -Parent $resolvedOutput
if (-not (Test-Path -LiteralPath $outputDirectory -PathType Container)) {
    New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
}

$json = $output | ConvertTo-Json -Depth 100
[System.IO.File]::WriteAllText($resolvedOutput, $json + [Environment]::NewLine, [System.Text.UTF8Encoding]::new($false))

$hash = (Get-FileHash -LiteralPath $resolvedOutput -Algorithm SHA256).Hash
[pscustomobject]@{
    InstalledPackageVersion = $package.Version.ToString()
    BundledCatalogModels = $embeddedCatalog.models.Count
    ManifestModels = $manifest.models.Count
    IncludedSolovModels = $outputModels.Count
    IncludedTextModels = $textCatalogOrder.Count
    IncludedImageModels = $imageCatalogOrder.Count
    ModelIds = @($textCatalogOrder + $imageCatalogOrder)
    OutputPath = $resolvedOutput
    OutputBytes = (Get-Item -LiteralPath $resolvedOutput).Length
    Sha256 = $hash
}
