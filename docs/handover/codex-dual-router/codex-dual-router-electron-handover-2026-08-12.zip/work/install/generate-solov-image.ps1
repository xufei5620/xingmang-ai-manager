[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateNotNullOrEmpty()]
    [string]$Prompt,

    [ValidateSet(
        'solov::gpt-image-1',
        'solov::gpt-image-1.5',
        'solov::gpt-image-2',
        'solov::gpt-image-2-2026-04-21'
    )]
    [string]$Model = 'solov::gpt-image-1',

    [ValidateSet('1024x1024', '1024x1536', '1536x1024')]
    [string]$Size = '1024x1024',

    [ValidateSet('low', 'medium', 'high')]
    [string]$Quality = 'low',

    [Parameter(Mandatory)]
    [string]$OutputPath,

    [int]$Port = 43120,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if ($Prompt.Length -gt 32000) {
    throw 'Prompt exceeds the local 32,000-character safety limit.'
}
if ($Port -lt 1 -or $Port -gt 65535) {
    throw 'Port must be from 1 through 65535.'
}

$resolvedOutput = [IO.Path]::GetFullPath($OutputPath)
if ((Test-Path -LiteralPath $resolvedOutput) -and -not $Force) {
    throw "Output file already exists: $resolvedOutput"
}
$outputDirectory = [IO.Path]::GetDirectoryName($resolvedOutput)
if ([string]::IsNullOrWhiteSpace($outputDirectory)) {
    throw 'OutputPath must include a valid directory.'
}
[IO.Directory]::CreateDirectory($outputDirectory) | Out-Null

$health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -Method Get -TimeoutSec 3
if ($health.status -cne 'ok') {
    throw "The local dual router is not healthy on 127.0.0.1:$Port."
}

$payload = [ordered]@{
    model = $Model
    prompt = $Prompt
    n = 1
    size = $Size
    quality = $Quality
} | ConvertTo-Json -Compress -Depth 10

$started = [Diagnostics.Stopwatch]::StartNew()
$response = Invoke-WebRequest `
    -Uri "http://127.0.0.1:$Port/images/generations" `
    -Method Post `
    -Headers @{ Authorization = 'Bearer <SYNTHETIC_LOCAL_ROUTER_AUTH>' } `
    -ContentType 'application/json' `
    -Body $payload `
    -MaximumRedirection 0 `
    -TimeoutSec 300
$started.Stop()

$result = $response.Content | ConvertFrom-Json -Depth 30
$imageData = $result.data[0].b64_json
if ([string]::IsNullOrWhiteSpace([string]$imageData)) {
    throw 'The image response did not contain data[0].b64_json.'
}
$bytes = [Convert]::FromBase64String([string]$imageData)
if ($bytes.Length -eq 0 -or $bytes.Length -gt 64MB) {
    throw 'The decoded image size is outside the local safety limit.'
}

$outputFormat = if ([string]::IsNullOrWhiteSpace([string]$result.output_format)) {
    'png'
}
else {
    ([string]$result.output_format).ToLowerInvariant()
}
if ($outputFormat -eq 'png') {
    $pngSignature = [byte[]](0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
    if ($bytes.Length -lt $pngSignature.Length) {
        throw 'The decoded PNG is truncated.'
    }
    for ($index = 0; $index -lt $pngSignature.Length; $index++) {
        if ($bytes[$index] -ne $pngSignature[$index]) {
            throw 'The decoded payload does not have a valid PNG signature.'
        }
    }
}

[IO.File]::WriteAllBytes($resolvedOutput, $bytes)

[pscustomobject]@{
    StatusCode = [int]$response.StatusCode
    Model = $Model
    Size = [string]$result.size
    Quality = [string]$result.quality
    OutputFormat = $outputFormat
    OutputPath = $resolvedOutput
    Bytes = $bytes.Length
    Sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $resolvedOutput).Hash
    DurationMilliseconds = $started.ElapsedMilliseconds
}
