export const LISTEN_HOST = "127.0.0.1";
export const DEFAULT_PORT = 43120;

export const PRODUCTION_UPSTREAMS = Object.freeze({
  openai: "https://chatgpt.com/backend-api/codex",
  solov: "https://xm.solov.cc/v1",
});

export const ALLOWED_PATHS = Object.freeze(
  new Set(["/responses", "/responses/compact", "/images/generations"]),
);

export const SOLOV_IMAGE_GENERATION_MODELS = Object.freeze(
  new Set([
    "gpt-image-1",
    "gpt-image-1.5",
    "gpt-image-2",
    "gpt-image-2-2026-04-21",
  ]),
);

// Startup seed used before the first valid official GET /models response.
// After that response, the router atomically replaces this set with the live
// official slugs so newly available subscription models remain switchable.
export const DEFAULT_OPENAI_MODELS = Object.freeze(
  new Set([
    "gpt-5.2",
    "gpt-5.2-codex",
    "gpt-5.3-codex",
    "gpt-5.3-codex-spark",
    "gpt-5.4",
    "gpt-5.4-mini",
    "gpt-5.5",
    "gpt-5.6",
    "gpt-5.6-sol",
    "gpt-5.6-terra",
    "gpt-5.6-luna",
  ]),
);

export const DEFAULT_MAX_BODY_BYTES = 64 * 1024 * 1024;
export const DEFAULT_MAX_DECODED_BODY_BYTES = 128 * 1024 * 1024;
export const DEFAULT_MAX_IMAGE_RESPONSE_BYTES = 64 * 1024 * 1024;
export const DEFAULT_UPSTREAM_IDLE_TIMEOUT_MS = 300_000;

export function parseExplicitModelList(value, fallback) {
  if (value === undefined || value.trim() === "") {
    return new Set(fallback);
  }

  const models = value
    .split(",")
    .map((model) => model.trim())
    .filter(Boolean);

  if (models.length === 0 || models.some((model) => model.length > 256)) {
    throw new Error("The explicit model allowlist is invalid.");
  }

  return new Set(models);
}
