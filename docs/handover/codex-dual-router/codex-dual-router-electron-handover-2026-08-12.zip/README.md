# CodexDualRouter Electron 移植交付包

本包是 2026-08-12 本机实现的脱敏移交副本，目标是供另一个团队评估并移植到 Electron 桌面产品。

先阅读：

1. `HANDOVER-QA.md`：Q1–Q15 事实问答、验证边界和未验证总表。
2. `outputs/Codex双路由与图片模型下拉实现技术交接.md`：架构、协议、安全落盘和部署设计。
3. `outputs/Codex双路由使用与恢复说明.md`：原 Windows 部署与恢复说明。

## 包含内容

- `work/router/`：Node 路由器源码与 37 项单测。
- `work/catalog/`：11 项第三方目录、manifest、构建和验证脚本。
- `work/security/`：29 项回环安全黑盒、真实路由测试启动器及原有测试夹具/说明。
- `work/install/`：当前工作区完整安装工具树。现场实际为 14 个 `.ps1` 加 1 个 README，并非需求文字所称“六个 ps1”；因为要求导出全树，本包如实保留全部文件。
- `work/validate-full-chain-image-event.ps1`、`work/full_chain_image_probe.mjs`：bundled app-server 合成全链。
- `models.json`：正式安装目录与工作区候选在脱敏前 SHA-256 完全一致的目录副本。
- `outputs/`：两份说明文档。
- `SHA256SUMS.txt`：本包逐文件哈希。

## 明确不包含

- `auth.json` 或任何登录凭据；
- `secrets/solov.dpapi` 或任何 DPAPI 密文；
- 真实或合成可用的 API key/token/account/session/thread 值；
- 正式运行日志；
- 真实 prompt、生成图片或图片 Base64 产物；
- `node_modules`、`backups`、`generated-images`、`__pycache__`、运行时临时目录。

## 脱敏说明

源文件只在本交付副本中脱敏，原工作区和正式安装没有修改：

- 所有真实 Windows 用户目录 → `C:\Users\<USER>`；
- 测试认证值、API key 形状、account/session/thread 测试值 → 明确不可用的 `<SYNTHETIC_...>` 占位符；
- 固定测试输入与历史 prompt → `<SYNTHETIC_..._INPUT>`；
- `models.json` 中从 bundled catalog 克隆的 `model_messages` 文本 → `<REDACTED_BUNDLED_MODEL_MESSAGE>`。

目录字段、模型 slug、路由代码和测试逻辑均保留。由于上述脱敏，交付目录文件哈希不应与正式文件哈希逐项相等。

## 本包验证

```powershell
Set-Location .\work\router
npm test

Set-Location ..\..
python .\work\security\router_security_harness.py `
  --router-command node .\work\security\actual_router_test_launcher.mjs
```

交付副本最近结果：

- Node 单测：37 passed，0 failed。
- 安全黑盒：29 passed，0 failed。

两组测试均使用回环伪上游和合成占位符，不读取真实认证、不访问真实第三方、不产生费用。

## 移植注意

不要直接执行 `work/install/` 中的 Windows 正式部署或真实验证脚本。它们是事实材料，其中部分脚本会改配置、注册自启动、启停进程或调用真实上游；应先阅读 `HANDOVER-QA.md`，再由目标 Electron 产品重写平台适配与生命周期管理。
