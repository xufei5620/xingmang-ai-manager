# Codex 双路由本机安装脚本

这些脚本把路由器作为当前 Windows 用户的后台进程运行，并在登录时自动启动。

- `start-router.ps1`：解密本机 DPAPI 密钥并隐藏启动，只监听 `127.0.0.1`。
- `stop-router.ps1`：验证 PID 和命令行后，仅停止本路由器。
- `set-solov-key.ps1`：在交互窗口中安全输入密钥，明文不写入文件或日志。
- `register-autostart.ps1`：写入当前用户的登录启动项。
- `status.ps1`：读取不含敏感信息的健康状态。
- `validate-live-picker.ps1`：用桌面端同版本核心和当前 ChatGPT 登录，分别验证动态合并后的官方、Solov 文字和 Solov 图片菜单。
- `validate-live-responses.ps1`：分别对官方模型和 Solov 模型执行完整响应烟测。
- `generate-solov-image.ps1`：通过本机 `/images/generations` 路由调用 Solov 图片模型并保存 PNG，不接触明文密钥。
- `validate-standby.ps1`：在备用端口验证工作区的新路由和目录，不触碰正式监听端口。
- `validate-live-image-picker.ps1`：正式部署成功后由操作者显式执行一次真实图片生成验收；它会产生第三方 API 费用，因此部署脚本只安装它，绝不在预检或自动部署中调用。
- `apply-catalog-expansion.ps1`：带自动回滚地安装“官方目录原样保留 + Solov 追加”版本。
- `apply-image-route.ps1`：带自动回滚地安装独立 Solov 图片生成路由。
- `apply-image-picker.ps1`：事务安装四个图片下拉项和 Responses-to-Image 转换；先在系统临时目录完成候选测试，`-PreflightOnly` 只读检查正式安装且不会停机或创建备份。正式切换会固定并复核 CAS 基线、创建独立时间戳备份和 SHA-256 清单、整体替换 `router`、最后切换 `models.json`，失败自动回滚。
- `rollback.ps1`：经确认后停止路由器、移除启动项并恢复实施前配置。

安装目标固定为：

`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter`

生成图片目录 `generated-images` 是安装根目录下与 `router`、`backups` 同级的持久数据目录。部署脚本不会备份、移动或清理它，也不会修改 `config.toml`、`auth.json`、加密密钥以及既有的启动、停止和回滚脚本。

图片下拉兼容层会把已经完整验证的 PNG 原子保存到安装目录的 `generated-images`，然后返回桌面端已验证可显示的 assistant Markdown 绝对路径。该目录中的成功图片默认保留，不会在路由器重启、普通更新或配置回滚时自动删除；手动删除会使历史任务里的对应图片失效。

当前验证基线为路由器单元测试 37/37、安全黑盒 29/29。`validate-live-picker.ps1` 将 Solov 项精确分成 7 个文字模型和 4 个图片模型，同时只对实时官方模型使用动态最小数量，不把官方目录固定为某个快照。考虑到 app-server 首次 `model/list` 可能先返回内置缓存、随后才完成远端目录刷新，验证器最多重试 5 次，每次间隔 1 秒，达到预期后立即结束。

当前正式图片下拉事务于 2026-08-12 提交，最终失败重连修复事务备份为 `backups\20260812-123150-image-picker`，初次正式切换备份为 `backups\20260812-121636-image-picker`。部署后菜单验证为官方 7 个、Solov 文字 7 个、Solov 图片 4 个；官方订阅响应成功，但 Solov 文字和图片的真实验收均被上游账户余额以 HTTP 403 拒绝，余额恢复后需重新显式运行 `validate-live-image-picker.ps1`。图片路由现将确定性的 400/401/403/404/409/422 转为非重试 Responses 失败事件；同版本 app-server 的合成 403 只调用一次上游。429、5xx 与网络错误仍可能由客户端重试。
