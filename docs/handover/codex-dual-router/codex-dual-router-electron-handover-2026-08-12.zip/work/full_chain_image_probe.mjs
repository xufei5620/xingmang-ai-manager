import http from "node:http";
import { mkdir, stat, readFile, readdir, realpath } from "node:fs/promises";
import { resolve } from "node:path";

import {
  closeServer,
  createRouter,
  listenRouter,
  prepareImageOutputRoot,
} from "./router/src/router.mjs";

const required = ["PROBE_ROOT"];
for (const name of required) {
  if (typeof process.env[name] !== "string" || process.env[name].length === 0) {
    throw new Error(`${name} is required.`);
  }
}
if (process.env.FULL_CHAIN_PROBE_MODE !== "1") {
  throw new Error("This launcher is test-only.");
}

const probeRoot = resolve(process.env.PROBE_ROOT);
const outputRoot = resolve(probeRoot, "generated-images");
const pngBase64 =
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=";
const syntheticKey = "<SYNTHETIC_API_KEY>";
const syntheticSolovStatus = Number(process.env.PROBE_SOLOV_STATUS ?? "200");
if (![200, 403].includes(syntheticSolovStatus)) {
  throw new Error("PROBE_SOLOV_STATUS must be 200 or 403.");
}
const officialModel = {
  slug: "gpt-5.4-mini",
  display_name: "GPT-5.4 Mini",
  description: "Synthetic official catalog entry",
  visibility: "list",
  supported_in_api: true,
  default_reasoning_level: "low",
  supported_reasoning_levels: [{ effort: "low", description: "Low" }],
  shell_type: "shell_command",
  context_window: 200000,
  max_context_window: 200000,
  model_messages: { instructions_template: "Synthetic instructions" },
};
const localImageModel = {
  ...officialModel,
  slug: "solov::gpt-image-1",
  display_name: "GPT Image 1 · Solov Image",
  description: "Synthetic local image catalog entry",
  input_modalities: ["text"],
  supported_reasoning_levels: [{ effort: "low", description: "Low" }],
  supports_parallel_tool_calls: false,
  supports_search_tool: false,
  use_responses_lite: true,
};

let solovRequestCount = 0;
let capturedSolovRequest = null;
let openAiModelsRequestCount = 0;
const logs = [];

async function readBody(request) {
  const chunks = [];
  for await (const chunk of request) chunks.push(chunk);
  return Buffer.concat(chunks);
}

async function startLoopback(handler) {
  const server = http.createServer(handler);
  await new Promise((resolvePromise, rejectPromise) => {
    server.once("error", rejectPromise);
    server.listen(0, "127.0.0.1", () => {
      server.off("error", rejectPromise);
      resolvePromise();
    });
  });
  const address = server.address();
  return { server, url: `http://127.0.0.1:${address.port}` };
}

await mkdir(probeRoot, { recursive: true });
const openai = await startLoopback(async (request, response) => {
  await readBody(request);
  if (request.method === "GET" && request.url?.startsWith("/openai/models")) {
    openAiModelsRequestCount += 1;
    const body = Buffer.from(JSON.stringify({ models: [officialModel] }));
    response.writeHead(200, {
      "content-type": "application/json",
      "content-length": body.length,
    });
    response.end(body);
    return;
  }
  response.writeHead(404, { "content-type": "application/json" });
  response.end('{"error":"synthetic openai path not found"}');
});

const solov = await startLoopback(async (request, response) => {
  const body = await readBody(request);
  if (request.method === "POST" && request.url === "/solov/images/generations") {
    solovRequestCount += 1;
    capturedSolovRequest = {
      path: request.url,
      authorizationMatchesSyntheticKey:
        request.headers.authorization === `Bearer ${syntheticKey}`,
      chatgptAccountIdAbsent:
        request.headers["chatgpt-account-id"] === undefined,
      payload: (() => {
        const parsed = JSON.parse(body.toString("utf8"));
        return {
          model: parsed.model,
          n: parsed.n,
          size: parsed.size,
          quality: parsed.quality,
          output_format: parsed.output_format,
          promptWasNonEmpty: typeof parsed.prompt === "string" && parsed.prompt.length > 0,
        };
      })(),
    };
    if (syntheticSolovStatus === 403) {
      const responseBody = Buffer.from(
        JSON.stringify({
          error: {
            code: "synthetic-private-upstream-code",
            message: "synthetic private upstream details",
          },
        }),
      );
      response.writeHead(403, {
        "content-type": "application/json",
        "content-length": responseBody.length,
      });
      response.end(responseBody);
      return;
    }
    const responseBody = Buffer.from(
      JSON.stringify({
        created: 1,
        data: [{ b64_json: pngBase64, revised_prompt: "<SYNTHETIC_REVISED_INPUT>" }],
      }),
    );
    response.writeHead(200, {
      "content-type": "application/json",
      "content-length": responseBody.length,
    });
    response.end(responseBody);
    return;
  }
  response.writeHead(404, { "content-type": "application/json" });
  response.end('{"error":"synthetic solov path not found"}');
});

const imageOutputState = await prepareImageOutputRoot(outputRoot);
const router = createRouter({
  solovApiKey: syntheticKey,
  catalogBody: Buffer.from(JSON.stringify({ models: [localImageModel] })),
  imageOutputState,
  upstreams: {
    openai: `${openai.url}/openai`,
    solov: `${solov.url}/solov`,
  },
  allowTestUpstreams: true,
  allowedOpenAiModels: new Set([officialModel.slug]),
  upstreamIdleTimeoutMs: 5_000,
  logger: (entry) => logs.push(entry),
});
const address = await listenRouter(router, 0);

let closing = false;
async function shutdown() {
  if (closing) return;
  closing = true;
  const files = await readdir(outputRoot).catch(() => []);
  const fileDetails = [];
  for (const name of files) {
    const path = resolve(outputRoot, name);
    const canonicalPath = await realpath(path);
    const metadata = await stat(canonicalPath);
    const bytes = await readFile(canonicalPath);
    fileDetails.push({
      name,
      path: canonicalPath,
      bytes: bytes.length,
      pngSignature: bytes.subarray(0, 8).toString("hex"),
      isFile: metadata.isFile(),
    });
  }
  const safeLogs = JSON.stringify(logs);
  const summary = {
    openAiModelsRequestCount,
    solovRequestCount,
    capturedSolovRequest,
    outputRoot: imageOutputState.canonicalRoot,
    files: fileDetails,
    logsContainSyntheticKey: safeLogs.includes(syntheticKey),
    logsContainGeneratedPath: safeLogs.includes("generated-images"),
    logsContainPrivateUpstreamError: safeLogs.includes("synthetic-private-upstream-code"),
  };
  process.stdout.write(`SUMMARY ${JSON.stringify(summary)}\n`);
  await Promise.all([
    closeServer(router),
    closeServer(openai.server),
    closeServer(solov.server),
  ]);
  process.stdin.pause();
  process.exitCode = 0;
}

process.on("SIGINT", () => void shutdown());
process.on("SIGTERM", () => void shutdown());
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  if (chunk.split(/\r?\n/u).some((line) => line === "shutdown")) {
    void shutdown();
  }
});

process.stdout.write(
  `READY ${JSON.stringify({ routerUrl: `http://127.0.0.1:${address.port}`, outputRoot })}\n`,
);
