[CmdletBinding()]
param(
    [string]$InstallRoot = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter',
    [int]$Port = 43120,
    [int]$MinimumOfficialModels = 2,
    [int]$MinimumSolovModels = 1,
    [int]$MinimumSolovTextModels = 0,
    [int]$MinimumSolovImageModels = 0,
    [int]$ExpectedSolovTextModels = -1,
    [int]$ExpectedSolovImageModels = -1,
    [switch]$UseCurrentConfigCopy,
    [string]$CurrentConfigPath = 'C:\Users\<USER>\.codex\config.toml'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Assert-True {
    param(
        [bool]$Condition,
        [string]$Message
    )
    if (-not $Condition) {
        throw $Message
    }
}

function Read-AppServerResponse {
    param(
        [System.Diagnostics.Process]$Process,
        [int]$RequestId,
        [int]$TimeoutMilliseconds = 30000
    )

    $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMilliseconds)
    while ([DateTime]::UtcNow -lt $deadline) {
        $remaining = [Math]::Max(1, [int]($deadline - [DateTime]::UtcNow).TotalMilliseconds)
        $readTask = $Process.StandardOutput.ReadLineAsync()
        if (-not $readTask.Wait($remaining)) {
            throw "Timed out waiting for app-server response id $RequestId."
        }
        $line = $readTask.Result
        if ($null -eq $line) {
            throw "app-server exited before response id $RequestId."
        }
        try {
            $message = $line | ConvertFrom-Json
        }
        catch {
            continue
        }
        $idProperty = $message.PSObject.Properties['id']
        if ($null -ne $idProperty -and $idProperty.Value -eq $RequestId) {
            return $message
        }
    }
    throw "Timed out waiting for app-server response id $RequestId."
}

$health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -Method Get -TimeoutSec 3
Assert-True ($health.status -ceq 'ok') "Router is not healthy on 127.0.0.1:$Port."

$authPath = 'C:\Users\<USER>\.codex\auth.json'
Assert-True (Test-Path -LiteralPath $authPath -PathType Leaf) "Codex login cache was not found: $authPath"

$package = Get-AppxPackage -Name 'OpenAI.Codex' | Sort-Object Version -Descending | Select-Object -First 1
Assert-True ($null -ne $package) 'OpenAI.Codex is not installed.'
$sourceExe = Join-Path $package.InstallLocation 'app\resources\codex.exe'
Assert-True (Test-Path -LiteralPath $sourceExe -PathType Leaf) "Bundled codex.exe not found: $sourceExe"

$tempBase = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
$tempRoot = Join-Path $tempBase ('codex-dual-router-live-' + [Guid]::NewGuid().ToString('N'))
$isolatedHome = Join-Path $tempRoot 'home'
$copiedExe = Join-Path $tempRoot 'codex.exe'
$isolatedConfig = Join-Path $isolatedHome 'config.toml'
$isolatedAuth = Join-Path $isolatedHome 'auth.json'
$process = $null

try {
    [IO.Directory]::CreateDirectory($isolatedHome) | Out-Null
    [IO.File]::WriteAllBytes($copiedExe, [IO.File]::ReadAllBytes($sourceExe))
    [IO.File]::WriteAllBytes($isolatedAuth, [IO.File]::ReadAllBytes($authPath))
    if ($UseCurrentConfigCopy) {
        Assert-True (Test-Path -LiteralPath $CurrentConfigPath -PathType Leaf) "Codex config was not found: $CurrentConfigPath"
        $configText = [IO.File]::ReadAllText($CurrentConfigPath)
        Assert-True (-not ($configText -match '(?m)^\s*model_catalog_json\s*=')) 'The current config still replaces the official catalog with model_catalog_json.'
        Assert-True ($configText -match '(?m)^\s*model_provider\s*=\s*"openai"\s*$') 'The current config must keep model_provider = "openai".'
        if ($configText -match '(?m)^\s*openai_base_url\s*=') {
            $configText = [Text.RegularExpressions.Regex]::Replace(
                $configText,
                '(?m)^\s*openai_base_url\s*=.*$',
                'openai_base_url = "http://127.0.0.1:' + $Port + '"'
            )
        }
        else {
            $configText += "`r`n" + ('openai_base_url = "http://127.0.0.1:{0}"' -f $Port) + "`r`n"
        }
    }
    else {
        $configText = @"
model_provider = "openai"
openai_base_url = "http://127.0.0.1:$Port"
"@
    }
    [IO.File]::WriteAllText($isolatedConfig, $configText, [Text.UTF8Encoding]::new($false))

    $processInfo = [Diagnostics.ProcessStartInfo]::new()
    $processInfo.FileName = $copiedExe
    $processInfo.Arguments = 'app-server'
    $processInfo.WorkingDirectory = $InstallRoot
    $processInfo.UseShellExecute = $false
    $processInfo.CreateNoWindow = $true
    $processInfo.RedirectStandardInput = $true
    $processInfo.RedirectStandardOutput = $true
    $processInfo.RedirectStandardError = $true
    $processInfo.EnvironmentVariables['CODEX_HOME'] = $isolatedHome

    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $processInfo
    Assert-True ($process.Start()) 'Failed to start the isolated Codex app-server.'

    $initialize = [ordered]@{
        id = 1
        method = 'initialize'
        params = [ordered]@{
            clientInfo = [ordered]@{
                name = 'dual-router-live-validator'
                title = 'Dual Router Live Validator'
                version = '1.0.0'
            }
            capabilities = [ordered]@{ experimentalApi = $true }
        }
    } | ConvertTo-Json -Compress -Depth 20
    $process.StandardInput.WriteLine($initialize)
    $process.StandardInput.Flush()
    $initializeResponse = Read-AppServerResponse -Process $process -RequestId 1
    Assert-True ($null -eq $initializeResponse.PSObject.Properties['error']) ('initialize failed: ' + ($initializeResponse | ConvertTo-Json -Compress -Depth 10))

    $process.StandardInput.WriteLine('{"method":"initialized","params":{}}')
    $imageModelIds = @(
        'solov::gpt-image-1',
        'solov::gpt-image-1.5',
        'solov::gpt-image-2',
        'solov::gpt-image-2-2026-04-21'
    )
    $models = @()
    $official = @()
    $solov = @()
    $solovImages = @()
    $solovText = @()
    $modelListAttempts = 5
    for ($attempt = 1; $attempt -le $modelListAttempts; $attempt++) {
        $requestId = 1 + $attempt
        $modelListRequest = [ordered]@{
            id = $requestId
            method = 'model/list'
            params = [ordered]@{
                cursor = $null
                includeHidden = $false
                limit = 200
            }
        } | ConvertTo-Json -Compress -Depth 20
        $process.StandardInput.WriteLine($modelListRequest)
        $process.StandardInput.Flush()

        $modelListResponse = Read-AppServerResponse -Process $process -RequestId $requestId
        Assert-True ($null -eq $modelListResponse.PSObject.Properties['error']) ('model/list failed: ' + ($modelListResponse | ConvertTo-Json -Compress -Depth 10))
        $models = @($modelListResponse.result.data)
        $official = @($models | Where-Object { -not ([string]$_.model).StartsWith('solov::', [StringComparison]::Ordinal) })
        $solov = @($models | Where-Object { ([string]$_.model).StartsWith('solov::', [StringComparison]::Ordinal) })
        $solovImages = @($solov | Where-Object { ([string]$_.model) -cin $imageModelIds })
        $solovText = @($solov | Where-Object { ([string]$_.model) -cnotin $imageModelIds })

        $minimumsReady =
            $official.Count -ge $MinimumOfficialModels -and
            $solov.Count -ge $MinimumSolovModels -and
            $solovText.Count -ge $MinimumSolovTextModels -and
            $solovImages.Count -ge $MinimumSolovImageModels
        $exactTextReady = $ExpectedSolovTextModels -lt 0 -or $solovText.Count -eq $ExpectedSolovTextModels
        $exactImageReady = $ExpectedSolovImageModels -lt 0 -or $solovImages.Count -eq $ExpectedSolovImageModels
        if ($minimumsReady -and $exactTextReady -and $exactImageReady) {
            break
        }
        if ($attempt -lt $modelListAttempts) {
            Start-Sleep -Milliseconds 1000
        }
    }
    $middleDot = [char]0x00B7
    $chatGptRenamedSuffix = ' ' + $middleDot + ' ChatGPT ' + [char]0x8BA2 + [char]0x9605
    $solovSuffix = ' ' + $middleDot + ' Solov'
    $solovImageSuffix = $solovSuffix + ' Image'

    Assert-True ($official.Count -ge $MinimumOfficialModels) "Expected at least $MinimumOfficialModels official models, got $($official.Count)."
    Assert-True ($solov.Count -ge $MinimumSolovModels) "Expected at least $MinimumSolovModels Solov models, got $($solov.Count)."
    Assert-True ($solovText.Count -ge $MinimumSolovTextModels) "Expected at least $MinimumSolovTextModels Solov text models, got $($solovText.Count)."
    Assert-True ($solovImages.Count -ge $MinimumSolovImageModels) "Expected at least $MinimumSolovImageModels Solov image models, got $($solovImages.Count)."
    if ($ExpectedSolovTextModels -ge 0) {
        Assert-True ($solovText.Count -eq $ExpectedSolovTextModels) "Expected exactly $ExpectedSolovTextModels Solov text models, got $($solovText.Count)."
    }
    if ($ExpectedSolovImageModels -ge 0) {
        Assert-True ($solovImages.Count -eq $ExpectedSolovImageModels) "Expected exactly $ExpectedSolovImageModels Solov image models, got $($solovImages.Count)."
    }
    Assert-True (($solovText.Count + $solovImages.Count) -eq $solov.Count) 'Solov text/image classification did not cover every appended model exactly once.'
    Assert-True (-not ($official | Where-Object { ([string]$_.displayName).EndsWith($chatGptRenamedSuffix, [StringComparison]::Ordinal) })) 'An official display name was renamed by the dual router.'
    Assert-True (-not ($solovText | Where-Object { -not ([string]$_.displayName).EndsWith($solovSuffix, [StringComparison]::Ordinal) })) 'A Solov text display name is missing the provider suffix.'
    Assert-True (-not ($solovImages | Where-Object { -not ([string]$_.displayName).EndsWith($solovImageSuffix, [StringComparison]::Ordinal) })) 'A Solov image display name is missing the image-provider suffix.'
    Assert-True ($solovImages.Count -eq (@($solovImages | Select-Object -ExpandProperty model -Unique)).Count) 'The image picker contains duplicate model IDs.'

    [pscustomobject]@{
        RouterStatus = $health.status
        InstalledPackageVersion = $package.Version.ToString()
        AppServerBinaryVersion = (& $copiedExe --version | Out-String).Trim()
        OfficialModels = $official.Count
        SolovModels = $solov.Count
        SolovTextModels = $solovText.Count
        SolovImageModels = $solovImages.Count
        Official = @($official | ForEach-Object { [pscustomobject]@{ Id = $_.model; Name = $_.displayName } })
        SolovText = @($solovText | ForEach-Object { [pscustomobject]@{ Id = $_.model; Name = $_.displayName } })
        SolovImages = @($solovImages | ForEach-Object { [pscustomobject]@{ Id = $_.model; Name = $_.displayName } })
        Solov = @($solov | ForEach-Object { [pscustomobject]@{ Id = $_.model; Name = $_.displayName } })
    }
}
finally {
    if ($null -ne $process -and -not $process.HasExited) {
        Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
        $process.WaitForExit(5000) | Out-Null
    }
    $resolvedTempRoot = [IO.Path]::GetFullPath($tempRoot)
    $expectedPrefix = $tempBase.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $leaf = [IO.Path]::GetFileName($resolvedTempRoot)
    if ($resolvedTempRoot.StartsWith($expectedPrefix, [StringComparison]::OrdinalIgnoreCase) -and
        $leaf.StartsWith('codex-dual-router-live-', [StringComparison]::Ordinal)) {
        [IO.Directory]::Delete($resolvedTempRoot, $true)
    }
}
