# Solov-only Codex model catalog

This folder builds and validates the **third-party-only** catalog that the local dual router appends to Codex's live official model response. It never contains, renames, reorders, or replaces an official OpenAI/ChatGPT model.

The official configuration reference documents `model_catalog_json` as a startup-loaded replacement catalog. Because pointing the desktop directly at a small custom file hides the rest of the official catalog, the final installation must **not** set `model_catalog_json` in `~/.codex/config.toml`. The router instead fetches the official `/models` response unchanged and appends the records generated here.

Official reference: <https://learn.chatgpt.com/docs/config-file/config-reference>

## Current discovery result

`solov-model-manifest.json` records the secret-free result checked against `https://xm.solov.cc/v1/models` and `POST /v1/responses` on 2026-08-12.

- Advertised by Solov: 23 models.
- Text/Responses candidates after excluding image, audio, and Realtime: 17 models.
- Minimal Responses request succeeded: 7 models.
- Advertised text candidates consistently returning HTTP 503 in two attempts: 10 models; these are intentionally absent from the picker until a future recheck succeeds.
- Excluded non-Codex modalities: 6 models.

## Picker entries generated

| Request `model` value | Desktop display name | Metadata source |
| --- | --- | --- |
| `solov::gpt-5.6-sol` | `GPT-5.6 Sol · Solov` | embedded `gpt-5.6-sol` |
| `solov::gpt-5.6-terra` | `GPT-5.6 Terra · Solov` | embedded `gpt-5.6-terra` |
| `solov::gpt-5.5` | `GPT-5.5 · Solov` | embedded `gpt-5.5` |
| `solov::gpt-5.4` | `GPT-5.4 · Solov` | embedded `gpt-5.4` |
| `solov::gpt-5.4-mini` | `GPT-5.4 Mini · Solov` | embedded `gpt-5.4-mini` |
| `solov::gpt-5.3-codex-spark` | `GPT-5.3 Codex Spark · Solov` | embedded `gpt-5.4-mini` compatibility template |
| `solov::codex-auto-review` | `Codex Auto Review · Solov` | embedded `codex-auto-review` |
| `solov::gpt-image-1` | `GPT Image 1 · Solov Image` | embedded `gpt-5.4-mini` compatibility template |
| `solov::gpt-image-1.5` | `GPT Image 1.5 · Solov Image` | embedded `gpt-5.4-mini` compatibility template |
| `solov::gpt-image-2` | `GPT Image 2 · Solov Image` | embedded `gpt-5.4-mini` compatibility template |
| `solov::gpt-image-2-2026-04-21` | `GPT Image 2 (2026-04-21) · Solov Image` | embedded `gpt-5.4-mini` compatibility template |

The `solov::` namespace exists only inside the desktop/router boundary. The router strips it before sending the request to Solov.

The four image entries remain ordinary picker records only at the catalog boundary. When selected, the router converts the final text-only user message into the fixed Solov Image API request, validates the returned PNG completely, publishes it atomically under a random name in the private `generated-images` directory, and returns a desktop-compatible assistant Markdown image reference. The current desktop core parses raw `image_generation_call` events but does not promote them to a visible desktop image item, which is why the validated local-path compatibility layer is required.

The strengthened isolated security harness passes 29/29 checks, including exact text/image classification, identity-header isolation, path-injection resistance, output-root replacement detection, cancellation and invalid-upstream cleanup, concurrent file uniqueness, no temporary-file residue, and log redaction.

## Files

- `solov-model-manifest.json`: all 23 advertised IDs, modality classification, inclusion decision, and safe HTTP smoke result. It contains no credentials or request headers.
- `build_catalog.ps1`: extracts complete model metadata from the installed Codex runtime and generates seven verified text records plus four image-picker records.
- `model-catalog.json`: generated Solov-only catalog consumed by the router merge.
- `validate_catalog.ps1`: rejects unprefixed/official entries, checks text/image metadata and manifest parity, then verifies all generated entries through Codex `0.147` `model/list` in an isolated temporary home.

## Build and validate

```powershell
pwsh -NoProfile -File .\build_catalog.ps1
pwsh -NoProfile -File .\validate_catalog.ps1
```

Use `-SkipRuntime` for JSON-only validation:

```powershell
pwsh -NoProfile -File .\validate_catalog.ps1 -SkipRuntime
```

Nothing in this folder modifies `~/.codex`, authentication, the encrypted Solov key, or the running router.
