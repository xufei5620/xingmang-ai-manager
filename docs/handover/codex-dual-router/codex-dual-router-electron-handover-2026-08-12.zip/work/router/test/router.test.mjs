import assert from "node:assert/strict";
import http from "node:http";
import https from "node:https";
import net from "node:net";
import test from "node:test";
import { once } from "node:events";
import {
  mkdtemp,
  mkdir,
  readFile,
  readdir,
  rm,
  symlink,
  unlink,
  writeFile,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, join } from "node:path";
import { promisify } from "node:util";
import { crc32, zstdCompress, zstdDecompress } from "node:zlib";

import {
  closeServer,
  createRouter,
  listenRouter,
  loadCatalogFile,
  prepareImageOutputRoot,
  validateHttpsProxy,
} from "../src/router.mjs";

const compressZstd = promisify(zstdCompress);
const decompressZstd = promisify(zstdDecompress);
const TEST_SOLOV_CATALOG = Buffer.from(
  JSON.stringify({
    models: [
      { slug: "solov::gpt-solov", display_name: "Solov test" },
      { slug: "solov::gpt-image-1", display_name: "Image test" },
    ],
  }),
);
const TINY_PNG_BASE64 =
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=";

function pngChunk(type, data = Buffer.alloc(0)) {
  const typeBytes = Buffer.from(type, "ascii");
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length);
  const checksum = Buffer.alloc(4);
  checksum.writeUInt32BE(crc32(Buffer.concat([typeBytes, data])) >>> 0);
  return Buffer.concat([length, typeBytes, data, checksum]);
}

function testPng({ bitDepth = 8, colorType = 6, ihdrTail, chunks } = {}) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(1, 0);
  ihdr.writeUInt32BE(1, 4);
  ihdr[8] = bitDepth;
  ihdr[9] = colorType;
  if (ihdrTail !== undefined) {
    ihdrTail.copy(ihdr, 10);
  }
  return Buffer.concat([
    Buffer.from("89504e470d0a1a0a", "hex"),
    pngChunk("IHDR", ihdr),
    ...(chunks ?? [pngChunk("IDAT", Buffer.from([0]))]),
    pngChunk("IEND"),
  ]);
}

// Public, test-only TLS material. It is intentionally embedded so the suite
// can verify certificate/SNI handling on Windows without invoking OpenSSL.
const TEST_TLS_KEY = `-----BEGIN PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCqjJxrOO61NYRQ
70ll/sEeuMKBa5VzWzEB6merONqW9dOfYATH6s6zCTPjTNPRseKP/vQ4SCb7yrhu
VRV5AVCI3SzHrpDPyqJSdRQa8FKpfICHAeynZLov8dYGyrAz8vnj/90zHVddLL04
2KaPxNphGLCtcAIMgjtHTJZuJsvU3kr6y0CJZqAO8ZqQHLBRT1Zq/qYuGUlhfDGh
+FNMNC3hl9/MjfBs3Ri/gge3Zkw18XZusBVv5v7DuJp8+Tj7KC2JWVx7aPp2jnrh
JKIXFU3JylpJ2R6JisqHV89gR6VAH+SXdrDKkOulp2/L3SIfd0kkfXhzs/rY9RyK
cKNG8uUFAgMBAAECggEACoOpWlw5LdzDGoZAsn62gzawGcXQgeXGVgWQfJgrCbwq
tBxO+dA6YVlDj1N7ijr66mu1EgneCrngYupF7PQtdd1E1yP7ni6HkVPRzdNbv+0t
Xfq6ufCAy1c6cv1onYXw7U3R4kaAeKhlxgJn9QcVe3+dLM7HTDl0fsce+GLV6s/r
peR41crs2w50N6GRhvZtIXi8Jjg/6KHG196D2yvZgdKU0VSYeAHNsXofgq178pai
XjFOCXRspgrKAanOiQvwF170IkrpGIRb//lvQfWBrHJVxMpZ04myllisrk82bG/E
hvn9NwKRTHP2LizWEcwHgsLyygfpOEjfMLT7UyMSQQKBgQDmkdGjCqXeNJPzZ/Yc
ZFeo4TNI8Qeg7hO7JOr4PVdl1dnVvXRYPiKIamQyMPPmTHO/hsOaUOjxRVgHK2tB
Z/l1hwFxE9m07f+Y6S+MpHo+LYO3LJJOfaGiHjLVWaCZG5t3PhbEVREvYldABhVN
hc6Kcw4Pv50+Qfje0MRqUpFF1QKBgQC9XBrrDbCPH36KiIlZB4+cpf+j2MkJvR3w
8hmEbn40I7q/Bh5myTpnPE/OQFPcVFLCJyhih/PYU0OS+R1Blwnlsa6QyFSTGkKF
WxGfsqLw54b6L4nEdV+y1LGi+AXaQeecVkePTA2v3S4EFkTumf2mgJ44Fe/3BHeu
Qps39FXKcQKBgQC2BcQ0LMHJbESo0hfvTiAOCMtN+EqHd6xH/9sn4nVOxcbVAF4L
E/J7M1KqdQ73br+qIh/lgZ6EarQV5OclmYnMiKpQtNUYCxPPibeqFmcTEyd6wks2
f+PMcn67A6jPdoYDWxbqJCYO/FnZB3Rl4Q6vKimdsS3X6okojjOhpFFfiQKBgDaK
HMauvre6XnwQL18RKm/379WFTwIbElCfqnHWUUs7L0JtxLveIZAyctn49S50qxF4
rc0TU0xvTvs5/Q8zLYqWzqysxo9H9Pjr7fuNPBke1mWg45FOLS4YzMEfpq/iY49H
2nyPbzHEBsjukRQYDlKyoN+OkfsXslDipkpLeZpBAoGAZ+jff93cnGDamTNxPqJ0
3MspFcg6pn/r7ug4nlG8qlQ7Ae1p1oQ2SNEVSMq4FDNrzoUBjgimBFzbFuqgN7Mu
dzall7tz1IdFXrVPBPNcO0ttQIhpmNw/UAusTErFALOvPwCxMMX3r6MQUJeu8sr9
KHeUiPsdBqysSFUBKu/9XZ4=
-----END PRIVATE KEY-----`;

const TEST_TLS_CERT = `-----BEGIN CERTIFICATE-----
MIIC8TCCAdmgAwIBAgIUTJMo/JqEqdSGpjWNgkiJiFnp3IcwDQYJKoZIhvcNAQEL
BQAwFjEUMBIGA1UEAwwLb3BlbmFpLnRlc3QwHhcNMjYwODEwMjIyMzE5WhcNMzYw
ODA4MjIyMzE5WjAWMRQwEgYDVQQDDAtvcGVuYWkudGVzdDCCASIwDQYJKoZIhvcN
AQEBBQADggEPADCCAQoCggEBAKqMnGs47rU1hFDvSWX+wR64woFrlXNbMQHqZ6s4
2pb1059gBMfqzrMJM+NM09Gx4o/+9DhIJvvKuG5VFXkBUIjdLMeukM/KolJ1FBrw
Uql8gIcB7Kdkui/x1gbKsDPy+eP/3TMdV10svTjYpo/E2mEYsK1wAgyCO0dMlm4m
y9TeSvrLQIlmoA7xmpAcsFFPVmr+pi4ZSWF8MaH4U0w0LeGX38yN8GzdGL+CB7dm
TDXxdm6wFW/m/sO4mnz5OPsoLYlZXHto+naOeuEkohcVTcnKWknZHomKyodXz2BH
pUAf5Jd2sMqQ66Wnb8vdIh93SSR9eHOz+tj1HIpwo0by5QUCAwEAAaM3MDUwIgYD
VR0RBBswGYILb3BlbmFpLnRlc3SCCnNvbG92LnRlc3QwDwYDVR0TAQH/BAUwAwEB
/zANBgkqhkiG9w0BAQsFAAOCAQEAKjNzjUc/66HUSJGJnN8LLyzSyY2z79kgYzjt
dcUxVrUiQRVLj1exbqP61drM39kHE7PrtBBlTTgJvHXJM01+MKRLNUJZQqou+dA1
+WGZw9fbTLbMdT5yYb+QgAUS71AAPgjPEiVnODFCFXVvQeR/b2AK4Waxljz7OBkb
1kiidDJ0Y9hH8euRWq7Y0Jh82p/rNj6fA4MpCXiKrU09XWJXn09vhG4BjNkzSLvp
/s6A48BT0JZO81k5TI8Kt9h4H52m2u7XLjzFgxHU9PSSifc8gCuGY0xnSQYnehp+
v4x7A7GH4/8e0XrCi+R7u79KemHFPRzlqdKSUFbxkxyyo7/TAQ==
-----END CERTIFICATE-----`;

async function readBody(request) {
  const chunks = [];
  for await (const chunk of request) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function startServer(handler) {
  const server = http.createServer(handler);
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      server.off("error", reject);
      resolve();
    });
  });
  const address = server.address();
  return {
    server,
    baseUrl: `http://127.0.0.1:${address.port}`,
  };
}

async function listenLoopback(server) {
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      server.off("error", reject);
      resolve();
    });
  });
  return server.address();
}

async function startTlsServer(handler) {
  const server = https.createServer(
    { key: TEST_TLS_KEY, cert: TEST_TLS_CERT },
    handler,
  );
  const address = await listenLoopback(server);
  return { server, port: address.port };
}

async function startConnectProxy(targetPort) {
  const authorities = [];
  const sockets = new Set();
  const trackSocket = (socket) => {
    sockets.add(socket);
    socket.once("close", () => sockets.delete(socket));
    return socket;
  };

  const server = http.createServer((_request, response) => {
    response.writeHead(405, { connection: "close" });
    response.end();
  });
  server.on("connection", trackSocket);
  server.on("connect", (request, clientSocket, head) => {
    authorities.push(request.url);
    const upstreamSocket = trackSocket(
      net.connect({ host: "127.0.0.1", port: targetPort }),
    );
    upstreamSocket.once("connect", () => {
      clientSocket.write("HTTP/1.1 200 Connection Established\r\n\r\n");
      if (head.length > 0) {
        upstreamSocket.write(head);
      }
      clientSocket.pipe(upstreamSocket);
      upstreamSocket.pipe(clientSocket);
    });
    upstreamSocket.once("error", () => clientSocket.destroy());
    clientSocket.once("error", () => upstreamSocket.destroy());
  });
  const address = await listenLoopback(server);

  return {
    server,
    authorities,
    url: `http://127.0.0.1:${address.port}`,
    async close() {
      for (const socket of sockets) {
        socket.destroy();
      }
      await closeServer(server);
    },
  };
}

async function startProxyFixture({ handler, logger } = {}) {
  const tlsUpstream = await startTlsServer(
    handler ?? ((_request, response) => response.end("tls-upstream")),
  );
  const proxy = await startConnectProxy(tlsUpstream.port);
  const outputRoot = await mkdtemp(join(tmpdir(), "codex-router-images-"));
  const imageOutputState = await prepareImageOutputRoot(outputRoot);
  const router = createRouter({
    solovApiKey: "<SYNTHETIC_SOLOV_AUTH>",
    catalogBody: TEST_SOLOV_CATALOG,
    upstreams: {
      openai: "https://openai.test/openai",
      solov: "https://solov.test/solov",
    },
    allowTestUpstreams: true,
    allowedOpenAiModels: new Set(["gpt-openai"]),
    imageOutputState,
    httpsProxy: proxy.url,
    testTlsCa: TEST_TLS_CERT,
    logger: logger ?? (() => {}),
  });
  const address = await listenRouter(router, 0);

  return {
    router,
    proxy,
    tlsUpstream,
    routerUrl: `http://127.0.0.1:${address.port}`,
    async close() {
      await closeServer(router);
      await proxy.close();
      tlsUpstream.server.closeAllConnections();
      await closeServer(tlsUpstream.server);
      await rm(outputRoot, { recursive: true, force: true });
    },
  };
}

async function startFixture({
  openAiHandler,
  solovHandler,
  solovApiKey = "<SYNTHETIC_SOLOV_AUTH>",
  catalogBody = TEST_SOLOV_CATALOG,
  logger,
} = {}) {
  const openai = await startServer(
    openAiHandler ?? ((_request, response) => response.end("openai")),
  );
  const solov = await startServer(
    solovHandler ?? ((_request, response) => response.end("solov")),
  );
  const outputRoot = await mkdtemp(join(tmpdir(), "codex-router-images-"));
  const imageOutputState = await prepareImageOutputRoot(outputRoot);
  const router = createRouter({
    solovApiKey,
    catalogBody,
    upstreams: {
      openai: `${openai.baseUrl}/openai`,
      solov: `${solov.baseUrl}/solov`,
    },
    allowTestUpstreams: true,
    allowedOpenAiModels: new Set(["gpt-openai"]),
    imageOutputState,
    logger: logger ?? (() => {}),
  });
  const address = await listenRouter(router, 0);
  return {
    router,
    openai,
    solov,
    outputRoot,
    routerUrl: `http://127.0.0.1:${address.port}`,
    async close() {
      await Promise.all([
        closeServer(router),
        closeServer(openai.server),
        closeServer(solov.server),
      ]);
      await rm(outputRoot, { recursive: true, force: true });
    },
  };
}

function request({
  url,
  path = "/responses",
  method = "POST",
  headers = {},
  body = Buffer.alloc(0),
}) {
  const target = new URL(path, url);
  return new Promise((resolve, reject) => {
    const outgoing = http.request(
      {
        hostname: target.hostname,
        port: target.port,
        path: `${target.pathname}${target.search}`,
        method,
        headers,
      },
      async (response) => {
        try {
          resolve({
            status: response.statusCode,
            headers: response.headers,
            body: await readBody(response),
          });
        } catch (error) {
          reject(error);
        }
      },
    );
    outgoing.once("error", reject);
    outgoing.end(body);
  });
}

function jsonHeaders(body, extra = {}) {
  return {
    authorization: "Bearer <SYNTHETIC_CHATGPT_AUTH>",
    "chatgpt-account-id": "<SYNTHETIC_ACCOUNT>",
    "content-type": "application/json",
    "content-length": String(body.length),
    ...extra,
  };
}

test("production upstream override is rejected unless it is an explicit loopback test upstream", () => {
  assert.throws(
    () =>
      createRouter({
        upstreams: {
          openai: "https://example.com/openai",
          solov: "https://xm.solov.cc/v1",
        },
        logger: () => {},
      }),
    /fixed/,
  );
  assert.throws(
    () =>
      createRouter({
        upstreams: {
          openai: "http://localhost:9999/openai",
          solov: "http://127.0.0.1:9998/solov",
        },
        allowTestUpstreams: true,
        logger: () => {},
      }),
    /127\.0\.0\.1/,
  );
});

test("HTTPS proxy configuration accepts only an unauthenticated loopback HTTP URL", () => {
  const proxy = validateHttpsProxy("http://127.0.0.1:10808");
  assert.equal(proxy.hostname, "127.0.0.1");
  assert.equal(proxy.port, "10808");

  for (const invalid of [
    "https://127.0.0.1:10808",
    "http://localhost:10808",
    "http://user:password@127.0.0.1:10808",
    "http://127.0.0.1:10808/path",
    "http://127.0.0.1:10808?query=1",
    "http://127.0.0.1:10808#fragment",
    "http://127.0.0.1",
  ]) {
    assert.throws(() => validateHttpsProxy(invalid), /127\.0\.0\.1:<port>/);
  }
});

test("catalog loader accepts only a bounded Solov-only models.json", async (t) => {
  const directory = await mkdtemp(join(tmpdir(), "codex-router-catalog-"));
  const catalogPath = join(directory, "models.json");
  t.after(async () => {
    await unlink(catalogPath);
    await rm(directory, { recursive: true, force: true });
  });

  await writeFile(
    catalogPath,
    JSON.stringify({
      models: [{ slug: "solov::gpt-solov", display_name: "Test · Solov" }],
    }),
    "utf8",
  );
  assert.deepEqual(JSON.parse(await loadCatalogFile(catalogPath)), {
    models: [{ slug: "solov::gpt-solov", display_name: "Test · Solov" }],
  });

  await writeFile(
    catalogPath,
    JSON.stringify({ models: [{ slug: "gpt-openai" }] }),
    "utf8",
  );
  await assert.rejects(loadCatalogFile(catalogPath), /only solov::/);

  await writeFile(
    catalogPath,
    JSON.stringify({
      models: [{ slug: "solov::duplicate" }, { slug: "solov::duplicate" }],
    }),
    "utf8",
  );
  await assert.rejects(loadCatalogFile(catalogPath), /duplicate/);

  await assert.rejects(
    loadCatalogFile(join(directory, "not-models.json")),
    /named models\.json/,
  );
});

test("router binds only to 127.0.0.1", async (t) => {
  const fixture = await startFixture();
  t.after(() => fixture.close());
  const address = fixture.router.address();
  assert.equal(address.address, "127.0.0.1");
  assert.equal(address.family, "IPv4");
});

test("OpenAI route preserves a valid zstd body and required first-party headers", async (t) => {
  let captured;
  const fixture = await startFixture({
    openAiHandler: async (incoming, response) => {
      captured = {
        url: incoming.url,
        headers: incoming.headers,
        body: await readBody(incoming),
      };
      response.writeHead(200, { "content-type": "application/json" });
      response.end('{"ok":true}');
    },
  });
  t.after(() => fixture.close());

  const payload = Buffer.from(
    JSON.stringify({ model: "gpt-openai", input: "private-prompt" }),
  );
  const compressed = await compressZstd(payload);
  const result = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(compressed, {
      authorization: "AgentAssertion <SYNTHETIC_AGENT_ASSERTION>",
      "content-encoding": "zstd",
      "x-oai-attestation": "fake-attestation",
      "x-codex-turn-state": "fake-turn-state",
      "x-client-request-id": "fake-client-request-id",
      "session-id": "<SYNTHETIC_SESSION>",
      "thread-id": "<SYNTHETIC_THREAD>",
      "x-unrelated-secret": "must-not-forward",
    }),
    body: compressed,
  });

  assert.equal(result.status, 200);
  assert.equal(captured.url, "/openai/responses");
  assert.deepEqual(captured.body, compressed);
  assert.deepEqual(await decompressZstd(captured.body), payload);
  assert.equal(captured.headers["content-encoding"], "zstd");
  assert.equal(captured.headers.authorization, "AgentAssertion <SYNTHETIC_AGENT_ASSERTION>");
  assert.equal(captured.headers["chatgpt-account-id"], "<SYNTHETIC_ACCOUNT>");
  assert.equal(captured.headers["x-oai-attestation"], "fake-attestation");
  assert.equal(captured.headers["x-codex-turn-state"], "fake-turn-state");
  assert.equal(captured.headers["x-client-request-id"], "fake-client-request-id");
  assert.equal(captured.headers["session-id"], "<SYNTHETIC_SESSION>");
  assert.equal(captured.headers["thread-id"], "<SYNTHETIC_THREAD>");
  assert.equal(captured.headers["x-unrelated-secret"], undefined);
});

test("Solov route strips its prefix, removes OpenAI headers, and injects only the Solov bearer", async (t) => {
  let captured;
  const logEntries = [];
  const fixture = await startFixture({
    logger: (entry) => logEntries.push(entry),
    solovHandler: async (incoming, response) => {
      captured = {
        url: incoming.url,
        headers: incoming.headers,
        body: await readBody(incoming),
      };
      response.writeHead(200, { "content-type": "application/json" });
      response.end('{"ok":true}');
    },
  });
  t.after(() => fixture.close());

  const secretPrompt = "content-that-must-not-enter-logs";
  const payload = Buffer.from(
    JSON.stringify({ model: "solov::gpt-solov", input: secretPrompt }),
  );
  const compressed = await compressZstd(payload);
  const result = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(compressed, {
      "content-encoding": "zstd",
      "x-oai-attestation": "fake-attestation",
      "x-codex-turn-state": "fake-turn-state",
      traceparent: "fake-traceparent",
    }),
    body: compressed,
  });

  assert.equal(result.status, 200);
  assert.equal(captured.url, "/solov/responses");
  assert.deepEqual(JSON.parse(captured.body), {
    model: "gpt-solov",
    input: secretPrompt,
  });
  assert.equal(captured.headers.authorization, "Bearer <SYNTHETIC_SOLOV_AUTH>");
  assert.equal(captured.headers["content-encoding"], undefined);
  assert.equal(captured.headers["chatgpt-account-id"], undefined);
  assert.equal(captured.headers["x-oai-attestation"], undefined);
  assert.equal(captured.headers["x-codex-turn-state"], undefined);
  assert.equal(captured.headers.traceparent, undefined);

  const serializedLogs = JSON.stringify(logEntries);
  assert.doesNotMatch(serializedLogs, /fake-chatgpt-token/);
  assert.doesNotMatch(serializedLogs, /<SYNTHETIC_SOLOV_AUTH>/);
  assert.doesNotMatch(serializedLogs, /content-that-must-not-enter-logs/);
  assert.doesNotMatch(serializedLogs, /fake-attestation/);
});

test("image picker model saves a PNG and returns a desktop-consumable Markdown message", async (t) => {
  let captured;
  const logEntries = [];
  const fixture = await startFixture({
    logger: (entry) => logEntries.push(entry),
    solovHandler: async (incoming, response) => {
      captured = {
        url: incoming.url,
        headers: incoming.headers,
        body: JSON.parse(await readBody(incoming)),
      };
      response.writeHead(200, { "content-type": "application/json" });
      response.end(
        JSON.stringify({
          created: 1,
          data: [{ b64_json: TINY_PNG_BASE64 }],
          output_format: "png",
        }),
      );
    },
  });
  t.after(() => fixture.close());

  const privatePrompt = "draw a private blue square\nwith no text";
  const body = Buffer.from(
    JSON.stringify({
      model: "solov::gpt-image-1",
      instructions: "large local instructions that must not reach Solov",
      input: [
        {
          type: "message",
          role: "developer",
          content: [{ type: "input_text", text: "developer context" }],
        },
        {
          type: "message",
          role: "user",
          content: [
            { type: "input_text", text: "draw a private blue square" },
            { type: "input_text", text: "with no text" },
          ],
        },
      ],
      tools: [{ type: "function", name: "must_not_reach_solov" }],
      tool_choice: "auto",
      parallel_tool_calls: false,
      stream: true,
      store: false,
    }),
  );
  const result = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(body, {
      "x-oai-attestation": "must-not-reach-solov",
      "x-codex-turn-state": "must-not-reach-solov",
    }),
    body,
  });

  assert.equal(result.status, 200);
  assert.match(result.headers["content-type"], /^text\/event-stream/);
  assert.deepEqual(captured.body, {
    model: "gpt-image-1",
    prompt: privatePrompt,
    n: 1,
    size: "1024x1024",
    quality: "low",
    output_format: "png",
  });
  assert.equal(captured.url, "/solov/images/generations");
  assert.equal(captured.headers.authorization, "Bearer <SYNTHETIC_SOLOV_AUTH>");
  assert.equal(captured.headers["chatgpt-account-id"], undefined);
  assert.equal(captured.headers["x-oai-attestation"], undefined);
  assert.equal(captured.headers["x-codex-turn-state"], undefined);

  const events = result.body
    .toString("utf8")
    .split("\n\n")
    .filter(Boolean)
    .map((block) => JSON.parse(block.split("\ndata: ")[1]));
  assert.deepEqual(
    events.map((event) => event.type),
    [
      "response.created",
      "response.output_item.added",
      "response.output_item.done",
      "response.completed",
    ],
  );
  const item = events[2].item;
  assert.equal(item.type, "message");
  assert.equal(item.status, "completed");
  assert.equal(item.role, "assistant");
  assert.match(item.id, /^msg_solov_[0-9a-f]{24}$/);
  assert.match(
    item.content[0].text,
    /^!\[Generated image\]\(<.*[\\/]solov-image-[0-9a-f]{32}\.png>\)$/,
  );
  const imagePath = item.content[0].text.slice(
    "![Generated image](<".length,
    -2,
  );
  assert.ok(imagePath.startsWith(fixture.outputRoot.replaceAll("\\", "/")));
  assert.deepEqual(await readFile(imagePath), Buffer.from(TINY_PNG_BASE64, "base64"));
  assert.equal(events[3].response.output[0].content[0].text, item.content[0].text);
  assert.equal(events[3].response.model, "solov::gpt-image-1");
  assert.deepEqual(await readdir(fixture.outputRoot), [basename(imagePath)]);
  assert.doesNotMatch(JSON.stringify(logEntries), /private blue square/);
  assert.doesNotMatch(JSON.stringify(logEntries), /<SYNTHETIC_SOLOV_AUTH>/);
  assert.doesNotMatch(JSON.stringify(logEntries), /solov-image-/);
  assert.doesNotMatch(JSON.stringify(logEntries), /generated-images/);
});

test("image picker accepts an explicit identity Image API response encoding", async (t) => {
  const fixture = await startFixture({
    solovHandler: async (_incoming, response) => {
      response.writeHead(200, {
        "content-type": "application/json",
        "content-encoding": "identity",
      });
      response.end(JSON.stringify({ data: [{ b64_json: TINY_PNG_BASE64 }] }));
    },
  });
  t.after(fixture.close);

  const body = JSON.stringify({
    model: "solov::gpt-image-1",
    input: "identity encoding image",
    stream: true,
  });
  const result = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(body),
    body,
  });
  assert.equal(result.status, 200);
  const events = result.body
    .toString("utf8")
    .split("\n\n")
    .filter(Boolean)
    .map((block) => JSON.parse(block.split("\ndata: ")[1]));
  assert.equal(events[2].item.type, "message");
  assert.match(events[2].item.content[0].text, /solov-image-[0-9a-f]{32}\.png/);
});

test("image picker converts deterministic upstream 4xx failures into terminal Responses SSE", async (t) => {
  const cases = [
    [400, "image_provider_bad_request"],
    [401, "image_provider_authentication_failed"],
    [403, "image_provider_access_denied"],
    [404, "image_provider_model_unavailable"],
    [409, "image_provider_conflict"],
    [422, "image_provider_invalid_request"],
  ];
  for (const [status, expectedCode] of cases) {
    let upstreamHits = 0;
    const logs = [];
    const fixture = await startFixture({
      logger: (entry) => logs.push(entry),
      solovHandler: async (incoming, response) => {
        upstreamHits += 1;
        await readBody(incoming);
        response.writeHead(status, { "content-type": "application/json" });
        response.end(
          JSON.stringify({
            error: {
              code: "private-upstream-code",
              message: "private upstream details must not be forwarded",
            },
          }),
        );
      },
    });
    try {
      const body = JSON.stringify({
        model: "solov::gpt-image-1",
        input: "terminal image failure",
        stream: true,
      });
      const result = await request({
        url: fixture.routerUrl,
        headers: jsonHeaders(body),
        body,
      });
      assert.equal(result.status, 200);
      assert.match(result.headers["content-type"], /^text\/event-stream/);
      const events = result.body
        .toString("utf8")
        .split("\n\n")
        .filter(Boolean)
        .map((block) => JSON.parse(block.split("\ndata: ")[1]));
      assert.deepEqual(events.map((event) => event.type), [
        "response.created",
        "response.failed",
      ]);
      assert.equal(events[1].response.status, "failed");
      assert.equal(events[1].response.error.code, "invalid_prompt");
      assert.match(events[1].response.error.message, new RegExp(`^${expectedCode}: `));
      assert.equal(events[1].response.model, "solov::gpt-image-1");
      assert.equal(upstreamHits, 1);
      assert.deepEqual(await readdir(fixture.outputRoot), []);
      assert.doesNotMatch(result.body.toString("utf8"), /private upstream/i);
      assert.equal(logs.at(-1).status, status);
      assert.equal(logs.at(-1).outcome, "terminal_upstream_status");
      assert.doesNotMatch(JSON.stringify(logs), /private-upstream-code/);
    } finally {
      await fixture.close();
    }
  }
});

test("image picker preserves retryable 429 and 5xx HTTP failure semantics", async (t) => {
  for (const status of [429, 500, 503]) {
    const fixture = await startFixture({
      solovHandler: async (incoming, response) => {
        await readBody(incoming);
        response.writeHead(status, {
          "content-type": "application/json",
          "retry-after": "3",
        });
        response.end(JSON.stringify({ error: { code: "retryable" } }));
      },
    });
    try {
      const body = JSON.stringify({
        model: "solov::gpt-image-1",
        input: "retryable image failure",
        stream: true,
      });
      const result = await request({
        url: fixture.routerUrl,
        headers: jsonHeaders(body),
        body,
      });
      assert.equal(result.status, status);
      assert.equal(result.headers["retry-after"], "3");
    } finally {
      await fixture.close();
    }
  }
});

test("image picker route rejects ambiguous or multimodal prompts before Image API", async (t) => {
  let upstreamHits = 0;
  const fixture = await startFixture({
    solovHandler: async (incoming, response) => {
      upstreamHits += 1;
      await readBody(incoming);
      response.end("unexpected");
    },
  });
  t.after(() => fixture.close());

  const invalidInputs = [
    [],
    [{ type: "message", role: "assistant", content: [] }],
    [{ type: "message", role: "user", content: [] }],
    [
      {
        type: "message",
        role: "user",
        content: [{ type: "input_image", image_url: "data:image/png;base64,AA==" }],
      },
    ],
    [
      {
        type: "message",
        role: "user",
        content: [{ type: "input_file", file_id: "file-secret" }],
      },
    ],
  ];
  for (const input of invalidInputs) {
    const body = Buffer.from(
      JSON.stringify({ model: "solov::gpt-image-1", input, stream: true }),
    );
    const result = await request({
      url: fixture.routerUrl,
      headers: jsonHeaders(body),
      body,
    });
    assert.equal(result.status, 400);
    assert.equal(JSON.parse(result.body).error.code, "image_prompt_unsupported");
  }
  assert.equal(upstreamHits, 0);
});

test("image picker route validates a single PNG and rejects malformed Image API success", async (t) => {
  const invalidResponses = [
    { data: [] },
    { data: [{ b64_json: "not-base64!!!" }] },
    { data: [{ b64_json: Buffer.from("not a png").toString("base64") }] },
    { data: [{ b64_json: TINY_PNG_BASE64 }, { b64_json: TINY_PNG_BASE64 }] },
  ];
  for (const invalid of invalidResponses) {
    const fixture = await startFixture({
      solovHandler: async (incoming, response) => {
        await readBody(incoming);
        response.writeHead(200, { "content-type": "application/json" });
        response.end(JSON.stringify(invalid));
      },
    });
    try {
      const body = Buffer.from(
        JSON.stringify({
          model: "solov::gpt-image-1",
          input: "test",
          stream: true,
        }),
      );
      const result = await request({
        url: fixture.routerUrl,
        headers: jsonHeaders(body),
        body,
      });
      assert.equal(result.status, 502);
      assert.equal(JSON.parse(result.body).error.code, "invalid_image_response");
    } finally {
      await fixture.close();
    }
  }
});

test("image picker rejects unsafe PNG semantics and critical chunk ordering", async (t) => {
  const invalidPngs = [
    testPng({ bitDepth: 4, colorType: 2 }),
    testPng({ ihdrTail: Buffer.from([1, 0, 0]) }),
    testPng({ ihdrTail: Buffer.from([0, 1, 0]) }),
    testPng({ ihdrTail: Buffer.from([0, 0, 2]) }),
    testPng({
      chunks: [
        pngChunk("IDAT", Buffer.from([0])),
        pngChunk("tEXt", Buffer.from("x")),
        pngChunk("IDAT", Buffer.from([0])),
      ],
    }),
    testPng({ chunks: [pngChunk("ABCD"), pngChunk("IDAT", Buffer.from([0]))] }),
    testPng({ colorType: 3, chunks: [pngChunk("IDAT", Buffer.from([0]))] }),
    testPng({
      colorType: 0,
      chunks: [pngChunk("PLTE", Buffer.from([0, 0, 0])), pngChunk("IDAT", Buffer.from([0]))],
    }),
  ];

  for (const png of invalidPngs) {
    const fixture = await startFixture({
      solovHandler: async (incoming, response) => {
        await readBody(incoming);
        response.writeHead(200, { "content-type": "application/json" });
        response.end(
          JSON.stringify({ data: [{ b64_json: png.toString("base64") }] }),
        );
      },
    });
    try {
      const body = JSON.stringify({
        model: "solov::gpt-image-1",
        input: "invalid png",
        stream: true,
      });
      const result = await request({
        url: fixture.routerUrl,
        headers: jsonHeaders(body),
        body,
      });
      assert.equal(result.status, 502);
      assert.equal(JSON.parse(result.body).error.code, "invalid_image_response");
      assert.deepEqual(await readdir(fixture.outputRoot), []);
    } finally {
      await fixture.close();
    }
  }
});

test("image output state cannot be forged and linked ancestors are rejected", async (t) => {
  assert.throws(
    () =>
      createRouter({
        solovApiKey: "<SYNTHETIC_SOLOV_AUTH>",
        catalogBody: TEST_SOLOV_CATALOG,
        imageOutputState: Object.freeze({
          requestedRoot: tmpdir(),
          canonicalRoot: tmpdir(),
          identity: Object.freeze({ dev: 0, ino: 0, birthtimeMs: 0 }),
        }),
        logger: () => {},
      }),
    /prepared output directory/,
  );

  const container = await mkdtemp(join(tmpdir(), "codex-router-link-test-"));
  const realDirectory = join(container, "real");
  const linkDirectory = join(container, "linked");
  await mkdir(realDirectory);
  t.after(() => rm(container, { recursive: true, force: true }));

  try {
    await symlink(realDirectory, linkDirectory, "junction");
  } catch (error) {
    if (error?.code === "EPERM") {
      t.diagnostic("Windows policy did not permit creation of a junction fixture.");
      return;
    }
    throw error;
  }
  await assert.rejects(
    prepareImageOutputRoot(join(linkDirectory, "images")),
    /links or junctions/,
  );
});

test("Solov image generation accepts only its four fixed models and strips their route prefix", async (t) => {
  const captured = [];
  const fixture = await startFixture({
    solovHandler: async (incoming, response) => {
      captured.push({
        url: incoming.url,
        headers: incoming.headers,
        body: await readBody(incoming),
      });
      response.writeHead(200, { "content-type": "application/json" });
      response.end('{"created":1,"data":[{"b64_json":"aW1hZ2U="}]}');
    },
  });
  t.after(() => fixture.close());

  const imageModels = [
    "gpt-image-1",
    "gpt-image-1.5",
    "gpt-image-2",
    "gpt-image-2-2026-04-21",
  ];
  for (const model of imageModels) {
    const body = Buffer.from(
      JSON.stringify({
        model: `solov::${model}`,
        prompt: "private image prompt",
        response_format: "b64_json",
      }),
    );
    const result = await request({
      url: fixture.routerUrl,
      path: "/images/generations",
      headers: jsonHeaders(body, {
        accept: "application/json",
        "accept-language": "zh-CN",
        "user-agent": "image-test-client",
        "x-oai-attestation": "must-not-forward",
        "x-codex-turn-state": "must-not-forward",
        traceparent: "must-not-forward",
        "x-unrelated-secret": "must-not-forward",
      }),
      body,
    });
    assert.equal(result.status, 200);
    assert.deepEqual(JSON.parse(result.body), {
      created: 1,
      data: [{ b64_json: "aW1hZ2U=" }],
    });
  }

  assert.equal(captured.length, imageModels.length);
  for (const [index, incoming] of captured.entries()) {
    assert.equal(incoming.url, "/solov/images/generations");
    assert.equal(JSON.parse(incoming.body).model, imageModels[index]);
    assert.equal(incoming.headers.authorization, "Bearer <SYNTHETIC_SOLOV_AUTH>");
    assert.equal(incoming.headers.accept, "application/json");
    assert.equal(incoming.headers["accept-language"], "zh-CN");
    assert.equal(incoming.headers["user-agent"], "image-test-client");
    assert.equal(incoming.headers["chatgpt-account-id"], undefined);
    assert.equal(incoming.headers["x-oai-attestation"], undefined);
    assert.equal(incoming.headers["x-codex-turn-state"], undefined);
    assert.equal(incoming.headers.traceparent, undefined);
    assert.equal(incoming.headers["x-unrelated-secret"], undefined);
  }
});

test("Solov image generation rejects official and unknown models, queries, and adjacent paths before forwarding", async (t) => {
  let upstreamHits = 0;
  const fixture = await startFixture({
    solovHandler: async (incoming, response) => {
      upstreamHits += 1;
      await readBody(incoming);
      response.end("unexpected");
    },
  });
  t.after(() => fixture.close());

  for (const model of [
    "gpt-image-1",
    "gpt-openai",
    "solov::gpt-solov",
    "solov::gpt-image-3",
    "solov::https://attacker.invalid/model",
  ]) {
    const body = Buffer.from(JSON.stringify({ model, prompt: "test" }));
    const result = await request({
      url: fixture.routerUrl,
      path: "/images/generations",
      headers: jsonHeaders(body),
      body,
    });
    assert.equal(result.status, 400);
    assert.equal(JSON.parse(result.body).error.code, "unknown_model");
  }

  const allowedBody = Buffer.from(
    JSON.stringify({ model: "solov::gpt-image-1", prompt: "test" }),
  );
  for (const path of [
    "/images/generations?url=https%3A%2F%2Fattacker.invalid",
    "/images/edits",
    "/images/generations/extra",
  ]) {
    const result = await request({
      url: fixture.routerUrl,
      path,
      headers: jsonHeaders(allowedBody),
      body: allowedBody,
    });
    assert.equal(result.status, 404);
    assert.equal(JSON.parse(result.body).error.code, "unknown_path");
  }
  assert.equal(upstreamHits, 0);
});

test("Solov image generation blocks redirects without exposing Location", async (t) => {
  const fixture = await startFixture({
    solovHandler: async (incoming, response) => {
      await readBody(incoming);
      response.writeHead(307, {
        location: "https://attacker.invalid/collect-image-request",
      });
      response.end();
    },
  });
  t.after(() => fixture.close());

  const body = Buffer.from(
    JSON.stringify({ model: "solov::gpt-image-1", prompt: "test" }),
  );
  const result = await request({
    url: fixture.routerUrl,
    path: "/images/generations",
    headers: jsonHeaders(body),
    body,
  });
  assert.equal(result.status, 502);
  assert.equal(result.headers.location, undefined);
  assert.equal(JSON.parse(result.body).error.code, "upstream_redirect_blocked");
});

test("Solov image generation streams base64 JSON responses larger than the catalog limit", async (t) => {
  const base64 = "A".repeat(9 * 1024 * 1024);
  const upstreamBody = Buffer.from(
    JSON.stringify({ created: 1, data: [{ b64_json: base64 }] }),
  );
  const fixture = await startFixture({
    solovHandler: async (incoming, response) => {
      await readBody(incoming);
      response.writeHead(200, {
        "content-type": "application/json",
        "content-length": String(upstreamBody.length),
      });
      response.end(upstreamBody);
    },
  });
  t.after(() => fixture.close());

  const body = Buffer.from(
    JSON.stringify({ model: "solov::gpt-image-2", prompt: "large" }),
  );
  const result = await request({
    url: fixture.routerUrl,
    path: "/images/generations",
    headers: jsonHeaders(body),
    body,
  });
  assert.equal(result.status, 200);
  assert.equal(result.headers["content-length"], undefined);
  assert.equal(result.body.length, upstreamBody.length);
  assert.deepEqual(result.body, upstreamBody);
});

test("Solov image generation fails closed when its key is not configured", async (t) => {
  let solovHits = 0;
  const fixture = await startFixture({
    solovApiKey: null,
    solovHandler: async (incoming, response) => {
      solovHits += 1;
      await readBody(incoming);
      response.end("unexpected");
    },
  });
  t.after(() => fixture.close());

  const body = Buffer.from(
    JSON.stringify({ model: "solov::gpt-image-1", prompt: "test" }),
  );
  const result = await request({
    url: fixture.routerUrl,
    path: "/images/generations",
    headers: jsonHeaders(body),
    body,
  });
  assert.equal(result.status, 503);
  assert.equal(JSON.parse(result.body).error.code, "solov_not_configured");
  assert.equal(solovHits, 0);
});

test("Solov image generation uses only the fixed Solov CONNECT authority and path", async (t) => {
  let captured;
  const fixture = await startProxyFixture({
    handler: async (incoming, response) => {
      captured = {
        method: incoming.method,
        url: incoming.url,
        host: incoming.headers.host,
        servername: incoming.socket.servername,
        body: await readBody(incoming),
      };
      response.writeHead(200, { "content-type": "application/json" });
      response.end('{"data":[]}');
    },
  });
  t.after(() => fixture.close());

  const body = Buffer.from(
    JSON.stringify({ model: "solov::gpt-image-1.5", prompt: "fixed target" }),
  );
  const result = await request({
    url: fixture.routerUrl,
    path: "/images/generations",
    headers: jsonHeaders(body),
    body,
  });

  assert.equal(result.status, 200);
  assert.deepEqual(fixture.proxy.authorities, ["solov.test:443"]);
  assert.deepEqual(captured, {
    method: "POST",
    url: "/solov/images/generations",
    host: "solov.test",
    servername: "solov.test",
    body: Buffer.from(
      JSON.stringify({ model: "gpt-image-1.5", prompt: "fixed target" }),
    ),
  });
});

test("CONNECT proxy uses only the fixed OpenAI and Solov authorities with verified SNI", async (t) => {
  const captured = [];
  const fixture = await startProxyFixture({
    handler: async (incoming, response) => {
      captured.push({
        url: incoming.url,
        host: incoming.headers.host,
        servername: incoming.socket.servername,
        body: await readBody(incoming),
      });
      response.writeHead(200, { "content-type": "application/json" });
      response.end('{"ok":true}');
    },
  });
  t.after(() => fixture.close());

  const openAiBody = Buffer.from(
    JSON.stringify({ model: "gpt-openai", input: "openai" }),
  );
  const openAiResult = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(openAiBody),
    body: openAiBody,
  });
  const solovBody = Buffer.from(
    JSON.stringify({ model: "solov::gpt-solov", input: "solov" }),
  );
  const solovResult = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(solovBody),
    body: solovBody,
  });

  assert.equal(openAiResult.status, 200);
  assert.equal(solovResult.status, 200);
  assert.deepEqual(fixture.proxy.authorities, [
    "openai.test:443",
    "solov.test:443",
  ]);
  assert.deepEqual(
    captured.map(({ url, host, servername }) => ({ url, host, servername })),
    [
      {
        url: "/openai/responses",
        host: "openai.test",
        servername: "openai.test",
      },
      {
        url: "/solov/responses",
        host: "solov.test",
        servername: "solov.test",
      },
    ],
  );
});

test("GET /models uses the fixed OpenAI CONNECT authority and verified SNI", async (t) => {
  let captured;
  const fixture = await startProxyFixture({
    handler: async (incoming, response) => {
      captured = {
        method: incoming.method,
        url: incoming.url,
        host: incoming.headers.host,
        servername: incoming.socket.servername,
        authorization: incoming.headers.authorization,
        body: await readBody(incoming),
      };
      response.writeHead(200, { "content-type": "application/json" });
      response.end(
        JSON.stringify({
          models: [{ slug: "gpt-proxy-live", display_name: "Proxy live" }],
        }),
      );
    },
  });
  t.after(() => fixture.close());

  const result = await request({
    url: fixture.routerUrl,
    path: "/models?client_version=1",
    method: "GET",
    headers: { authorization: "AgentAssertion <SYNTHETIC_AGENT_ASSERTION>" },
  });

  assert.equal(result.status, 200);
  assert.deepEqual(fixture.proxy.authorities, ["openai.test:443"]);
  assert.deepEqual(captured, {
    method: "GET",
    url: "/openai/models?client_version=1",
    host: "openai.test",
    servername: "openai.test",
    authorization: "AgentAssertion <SYNTHETIC_AGENT_ASSERTION>",
    body: Buffer.alloc(0),
  });
  assert.deepEqual(
    JSON.parse(result.body).models.map((model) => model.slug),
    ["gpt-proxy-live", "solov::gpt-solov", "solov::gpt-image-1"],
  );
});

test("SSE response chunks are streamed before the upstream response completes", async (t) => {
  let releaseSecondChunk;
  const release = new Promise((resolve) => {
    releaseSecondChunk = resolve;
  });
  const fixture = await startFixture({
    openAiHandler: async (incoming, response) => {
      await readBody(incoming);
      response.writeHead(200, {
        "content-type": "text/event-stream",
        "cache-control": "no-cache",
      });
      response.write('event: response.output_text.delta\ndata: {"delta":"A"}\n\n');
      await release;
      response.end('event: response.completed\ndata: {"ok":true}\n\n');
    },
  });
  t.after(() => fixture.close());

  const body = Buffer.from(JSON.stringify({ model: "gpt-openai", input: "stream" }));
  const target = new URL("/responses", fixture.routerUrl);
  const outgoing = http.request({
    hostname: target.hostname,
    port: target.port,
    path: target.pathname,
    method: "POST",
    headers: jsonHeaders(body),
  });
  outgoing.end(body);
  const [response] = await once(outgoing, "response");
  const firstChunkPromise = once(response, "data");
  const [firstChunk] = await firstChunkPromise;
  assert.match(firstChunk.toString(), /"delta":"A"/);

  releaseSecondChunk();
  const remaining = [firstChunk];
  response.on("data", (chunk) => remaining.push(chunk));
  await once(response, "end");
  assert.match(Buffer.concat(remaining).toString(), /response\.completed/);
});

test("SSE remains streaming through CONNECT and client cancellation closes the TLS upstream", async (t) => {
  let markUpstreamClosed;
  const upstreamClosed = new Promise((resolve) => {
    markUpstreamClosed = resolve;
  });
  const fixture = await startProxyFixture({
    handler: async (incoming, response) => {
      await readBody(incoming);
      response.once("close", markUpstreamClosed);
      response.writeHead(200, {
        "content-type": "text/event-stream",
        "cache-control": "no-cache",
      });
      response.write('event: response.output_text.delta\ndata: {"delta":"A"}\n\n');
    },
  });
  t.after(() => fixture.close());

  const body = Buffer.from(
    JSON.stringify({ model: "gpt-openai", input: "cancel" }),
  );
  const target = new URL("/responses", fixture.routerUrl);
  const outgoing = http.request({
    hostname: target.hostname,
    port: target.port,
    path: target.pathname,
    method: "POST",
    headers: jsonHeaders(body),
  });
  outgoing.end(body);
  const [response] = await once(outgoing, "response");
  const [firstChunk] = await once(response, "data");
  assert.match(firstChunk.toString(), /"delta":"A"/);
  response.destroy();

  await Promise.race([
    upstreamClosed,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error("upstream cancellation timed out")), 2_000),
    ),
  ]);
});

test("redirects are blocked and Location is not exposed to the client", async (t) => {
  const fixture = await startFixture({
    openAiHandler: async (incoming, response) => {
      await readBody(incoming);
      response.writeHead(307, {
        location: "https://attacker.invalid/collect",
      });
      response.end();
    },
  });
  t.after(() => fixture.close());

  const body = Buffer.from(JSON.stringify({ model: "gpt-openai", input: "redirect" }));
  const result = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(body),
    body,
  });
  assert.equal(result.status, 502);
  assert.equal(result.headers.location, undefined);
  assert.equal(JSON.parse(result.body).error.code, "upstream_redirect_blocked");
});

test("authentication and throttling statuses keep only safe diagnostic headers", async (t) => {
  const fixture = await startFixture({
    openAiHandler: async (incoming, response) => {
      await readBody(incoming);
      response.writeHead(401, {
        "content-type": "application/json",
        "www-authenticate": 'Bearer realm="chatgpt"',
        "retry-after": "2",
        "set-cookie": "sensitive-cookie=must-not-forward",
        location: "https://attacker.invalid/not-a-redirect-status",
      });
      response.end('{"error":{"code":"unauthorized"}}');
    },
  });
  t.after(() => fixture.close());

  const body = Buffer.from(JSON.stringify({ model: "gpt-openai" }));
  const result = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(body),
    body,
  });
  assert.equal(result.status, 401);
  assert.equal(result.headers["www-authenticate"], 'Bearer realm="chatgpt"');
  assert.equal(result.headers["retry-after"], "2");
  assert.equal(result.headers["set-cookie"], undefined);
  assert.equal(result.headers.location, undefined);
});

test("unknown models, paths, encodings, and unauthenticated requests fail before any upstream call", async (t) => {
  let upstreamHits = 0;
  const logEntries = [];
  const hit = async (incoming, response) => {
    upstreamHits += 1;
    await readBody(incoming);
    response.end("unexpected");
  };
  const fixture = await startFixture({
    openAiHandler: hit,
    solovHandler: hit,
    logger: (entry) => logEntries.push(entry),
  });
  t.after(() => fixture.close());

  const unknownBody = Buffer.from(JSON.stringify({ model: "not-allowed" }));
  const unknownModel = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(unknownBody),
    body: unknownBody,
  });
  assert.equal(unknownModel.status, 400);
  assert.equal(JSON.parse(unknownModel.body).error.code, "unknown_model");

  const knownBody = Buffer.from(JSON.stringify({ model: "gpt-openai" }));
  const unknownPath = await request({
    url: fixture.routerUrl,
    path: "/not-allowed?private-value-that-must-not-be-logged=1",
    headers: jsonHeaders(knownBody),
    body: knownBody,
  });
  assert.equal(unknownPath.status, 404);

  const unsupportedEncoding = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(knownBody, { "content-encoding": "gzip" }),
    body: knownBody,
  });
  assert.equal(unsupportedEncoding.status, 415);

  const noAuthHeaders = jsonHeaders(knownBody);
  delete noAuthHeaders.authorization;
  const unauthenticated = await request({
    url: fixture.routerUrl,
    headers: noAuthHeaders,
    body: knownBody,
  });
  assert.equal(unauthenticated.status, 401);
  assert.equal(upstreamHits, 0);
  assert.doesNotMatch(
    JSON.stringify(logEntries),
    /private-value-that-must-not-be-logged/,
  );
  assert.ok(
    logEntries.some(
      (entry) =>
        entry.event === "router_rejection" && entry.path === "/not-allowed",
    ),
  );
});

test("WebSocket probe gets an explicit HTTP fallback response without upstream forwarding", async (t) => {
  let upstreamHits = 0;
  const logEntries = [];
  const fixture = await startFixture({
    openAiHandler: (_incoming, response) => {
      upstreamHits += 1;
      response.end("unexpected");
    },
    logger: (entry) => logEntries.push(entry),
  });
  t.after(() => fixture.close());

  const websocketProbe = await request({
    url: fixture.routerUrl,
    path: "/responses",
    method: "GET",
    headers: {
      connection: "Upgrade",
      upgrade: "websocket",
      authorization: "Bearer <SYNTHETIC_WEBSOCKET_AUTH>",
      "sec-websocket-key": "fake-websocket-key",
      "sec-websocket-version": "13",
    },
  });
  assert.equal(websocketProbe.status, 426);
  assert.equal(
    JSON.parse(websocketProbe.body).error.code,
    "websocket_not_supported",
  );

  const ordinaryGet = await request({
    url: fixture.routerUrl,
    path: "/responses",
    method: "GET",
  });
  assert.equal(ordinaryGet.status, 404);
  assert.equal(upstreamHits, 0);
  assert.ok(
    logEntries.some(
      (entry) =>
        entry.path === "/responses" &&
        entry.status === 426 &&
        entry.outcome === "websocket_not_supported",
    ),
  );
  assert.doesNotMatch(
    JSON.stringify({ body: websocketProbe.body.toString(), logEntries }),
    /websocket-secret-must-not-leak|fake-websocket-key/,
  );
});

test("Solov route fails closed when its key is not configured", async (t) => {
  let solovHits = 0;
  const fixture = await startFixture({
    solovApiKey: null,
    solovHandler: async (incoming, response) => {
      solovHits += 1;
      await readBody(incoming);
      response.end("unexpected");
    },
  });
  t.after(() => fixture.close());

  const body = Buffer.from(JSON.stringify({ model: "solov::gpt-solov" }));
  const result = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(body),
    body,
  });
  assert.equal(result.status, 503);
  assert.equal(JSON.parse(result.body).error.code, "solov_not_configured");
  assert.equal(solovHits, 0);
});

test("responses/compact is the only additional allowed endpoint", async (t) => {
  let capturedPath;
  const fixture = await startFixture({
    openAiHandler: async (incoming, response) => {
      capturedPath = incoming.url;
      await readBody(incoming);
      response.writeHead(200, { "content-type": "application/json" });
      response.end('{"output":[]}');
    },
  });
  t.after(() => fixture.close());

  const body = Buffer.from(JSON.stringify({ model: "gpt-openai", input: [] }));
  const result = await request({
    url: fixture.routerUrl,
    path: "/responses/compact",
    headers: jsonHeaders(body),
    body,
  });
  assert.equal(result.status, 200);
  assert.equal(capturedPath, "/openai/responses/compact");
});

test("Solov responses/compact fails closed until compatibility is verified", async (t) => {
  let solovHits = 0;
  const fixture = await startFixture({
    solovHandler: async (incoming, response) => {
      solovHits += 1;
      await readBody(incoming);
      response.end("unexpected");
    },
  });
  t.after(() => fixture.close());

  const body = Buffer.from(
    JSON.stringify({ model: "solov::gpt-solov", input: [] }),
  );
  const result = await request({
    url: fixture.routerUrl,
    path: "/responses/compact",
    headers: jsonHeaders(body),
    body,
  });
  assert.equal(result.status, 501);
  assert.equal(
    JSON.parse(result.body).error.code,
    "solov_compaction_unverified",
  );
  assert.equal(solovHits, 0);
});

test("GET /models preserves the official catalog, appends Solov, and refreshes route allowlists", async (t) => {
  const logEntries = [];
  const captured = [];
  const officialCatalog = {
    object: "model_catalog",
    models: [
      {
        slug: "gpt-dynamic-a",
        display_name: "Official A",
        supported_reasoning_levels: [{ effort: "high", description: "Exact" }],
      },
      {
        slug: "gpt-dynamic-b",
        display_name: "Official B",
        metadata: { untouched: true },
      },
    ],
    server_metadata: { revision: 7 },
  };
  const solovCatalog = {
    models: [
      { slug: "solov::gpt-solov", display_name: "Solov test · Solov" },
      { slug: "solov::gpt-extra", display_name: "Extra test · Solov" },
    ],
  };
  const fixture = await startFixture({
    catalogBody: Buffer.from(JSON.stringify(solovCatalog)),
    logger: (entry) => logEntries.push(entry),
    openAiHandler: async (incoming, response) => {
      captured.push({
        method: incoming.method,
        url: incoming.url,
        headers: incoming.headers,
        body: await readBody(incoming),
      });
      response.writeHead(200, { "content-type": "application/json" });
      response.end(
        incoming.method === "GET"
          ? JSON.stringify(officialCatalog)
          : '{"ok":true}',
      );
    },
    solovHandler: async (incoming, response) => {
      captured.push({
        method: incoming.method,
        url: incoming.url,
        headers: incoming.headers,
        body: await readBody(incoming),
      });
      response.writeHead(200, { "content-type": "application/json" });
      response.end('{"ok":true}');
    },
  });
  t.after(() => fixture.close());

  const health = await request({
    url: fixture.routerUrl,
    path: "/health",
    method: "GET",
  });
  assert.equal(health.status, 200);
  assert.deepEqual(JSON.parse(health.body), { status: "ok" });

  const models = await request({
    url: fixture.routerUrl,
    path: "/models?client_version=26.803.10989.0",
    method: "GET",
    headers: {
      authorization: "AgentAssertion <SYNTHETIC_AGENT_ASSERTION>",
      "chatgpt-account-id": "<SYNTHETIC_ACCOUNT>",
      "x-oai-attestation": "fake-attestation",
      "accept-encoding": "gzip",
      "x-unrelated-secret": "must-not-forward",
    },
  });
  assert.equal(models.status, 200);
  const mergedCatalog = JSON.parse(models.body);
  assert.deepEqual(mergedCatalog.server_metadata, officialCatalog.server_metadata);
  assert.deepEqual(
    mergedCatalog.models.slice(0, officialCatalog.models.length),
    officialCatalog.models,
  );
  assert.deepEqual(
    mergedCatalog.models.slice(officialCatalog.models.length),
    solovCatalog.models,
  );

  assert.equal(captured[0].method, "GET");
  assert.equal(
    captured[0].url,
    "/openai/models?client_version=26.803.10989.0",
  );
  assert.equal(
    captured[0].headers.authorization,
    "AgentAssertion <SYNTHETIC_AGENT_ASSERTION>",
  );
  assert.equal(captured[0].headers["chatgpt-account-id"], "<SYNTHETIC_ACCOUNT>");
  assert.equal(captured[0].headers["x-oai-attestation"], "fake-attestation");
  assert.equal(captured[0].headers["accept-encoding"], "identity");
  assert.equal(captured[0].headers["x-unrelated-secret"], undefined);
  assert.equal(captured[0].headers["content-length"], undefined);

  const dynamicBody = Buffer.from(
    JSON.stringify({ model: "gpt-dynamic-b", input: "official" }),
  );
  const dynamicResult = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(dynamicBody),
    body: dynamicBody,
  });
  assert.equal(dynamicResult.status, 200);
  assert.equal(captured[1].url, "/openai/responses");

  const removedSeedBody = Buffer.from(
    JSON.stringify({ model: "gpt-openai", input: "stale-seed" }),
  );
  const removedSeedResult = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(removedSeedBody),
    body: removedSeedBody,
  });
  assert.equal(removedSeedResult.status, 400);

  const solovBody = Buffer.from(
    JSON.stringify({ model: "solov::gpt-extra", input: "third-party" }),
  );
  const solovResult = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(solovBody),
    body: solovBody,
  });
  assert.equal(solovResult.status, 200);
  assert.equal(captured[2].url, "/solov/responses");
  assert.equal(JSON.parse(captured[2].body).model, "gpt-extra");

  const forbiddenQuery = await request({
    url: fixture.routerUrl,
    path: "/models?client_version=1&redirect=https%3A%2F%2Fattacker.invalid",
    method: "GET",
    headers: { authorization: "Bearer <SYNTHETIC_CHATGPT_AUTH>" },
  });
  assert.equal(forbiddenQuery.status, 404);

  const duplicateVersion = await request({
    url: fixture.routerUrl,
    path: "/models?client_version=1&client_version=2",
    method: "GET",
    headers: { authorization: "Bearer <SYNTHETIC_CHATGPT_AUTH>" },
  });
  assert.equal(duplicateVersion.status, 400);

  const unknownGet = await request({
    url: fixture.routerUrl,
    path: "/anything-else?query-secret-must-not-be-logged=1",
    method: "GET",
  });
  assert.equal(unknownGet.status, 404);
  assert.ok(
    logEntries.some(
      (entry) =>
        entry.event === "router_rejection" && entry.path === "/anything-else",
    ),
  );
  assert.doesNotMatch(
    JSON.stringify(logEntries),
    /query-secret-must-not-be-logged/,
  );
});

test("GET /models passes through official errors without exposing a Solov-only catalog", async (t) => {
  const fixture = await startFixture({
    openAiHandler: async (incoming, response) => {
      await readBody(incoming);
      if (incoming.method === "GET") {
        response.writeHead(401, {
          "content-type": "application/json",
          "www-authenticate": 'Bearer realm="chatgpt"',
          "set-cookie": "sensitive=must-not-forward",
          location: "https://attacker.invalid/collect",
        });
        response.end('{"error":{"code":"official_auth_failed"}}');
        return;
      }
      response.writeHead(200, { "content-type": "application/json" });
      response.end('{"ok":true}');
    },
  });
  t.after(() => fixture.close());

  const models = await request({
    url: fixture.routerUrl,
    path: "/models?client_version=1",
    method: "GET",
    headers: { authorization: "Bearer <SYNTHETIC_CHATGPT_AUTH>" },
  });
  assert.equal(models.status, 401);
  assert.deepEqual(JSON.parse(models.body), {
    error: { code: "official_auth_failed" },
  });
  assert.doesNotMatch(models.body.toString(), /Solov test/);
  assert.equal(models.headers["www-authenticate"], 'Bearer realm="chatgpt"');
  assert.equal(models.headers["set-cookie"], undefined);
  assert.equal(models.headers.location, undefined);

  // A failed refresh must not replace the safe startup seed allowlist.
  const seededBody = Buffer.from(
    JSON.stringify({ model: "gpt-openai", input: "still-allowed" }),
  );
  const seeded = await request({
    url: fixture.routerUrl,
    headers: jsonHeaders(seededBody),
    body: seededBody,
  });
  assert.equal(seeded.status, 200);
});

test("GET /models rejects malformed, redirected, and oversized official catalogs", async (t) => {
  const cases = [
    {
      name: "malformed",
      handler: (_incoming, response) => {
        response.writeHead(200, { "content-type": "application/json" });
        response.end('{"models":');
      },
      code: "invalid_upstream_catalog",
    },
    {
      name: "redirected",
      handler: (_incoming, response) => {
        response.writeHead(307, { location: "https://attacker.invalid/models" });
        response.end();
      },
      code: "upstream_redirect_blocked",
    },
    {
      name: "oversized",
      handler: (_incoming, response) => {
        response.writeHead(200, {
          "content-type": "application/json",
          "content-length": String(8 * 1024 * 1024 + 1),
        });
        response.end();
      },
      code: "upstream_catalog_too_large",
    },
  ];

  for (const testCase of cases) {
    await t.test(testCase.name, async () => {
      const fixture = await startFixture({ openAiHandler: testCase.handler });
      try {
        const models = await request({
          url: fixture.routerUrl,
          path: "/models?client_version=1",
          method: "GET",
          headers: { authorization: "Bearer <SYNTHETIC_CHATGPT_AUTH>" },
        });
        assert.equal(models.status, 502);
        assert.equal(JSON.parse(models.body).error.code, testCase.code);
        assert.doesNotMatch(models.body.toString(), /Solov test/);
        assert.equal(models.headers.location, undefined);
      } finally {
        await fixture.close();
      }
    });
  }
});
