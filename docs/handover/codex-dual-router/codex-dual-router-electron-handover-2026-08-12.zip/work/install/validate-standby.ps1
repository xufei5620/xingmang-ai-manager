[CmdletBinding()]
param(
    [int]$TestPort = 43121,
    [string]$HttpsProxy = 'http://127.0.0.1:10808',
    [string]$SecretPath = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\secrets\solov.dpapi'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$workspaceRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$routerRoot = Join-Path $workspaceRoot 'work\router'
$routerEntry = Join-Path $routerRoot 'src\main.mjs'
$catalogPath = Join-Path $workspaceRoot 'work\catalog\model-catalog.json'
$liveValidator = Join-Path $PSScriptRoot 'validate-live-picker.ps1'

foreach ($requiredPath in @($routerEntry, $catalogPath, $liveValidator, $SecretPath)) {
    if (-not (Test-Path -LiteralPath $requiredPath -PathType Leaf)) {
        throw "Required file not found: $requiredPath"
    }
}

$tempBase = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
$tempRoot = Join-Path $tempBase ('codex-dual-router-standby-' + [Guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($tempRoot) | Out-Null
$standbyCatalog = Join-Path $tempRoot 'models.json'
[IO.File]::WriteAllBytes($standbyCatalog, [IO.File]::ReadAllBytes($catalogPath))
$stdoutPath = Join-Path $tempRoot 'stdout.log'
$stderrPath = Join-Path $tempRoot 'stderr.log'
$routerProcess = $null
$secretPointer = [IntPtr]::Zero
$plainSecret = $null

try {
    $encrypted = [IO.File]::ReadAllText($SecretPath).Trim()
    $secureSecret = ConvertTo-SecureString $encrypted
    $secretPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureSecret)
    $plainSecret = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($secretPointer)

    $env:SOLOV_API_KEY = $plainSecret
    $env:DUAL_ROUTER_PORT = [string]$TestPort
    $env:DUAL_ROUTER_CATALOG = $standbyCatalog
    $env:DUAL_ROUTER_HTTPS_PROXY = $HttpsProxy

    $nodePath = (Get-Command node.exe -ErrorAction Stop).Source
    $routerProcess = Start-Process -FilePath $nodePath `
        -ArgumentList @($routerEntry) `
        -WorkingDirectory $routerRoot `
        -WindowStyle Hidden `
        -RedirectStandardOutput $stdoutPath `
        -RedirectStandardError $stderrPath `
        -PassThru

    Remove-Item Env:SOLOV_API_KEY -ErrorAction SilentlyContinue
    Remove-Item Env:DUAL_ROUTER_PORT -ErrorAction SilentlyContinue
    Remove-Item Env:DUAL_ROUTER_CATALOG -ErrorAction SilentlyContinue
    Remove-Item Env:DUAL_ROUTER_HTTPS_PROXY -ErrorAction SilentlyContinue
    $plainSecret = $null
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secretPointer)
    $secretPointer = [IntPtr]::Zero

    $healthy = $false
    for ($attempt = 0; $attempt -lt 20; $attempt++) {
        Start-Sleep -Milliseconds 250
        if ($routerProcess.HasExited) {
            $safeError = Get-Content -Raw -LiteralPath $stderrPath -ErrorAction SilentlyContinue
            throw "Standby router exited during startup. $safeError"
        }
        try {
            $health = Invoke-RestMethod -Uri "http://127.0.0.1:$TestPort/health" -TimeoutSec 2
            if ($health.status -ceq 'ok') {
                $healthy = $true
                break
            }
        }
        catch {
            # The process may still be starting.
        }
    }
    if (-not $healthy) {
        $safeError = Get-Content -Raw -LiteralPath $stderrPath -ErrorAction SilentlyContinue
        throw "Standby router did not become healthy. $safeError"
    }

    & $liveValidator `
        -InstallRoot $routerRoot `
        -Port $TestPort `
        -MinimumOfficialModels 2 `
        -MinimumSolovModels 11 `
        -MinimumSolovTextModels 7 `
        -MinimumSolovImageModels 4 `
        -ExpectedSolovTextModels 7 `
        -ExpectedSolovImageModels 4
}
finally {
    Remove-Item Env:SOLOV_API_KEY -ErrorAction SilentlyContinue
    Remove-Item Env:DUAL_ROUTER_PORT -ErrorAction SilentlyContinue
    Remove-Item Env:DUAL_ROUTER_CATALOG -ErrorAction SilentlyContinue
    Remove-Item Env:DUAL_ROUTER_HTTPS_PROXY -ErrorAction SilentlyContinue
    $plainSecret = $null
    if ($secretPointer -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secretPointer)
    }
    if ($null -ne $routerProcess -and -not $routerProcess.HasExited) {
        Stop-Process -Id $routerProcess.Id -Force
        $routerProcess.WaitForExit(5000) | Out-Null
    }

    $resolvedTempRoot = [IO.Path]::GetFullPath($tempRoot)
    $expectedPrefix = $tempBase.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $leaf = [IO.Path]::GetFileName($resolvedTempRoot)
    if ($resolvedTempRoot.StartsWith($expectedPrefix, [StringComparison]::OrdinalIgnoreCase) -and
        $leaf.StartsWith('codex-dual-router-standby-', [StringComparison]::Ordinal)) {
        [IO.Directory]::Delete($resolvedTempRoot, $true)
    }
}
