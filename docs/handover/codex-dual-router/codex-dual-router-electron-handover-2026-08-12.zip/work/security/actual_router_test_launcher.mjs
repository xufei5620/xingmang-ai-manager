// Test-only launcher that wires the real router implementation to fake
// loopback upstreams supplied by router_security_harness.py.
import { appendFileSync } from "node:fs";
import {
  closeServer,
  createRouter,
  listenRouter,
  prepareImageOutputRoot,
} from "../router/src/router.mjs";

const required = [
  "ROUTER_PORT",
  "OPENAI_UPSTREAM_BASE_URL",
  "SOLOV_UPSTREAM_BASE_URL",
  "SOLOV_API_KEY",
];
for (const name of required) {
  if (typeof process.env[name] !== "string" || process.env[name].length === 0) {
    throw new Error(`${name} is required by the isolated test launcher.`);
  }
}

if (process.env.ROUTER_TEST_MODE !== "1") {
  throw new Error("The actual-router test launcher only runs in ROUTER_TEST_MODE=1.");
}

const openAiModel = process.env.ROUTER_TEST_OPENAI_MODEL ?? "gpt-test";
const solovModel = process.env.ROUTER_TEST_SOLOV_MODEL ?? "deepseek-test";
const solovCatalogJson =
  process.env.ROUTER_TEST_SOLOV_CATALOG_JSON ??
  JSON.stringify({
    models: [
      {
        slug: `solov::${solovModel}`,
        display_name: "Synthetic Test Model \u00b7 Solov",
      },
    ],
  });
let solovCatalog;
try {
  solovCatalog = JSON.parse(solovCatalogJson);
} catch {
  throw new Error("ROUTER_TEST_SOLOV_CATALOG_JSON must be valid JSON.");
}
if (
  solovCatalog === null ||
  Array.isArray(solovCatalog) ||
  typeof solovCatalog !== "object" ||
  !Array.isArray(solovCatalog.models)
) {
  throw new Error("ROUTER_TEST_SOLOV_CATALOG_JSON must contain a models array.");
}
const port = Number(process.env.ROUTER_PORT);
if (!Number.isInteger(port) || port < 1 || port > 65_535) {
  throw new Error("ROUTER_PORT is invalid.");
}

if (
  typeof process.env.ROUTER_TEST_IMAGE_OUTPUT_ROOT !== "string" ||
  process.env.ROUTER_TEST_IMAGE_OUTPUT_ROOT.length === 0
) {
  throw new Error("ROUTER_TEST_IMAGE_OUTPUT_ROOT is required.");
}
const imageOutputState = await prepareImageOutputRoot(
  process.env.ROUTER_TEST_IMAGE_OUTPUT_ROOT,
);

const server = createRouter({
  solovApiKey: process.env.SOLOV_API_KEY,
  catalogBody: Buffer.from(JSON.stringify(solovCatalog), "utf8"),
  imageOutputState,
  upstreams: {
    openai: process.env.OPENAI_UPSTREAM_BASE_URL,
    solov: process.env.SOLOV_UPSTREAM_BASE_URL,
  },
  allowTestUpstreams: true,
  allowedOpenAiModels: new Set([openAiModel]),
  allowedSolovModels: new Set([solovModel]),
  upstreamIdleTimeoutMs: 5_000,
  logger: (entry) => {
    const logPath = process.env.ROUTER_TEST_LOG_PATH;
    if (typeof logPath === "string" && logPath.length > 0) {
      appendFileSync(logPath, `${JSON.stringify(entry)}\n`, "utf8");
    }
  },
});

await listenRouter(server, port);

let closing = false;
async function shutdown() {
  if (closing) {
    return;
  }
  closing = true;
  await closeServer(server);
  process.exitCode = 0;
}

process.on("SIGINT", () => void shutdown());
process.on("SIGTERM", () => void shutdown());
