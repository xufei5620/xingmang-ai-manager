# Mixed-provider router security harness

This directory contains an isolated black-box audit harness for the local
OpenAI/third-party model router. It does not read or modify `~/.codex`, and all
credentials are obvious synthetic test values.

## What it proves

The harness starts fake OpenAI and Solov upstreams plus an SSRF trap, then
checks that the router:

- listens only on `127.0.0.1`;
- rejects unknown paths and models before contacting an upstream;
- forwards `GET /models` to the official upstream with the original synthetic
  ChatGPT identity headers and without the Solov key;
- preserves every official model record and its order, then appends only local
  `solov::` records whose display names end in `\u00b7 Solov`;
- permits a newly discovered official model on `POST /responses` after a
  successful catalog refresh;
- preserves an official catalog error without returning a Solov-only fallback,
  contacting Solov, leaking credentials, or erasing the last known-good
  official model set;
- replaces, rather than forwards, ChatGPT authorization on the Solov branch;
- removes `ChatGPT-Account-ID`, `x-oai-attestation`, `originator`, Codex
  installation IDs, and related first-party identity headers from Solov calls;
- accepts `POST /images/generations` only for the four explicitly allowlisted
  `solov::gpt-image-*` aliases, strips only the `solov::` prefix, and sends the
  request only to the fixed Solov `/v1/images/generations` endpoint;
- rejects unprefixed/official, text-only, unknown, URL-shaped, and
  query-overridden image models before any upstream is contacted;
- applies the same ChatGPT/Codex identity-header isolation and synthetic-key
  replacement to image-generation requests as to Solov Responses requests;
- never follows an image-upstream redirect and preserves safe image success
  and error bodies, content types, request IDs, and retry headers;
- exposes each allowlisted Solov image model through `POST /responses` while
  translating only a non-empty string or the latest user message's single
  `input_text` into the fixed Image API request;
- ignores Codex's top-level tool definitions, instructions, and prior
  developer/assistant/user history when building the image prompt, but rejects
  ambiguous, file, image, structured, oversized, and non-streaming inputs;
- validates the complete PNG structure and CRCs, atomically publishes it under
  a cryptographically random name in a fixed private output directory, and
  converts it into an assistant `output_text` Markdown reference through
  `response.created`, `response.output_item.added`,
  `response.output_item.done`, and `response.completed` SSE events;
- fails closed on malformed JSON, wrong result cardinality, invalid base64, or
  non-PNG results, while preserving safe upstream error status semantics;
- keeps concurrent image files and random response/item IDs isolated, leaves no
  partial temporary file after success or validated failures, keeps each final
  path directly under the prepared output root, and never logs prompts, base64
  image contents, local paths, ChatGPT credentials, or the Solov key;
- never exposes the Solov key to the OpenAI branch;
- ignores caller-controlled routing headers and URL-shaped models;
- never follows an upstream redirect;
- streams SSE incrementally and propagates client cancellation;
- preserves upstream `401`, `429`, `WWW-Authenticate`, `Retry-After`, and
  request-ID semantics.

## Run the harness self-test

The bundled `router_test_fixture.py` is a deliberately small, test-only router
used to prove that the harness itself works:

```powershell
python work/security/router_security_harness.py --self-test-router
```

It is not intended to be installed or used as the production router.

## Audit the real router

Pass the real router command after `--router-command`. The harness assigns an
unused router port and injects these synthetic settings:

- `ROUTER_HOST`, `ROUTER_PORT`
- `OPENAI_UPSTREAM_BASE_URL`, `SOLOV_UPSTREAM_BASE_URL`
- `SOLOV_API_KEY`
- `OPENAI_MODEL_ALIASES`, `SOLOV_MODEL_ALIASES`
- `SOLOV_IMAGE_MODEL_ALIASES`
- `ROUTER_TEST_SOLOV_CATALOG_JSON`
- `ROUTER_TEST_MODE=1`

Example:

```powershell
python work/security/router_security_harness.py `
  --router-cwd C:\path\to\router `
  --router-command python router.py
```

For the router implementation currently located at `work/router`, use the
test-only launcher so its hard-coded production upstreams are replaced by the
fake loopback servers:

```powershell
python work/security/router_security_harness.py `
  --router-command node work/security/actual_router_test_launcher.mjs
```

Command tokens may also use `{host}`, `{port}`, `{openai_upstream}`,
`{solov_upstream}`, `{solov_key}`, `{openai_model}`, and `{solov_model}`
placeholders. A failing assertion produces a nonzero exit code while the rest
of the audit continues, so one run gives a complete pass/fail inventory.

## Security boundary

Passing this suite is necessary but not sufficient for production use. The
real router should additionally pin its two configured upstream hostnames,
validate TLS normally, never log request headers or bodies, keep the Solov key
outside source/config files, and disable WebSocket mode unless it implements
equivalent isolation for WebSocket frames.
