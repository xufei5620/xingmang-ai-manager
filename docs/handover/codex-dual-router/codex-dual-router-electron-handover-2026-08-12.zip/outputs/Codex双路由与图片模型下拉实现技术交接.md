# Codex 双路由与图片模型下拉实现技术交接

> 文档用途：供其他 Codex 会话在不重新调查整条链路的情况下，理解、审计、维护或扩展本机实现。
>
> 当前快照：2026-08-12；Codex 桌面包 `26.803.10989.0`；bundled core `codex-cli 0.147.0-alpha.6.6`。
>
> 安全说明：本文不包含 Solov API Key、ChatGPT token、DPAPI 密文内容或任何可复用凭据。

## 1. 一句话结论

本实现没有把所有请求改成走第三方，也没有修改 Codex 客户端二进制。它让 Codex 继续保持 `openai` Provider 和原 ChatGPT 订阅登录，只把 `openai_base_url` 指向本机回环路由；路由实时保留官方模型目录，再追加带 `solov::` 命名空间的第三方模型，并按模型 ID 将每个请求分别送往 ChatGPT 或 Solov。

图片模型通过同一个模型下拉菜单选择。因为当前桌面核心不会把原生 `image_generation_call` 提升成桌面可见图片项，本机路由会把 `/responses` 图片任务转换为 Solov Images API 请求，严格验证返回的 PNG，安全保存到本机，再用桌面端已验证可渲染的绝对路径 Markdown assistant message 返回。

最终用户体验是：

- 官方模型保留原名称、原顺序和订阅线路；
- Solov 文字模型显示 `· Solov` 后缀；
- Solov 图片模型显示 `· Solov Image` 后缀；
- 用户在输入框下方的原模型菜单中直接切换；
- 客户端看到的请求 URL 是 `http://127.0.0.1:43120/...`，这是预期的本机分流入口，不是真实上游地址。

## 2. 官方能力与本机兼容层的边界

### 2.1 官方能力

官方文档确认了这些构建块：

- Codex 可以通过 `openai_base_url` 将内置 `openai` Provider 指向代理或路由，而不必创建新 Provider；参见 [Advanced Configuration](https://learn.chatgpt.com/docs/config-file/config-advanced)。
- Codex app-server 提供 `model/list` 并向桌面客户端返回可用模型；参见 [Codex App Server](https://learn.chatgpt.com/docs/app-server)。
- 桌面端在 composer 下方选择 available model 和 reasoning effort；参见 [Models](https://learn.chatgpt.com/docs/models)。
- OpenAI Images API 可返回 `data[0].b64_json`，Responses 图片工具可产生 `image_generation_call.result`；参见 [Image generation](https://developers.openai.com/api/docs/guides/image-generation)。

### 2.2 本机增加的能力

以下不是官方桌面 UI 原生提供的“双 Provider 下拉选择器”，而是本机适配层：

- 在官方实时模型目录末尾追加第三方模型；
- 用 `solov::` slug 前缀把一个模型菜单映射到两条上游；
- 在同一个 `openai` Provider 会话下按模型逐请求分流；
- 将图片模型的 Responses 请求适配为 Images API；
- 把图片保存为本机 PNG，再通过 assistant Markdown 交给桌面渲染。

公开的模型目录条目本身不携带“该模型属于哪个 Provider”的路由字段，因此不能仅靠一个静态 catalog 让客户端原生逐项切 Provider。本实现选择“一个活动 Provider + 本机按模型分流”，而不是修改闭源桌面 UI。

### 2.3 不要做出的错误承诺

- 不要称其为 OpenAI 官方支持的桌面双 Provider 功能。
- 不要声称一个请求同时消耗 ChatGPT 订阅和第三方额度；每次请求只会进入一个上游分支。
- 不要声称 `127.0.0.1` 是计费方；它只是本机入口。
- 不要把通过安全测试描述成对同一 Windows 用户恶意进程的绝对文件系统隔离。
- 不要把历史 Solov HTTP 200 烟测描述成当前仍可用；服务端余额和模型状态会变化。

## 3. 当前正式状态

### 3.1 正式安装

```text
C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter
```

当前路由：

- 监听：`127.0.0.1:43120`
- ChatGPT 上游：`https://chatgpt.com/backend-api/codex`
- Solov 上游：`https://xm.solov.cc/v1`
- 最新事务：`backups\20260812-123150-image-picker`
- 事务状态：`committed`
- 最终审计时 PID 文件、事务 PID、实际 Node 进程和监听 PID 均为 `70612`
- 最终审计时 `/health` 返回 `{"status":"ok"}`

进程 PID 会在重启后变化，不要把 `70612` 当作长期常量。

### 3.2 Codex 配置契约

正式 `C:\Users\<USER>\.codex\config.toml` 的关键契约是：

```toml
model_provider = "openai"
openai_base_url = "http://127.0.0.1:43120"
```

同时必须满足：

- 不设置顶层 `model_catalog_json`；否则会用静态目录替换官方实时目录。
- 不把 `model_provider` 全局切成 Solov；否则任务过滤、登录和官方模型路径都会改变。
- `auth.json` 继续保存原 ChatGPT 登录；部署不修改它。

### 3.3 当前菜单

正式 `model/list` 最终验证为：

- 官方模型：7 个，实时返回，名称未改；
- Solov 文字模型：7 个；
- Solov 图片模型：4 个。

Solov 文字模型：

| 客户端 slug | 显示名 |
| --- | --- |
| `solov::gpt-5.6-sol` | `GPT-5.6 Sol · Solov` |
| `solov::gpt-5.6-terra` | `GPT-5.6 Terra · Solov` |
| `solov::gpt-5.5` | `GPT-5.5 · Solov` |
| `solov::gpt-5.4` | `GPT-5.4 · Solov` |
| `solov::gpt-5.4-mini` | `GPT-5.4 Mini · Solov` |
| `solov::gpt-5.3-codex-spark` | `GPT-5.3 Codex Spark · Solov` |
| `solov::codex-auto-review` | `Codex Auto Review · Solov` |

Solov 图片模型：

| 客户端 slug | 显示名 | 上游模型 |
| --- | --- | --- |
| `solov::gpt-image-1` | `GPT Image 1 · Solov Image` | `gpt-image-1` |
| `solov::gpt-image-1.5` | `GPT Image 1.5 · Solov Image` | `gpt-image-1.5` |
| `solov::gpt-image-2` | `GPT Image 2 · Solov Image` | `gpt-image-2` |
| `solov::gpt-image-2-2026-04-21` | `GPT Image 2 (2026-04-21) · Solov Image` | `gpt-image-2-2026-04-21` |

官方模型数量是动态状态，不应在代码或文档中永久固定为 7；Solov 本地目录则精确固定为 7 个文字 + 4 个图片，直到重新探测并发布新目录。

## 4. 总体架构

```mermaid
flowchart TD
    A["Codex desktop\nProvider=openai\nChatGPT login retained"] --> B["127.0.0.1:43120\nCodexDualRouter"]
    B -->|"GET /models + ChatGPT auth"| C["ChatGPT official /models"]
    C --> D["Preserve official records and order"]
    E["Local Solov-only catalog\n7 text + 4 image"] --> D
    D --> A

    B -->|"Official model slug"| F["ChatGPT Codex backend\nsubscription route"]
    B -->|"solov:: text slug"| G["Strip prefix + rebuild headers\nSolov /responses"]
    B -->|"solov:: image slug"| H["Extract last user text\nSolov /images/generations"]
    H --> I["Strict Base64 and PNG validation"]
    I --> J["Atomic PNG publish\ngenerated-images"]
    J --> K["Responses assistant Markdown\nabsolute local PNG path"]
    K --> A
```

核心思想不是“客户端知道两个 Provider”，而是：

```text
客户端始终认为自己使用 openai Provider
                    ↓
          本机根据 model slug 决定真实上游
```

## 5. 文件地图

工作区根目录：

```text
C:\Users\<USER>\Documents\Codex\2026-08-12\chatgpt-api
```

关键文件：

| 文件 | 作用 |
| --- | --- |
| `work/router/src/config.mjs` | 固定监听、上游、允许路径、图片白名单、大小和超时上限 |
| `work/router/src/main.mjs` | 载入目录、准备图片目录、创建并启动路由 |
| `work/router/src/router.mjs` | 目录合并、模型分流、代理、图片适配、安全落盘及错误语义 |
| `work/router/test/router.test.mjs` | 37 项路由单元测试 |
| `work/catalog/solov-model-manifest.json` | 23 个上游模型的无密钥探测证据和入选标记 |
| `work/catalog/model-catalog.json` | 只含 Solov 的 11 项 Codex 模型目录 |
| `work/catalog/build_catalog.ps1` | 从 manifest 和 bundled catalog 构建本地目录 |
| `work/catalog/validate_catalog.ps1` | 静态和真实 bundled app-server 目录验证 |
| `work/security/router_security_harness.py` | 29 项独立回环黑盒安全测试 |
| `work/security/actual_router_test_launcher.mjs` | 用伪上游启动真实 `router.mjs` |
| `work/validate-full-chain-image-event.ps1` | bundled app-server 成功/403 全链合成验证 |
| `work/full_chain_image_probe.mjs` | 全链测试用伪 OpenAI/Solov 服务 |
| `work/install/apply-image-picker.ps1` | 预检、CAS、备份、部署、验收和自动回滚 |
| `work/install/start-router.ps1` | DPAPI 解密、环境注入、隐藏启动和健康检查 |
| `work/install/stop-router.ps1` | PID 归属验证后停止正式路由 |
| `work/install/validate-live-picker.ps1` | 正式菜单和名称验证 |
| `work/install/validate-live-responses.ps1` | 官方和 Solov 文字真实请求验证 |
| `work/install/validate-live-image-picker.ps1` | 单次真实付费图片全链验收 |
| `work/install/rollback.ps1` | 完全退出双路由并恢复最初订阅直连配置 |

正式安装中，`router`、`models.json`、manifest 和三个 validator 均与最新工作区候选 SHA-256 一致。可复现时应优先读取最新备份中的 `candidate-sha256.json`，不要依赖人工抄录的哈希。

## 6. 路由入口和白名单

`work/router/src/config.mjs` 固定：

```js
LISTEN_HOST = "127.0.0.1"
DEFAULT_PORT = 43120

PRODUCTION_UPSTREAMS = {
  openai: "https://chatgpt.com/backend-api/codex",
  solov: "https://xm.solov.cc/v1",
}

ALLOWED_PATHS = new Set([
  "/responses",
  "/responses/compact",
  "/images/generations",
])
```

另外允许：

- `GET /health`
- `GET /models`，查询参数只允许单个可选 `client_version`
- `GET /responses` WebSocket probe 会返回 426，促使当前客户端回退 HTTP/SSE；不会转发给上游

所有其他路径、查询、模型或方法均失败关闭。

生产模式会严格比较上游的 scheme、hostname、port 和 base path。只有显式测试模式才能将上游替换为回环伪服务。

## 7. 动态模型目录合并

### 7.1 为什么不用 `model_catalog_json`

静态 `model_catalog_json` 会替换当前进程的模型目录。早期尝试因此只剩本地条目，造成“官方订阅只剩一个模型”或官方模型消失。

最终方案不在 `config.toml` 设置它，而是让客户端请求本机 `GET /models`：

1. 本机携带客户端原 ChatGPT 认证请求官方 `/models`；
2. 验证 HTTP 200、JSON、大小、内容编码和模型结构；
3. 保留官方响应所有根字段；
4. 保留每个官方 model 对象、原顺序和原名称；
5. 在末尾追加启动时加载的 Solov-only models；
6. 只有完整合并成功后才更新官方模型 allowlist。

核心表达式位于 `mergeOfficialAndSolovCatalog()`：

```js
models: [...officialCatalog.models, ...localCatalog.parsed.models]
```

官方请求失败时：

- 原安全状态返回客户端；
- 不输出 Solov-only 假目录；
- 不清空最后一个有效官方 allowlist；
- 不接触 Solov 上游。

### 7.2 本地目录约束

`parseLocalSolovCatalog()` 要求：

- 根结构符合 Codex models schema；
- 所有 slug 必须以 `solov::` 开头；
- slug 长度受限；
- 去前缀后的模型 ID 不能重复；
- 文件必须名为 `models.json`、是普通文件且大小受限。

### 7.3 app-server 异步刷新陷阱

bundled app-server 的第一次 `model/list` 偶尔先返回内置缓存，随后才完成远端 `/models` 刷新。一次看到 Solov=0 不代表目录丢失。

`validate-live-picker.ps1` 因此最多请求 5 次、间隔 1 秒，达到预期 7+4 后立即返回。不要用一次 `model/list` 结果直接判定部署失败。

## 8. 模型命名与分流

核心规则由 `resolveRoute()` 实现：

```text
model startsWith "solov::"
  → 必须在本地 Solov allowlist
  → 去掉前缀
  → route=solov

otherwise
  → 必须在实时官方 allowlist
  → model 不改写
  → route=openai
```

因此，命名空间不是装饰，而是安全路由键。

### 8.1 官方文字请求

官方分支：

- 原始 body 不重写、不重新序列化；
- 支持保留当前 Codex 使用的 zstd body；
- 按官方 header allowlist 转发 ChatGPT auth、account、session、thread、attestation 和 Codex 身份字段；
- SSE 响应通过 pipeline 增量转发，不缓冲完整回复；
- 永远不注入 Solov Key。

### 8.2 Solov 文字请求

Solov 分支：

1. 解码 JSON（必要时先解 zstd）；
2. 将 `payload.model` 从 `solov::<id>` 改为 `<id>`；
3. 重新序列化普通 JSON；
4. 丢弃 ChatGPT/Codex 身份头；
5. 只继承 `Accept`、`Accept-Language`、`User-Agent`；
6. 在内存中注入 `Authorization: Bearer <Solov Key>`；
7. 请求固定 Solov `/responses`。

Solov `/responses/compact` 暂未完成兼容验证，当前明确返回 501。超长第三方任务应新建任务，而不是依赖远程 compact。

## 9. Solov Key 生命周期

Key 不存在于：

- `config.toml`
- `auth.json`
- `models.json`
- manifest
- router 源码
- 文档
- 正常日志

正式 key 文件：

```text
C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\secrets\solov.dpapi
```

`start-router.ps1` 的生命周期：

1. 用当前 Windows 用户上下文解密 DPAPI 字符串；
2. 临时写入父进程 `SOLOV_API_KEY` 环境变量；
3. 隐藏启动 Node 子进程；
4. 立即删除 PowerShell 进程环境变量；
5. 将托管明文引用置空；
6. 对 BSTR 调用 `ZeroFreeBSTR`。

这不是硬件级密钥隔离，但避免了明文持久化和正常日志泄露。

## 10. 图片模型适配

### 10.1 为什么不能直接返回 `image_generation_call`

对当前 `codex-cli 0.147.0-alpha.6.6` 的隔离 app-server 测试发现：

- Responses `image_generation_call` 可被 parser 接受；
- experimental raw event 中能看到完成的 `image_generation_call`；
- 但没有产生桌面需要的 `item/completed: imageGeneration`；
- turn 会完成，但桌面不会得到可见图片项。

对照测试证明，assistant message 中的本机绝对 PNG Markdown 会原样产生：

```text
item/completed: agentMessage
```

因此最终选择 Markdown 本机路径兼容层，而不是伪装原生图片事件。

### 10.2 Prompt 提取

当 `/responses` 的模型是允许的 `solov::gpt-image-*` 时，`extractImagePrompt()`：

- 要求 `stream: true`；
- `input` 可以直接是非空字符串；
- 若 `input` 是消息数组，只找最后一条 `type=message, role=user`；
- 该消息允许一个或多个非空 `input_text`，按换行连接；
- 任一 `input_image`、`input_file`、结构化或未知 content 会整体拒绝；
- 忽略 instructions、tools、developer message、assistant message、旧 user message；
- 最长 32,000 字符。

忽略顶层 tools 是必要的：真实 Codex 图片任务即使 catalog 声明不支持工具，仍可能带多个默认 tools、tool_choice 和 instructions。若看到 tools 就拒绝，客户端图片模型将永远不可用。

### 10.3 固定 Images API 请求

`buildImageGenerationBody()` 当前固定：

```json
{
  "model": "<去掉 solov:: 的图片模型>",
  "prompt": "<最后一条用户纯文本>",
  "n": 1,
  "size": "1024x1024",
  "quality": "low",
  "output_format": "png"
}
```

如果以后要让用户选择尺寸或质量，应通过受控 UI/配置字段和严格枚举实现；不要从 prompt 或任意请求字段直接接收文件路径、上游 URL 或输出名。

### 10.4 上游图片响应

只接受：

- HTTP 200；
- JSON content type；
- 无压缩或 `identity`；
- `data` 恰好一项；
- `data[0].b64_json` 为非空、规范 Base64；
- 解码后是完整、有效且受限的 PNG。

响应上限为 64 MiB。

## 11. PNG 验证

验证并非只看 8 字节 PNG signature，而是：

1. Base64 长度、字符和补位合法；
2. 解码后重新编码必须与原字符串完全一致；
3. PNG signature 正确；
4. 每个 chunk 长度和边界合法；
5. chunk 名字和保留位合法；
6. 每个 chunk CRC32 正确；
7. 拒绝未知 critical chunk；
8. IHDR 必须第一、长度 13 且不能重复；
9. 宽高范围为 1–16384；
10. bit depth 与 color type 组合合法；
11. compression=0、filter=0、interlace 只能 0 或 1；
12. PLTE 的位置、长度、颜色类型和条目数合法；
13. IDAT 必须存在且连续；
14. 索引色图必须先出现 PLTE；
15. IEND 必须长度 0、位于结尾且无尾随字节。

非法 JSON、错误 cardinality、非规范 Base64、非 PNG 或结构非法均不会创建最终图片文件。

## 12. 安全落盘

### 12.1 固定输出根

正式输出目录由 `main.mjs` 根据模块位置计算，不接受请求参数或环境变量覆盖：

```text
C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\generated-images
```

`prepareImageOutputRoot()` 要求：

- 绝对路径；
- Windows 本地盘符路径；
- 拒绝 UNC、`\\?\`、`\\.\`；
- 不能是盘符根；
- 从卷根开始逐级 `lstat`；
- 拒绝可观测到的 symlink/junction；
- 保存 canonical root 和 `dev/ino/birthtimeMs`；
- 用模块私有 `WeakSet` 给可信 output state 做品牌，外部不能伪造普通对象。

### 12.2 原子发布

`persistGeneratedImage()`：

1. 生成 16 字节随机数，即 128-bit 文件名后缀；
2. 临时名 `.solov-image-<random>.tmp`；
3. 最终名 `solov-image-<random>.png`；
4. `open(..., "wx", 0600)`，禁止覆盖；
5. 完整写入、`fsync`、校验字节数和文件身份；
6. 再次验证输出根身份；
7. 通过同目录 hard link 发布最终名；
8. 校验临时和最终对象身份一致；
9. 身份安全地移除临时名；
10. 最终校验普通文件、非链接、size、`nlink===1` 和 canonical path。

### 12.3 安全清理

删除临时或未交付图片前，`unlinkOwnedImage()` 会重新核对：

- 输出根身份未变化；
- 文件为普通文件且非链接；
- `dev/ino/birthtimeMs/size` 与本进程记录一致。

若身份不符，宁可遗留一个随机小文件，也不按路径盲删攻击者替换的文件。

客户端取消、上游错误、响应写入失败或交付前断开都会走身份安全清理。成功交付的图片不会自动删除，因为历史任务中的 Markdown 路径依赖它。

### 12.4 Windows 限制

Node 在 Windows 上没有等价于目录句柄 `openat/unlinkat` 加 no-follow 的 API。当前设计可以发现并拒绝可观测到的目录/文件替换，但不能宣称绝对抵御同一 Windows 用户在检查与删除之间进行微秒级 reparse-point 交换。

此外，`chmod(0600/0700)` 不是 NTFS ACL 审计的替代品。若威胁模型包含同一账号下任意恶意代码，应考虑原生 Win32 handle helper、独立低权限账号或更强沙箱。

## 13. 返回桌面可见图片

成功保存后，`writeResponsesImageStream()` 构造：

```markdown
![Generated image](<C:/Users/.../generated-images/solov-image-....png>)
```

它作为 assistant `output_text` 依次发出：

```text
response.created
response.output_item.added
response.output_item.done
response.completed
```

app-server 将其转为 `item/completed: agentMessage`，桌面 Markdown 渲染器读取绝对本机 PNG 路径并显示图片。

返回中不包含 Base64，不包含 revised prompt，也不让上游控制 alt text、文件名或本机路径。

## 14. 图片失败和重复请求控制

### 14.1 发现的问题

第一次正式图片 403 验收中，一次 `turn/start` 在客户端侧产生：

```text
初始请求 + Reconnecting 1/5 ... 5/5
```

路由日志因此记录了最多 6 次 Solov Image API 调用。脚本和路由本身没有循环；重发来自 bundled Codex Responses retry 层。

这对付费图片接口存在风险：即使 403 通常不计费，也不能把所有确定性失败都交给通用传输重试。

### 14.2 最终修复

以下确定性状态：

```text
400, 401, 403, 404, 409, 422
```

会被转换为 HTTP 200 的合法 Responses SSE：

```text
response.created
response.failed
```

wire error code 使用当前 bundled Codex 已知为非重试的 `invalid_prompt`；稳定本地原因放在经过净化的 message 中，例如：

```text
image_provider_access_denied: The image provider denied this request. Check provider access and balance.
```

不透传第三方私有错误正文。

最终同版本 app-server 合成 403 证明：

- Solov 伪上游只收到 1 次请求；
- turn 状态为 failed；
- 客户端收到可见 error；
- 没有 `Reconnecting`；
- 没有生成图片文件。

429、5xx 和网络错误仍保留可重试语义，因为它们可能是短时故障。

### 14.3 尚未实现的幂等

若上游实际成功并可能计费，但随后本机落盘、SSE 交付或客户端收尾失败，客户端仍可能重发。当前没有 turn 级去重缓存，也没有确认 Solov 支持 idempotency key。

这是残余计费风险。若继续强化，优先调查上游幂等能力，再设计短期 request fingerprint；不要直接缓存任意 prompt/result 而引入隐私和错误复用。

## 15. Header、身份和日志隔离

### 15.1 官方分支

官方分支允许转发经过审核的：

- `Authorization: Bearer ...` 或 `AgentAssertion ...`
- ChatGPT account ID
- `session-id`、`thread-id`
- `x-codex-*`
- `x-oai-*`
- `x-openai-*`
- 必要客户端请求 ID 和内容头

### 15.2 Solov 分支

Solov 分支不继承上述身份，只保留最小普通头并注入 Solov Key。特别要确保：

- ChatGPT Bearer/AgentAssertion 不去 Solov；
- account ID、attestation、session/thread 不去 Solov；
- `x-codex-*`、`x-oai-*`、`x-openai-*`、`x-stainless-*` 不去 Solov；
- Solov Key 不去 ChatGPT。

### 15.3 响应头

只返回有限安全响应头、请求 ID、`WWW-Authenticate`、`Retry-After` 和 rate-limit 类头。重定向的 `Location` 不暴露。

### 15.4 日志

结构化日志只记录：

```text
event, route, method, path, status, outcome, duration_ms
```

日志不记录：

- 请求/响应 body
- prompt
- Base64
- Authorization
- ChatGPT token/account ID
- Solov Key
- query string
- 生成图片绝对路径或文件名

最终正式日志模式扫描对上述敏感内容均为 0 命中。该结论是时点扫描，不是形式化信息流证明。

## 16. SSRF、代理和网络边界

防护包括：

- 两个生产上游硬编码；
- 路径白名单；
- 模型 allowlist；
- 图片只允许四个固定 ID；
- URL-shaped model、查询覆盖和 caller routing header 不参与路由；
- 所有 3xx 不跟随；
- 只监听 IPv4 `127.0.0.1`；
- Windows 系统代理只接受无认证 `http://127.0.0.1:<port>`；
- CONNECT authority 固定为真实上游 host:port；
- TLS 仍验证真实 hostname/certificate，并使用真实 hostname 作为 SNI。

不要放宽为任意 `HTTP_PROXY`、任意 base URL 或任意请求头上游覆盖，否则会破坏当前 SSRF 证明。

## 17. 模型目录的构建

`solov-model-manifest.json` 记录 Solov `/v1/models` 返回的 23 个模型和探测结果：

- 17 个文字 Responses 候选；
- 7 个经过 Responses、reasoning 和 function tool 验证后 `include=true`；
- 10 个连续两轮 HTTP 503，暂不入目录；
- audio/realtime 排除；
- 4 个图片条目使用独立 `image_picker_include=true`。

文字 `include` 和图片 `image_picker_include` 必须分开，避免把“可通过 Images API 适配”误写为“原生 Responses 文字兼容”。

`build_catalog.ps1`：

- 从 bundled Codex 模型目录复制完整 metadata schema；
- 文字模型按既定 source model 克隆并改 slug、display、description；
- 图片模型以 `gpt-5.4-mini` metadata 为基础，改成 text input、低 reasoning、关闭 search/parallel tools 等目录提示；
- 但路由不能相信 catalog 真能阻止客户端附带 tools，所以仍必须在请求层忽略/校验。

构建和静态验证：

```powershell
pwsh -NoProfile -File .\work\catalog\build_catalog.ps1

pwsh -NoProfile -File .\work\catalog\validate_catalog.ps1 `
  -CatalogPath .\work\catalog\model-catalog.json `
  -ManifestPath .\work\catalog\solov-model-manifest.json
```

validator 使用 strict UTF-8，并通过 `[char]0x00B7` 构造中点，兼容 Windows PowerShell 5.1 的无 BOM 源文件读取。

## 18. 部署事务

正式部署入口：

```powershell
pwsh -NoProfile -File .\work\install\apply-image-picker.ps1
```

### 18.1 只预检

始终先运行：

```powershell
pwsh -NoProfile -File .\work\install\apply-image-picker.ps1 -PreflightOnly
```

预检：

1. 在系统临时目录创建唯一 staging；
2. staging 与正式安装要求同卷；
3. 复制 router、catalog、manifest、README、validators；
4. 逐文件 SHA-256 验证；
5. 拒绝 staging reparse point；
6. PowerShell syntax check；
7. Node `--check`；
8. 运行 37 项 Node tests；
9. 用真实 bundled app-server 验证 catalog 11 项全部 visible；
10. 只读检查正式 health、PID 归属和当前菜单；
11. 冻结 candidate hash manifest；
12. 冻结正式 CAS baseline；
13. 返回 `ProductionChanged=false` 并清理 staging。

预检不会：

- 停路由；
- 创建正式备份；
- 修改 config/auth/key；
- 调用真实付费图片接口。

### 18.2 CAS baseline

baseline 包含：

- 正式 router 全树；
- `models.json`
- manifest
- README
- 三个 validators
- 受保护的 `config.toml`
- `auth.json`
- `secrets\solov.dpapi`
- start/stop/rollback scripts

备份完成后、停机前和确认停机后都会重新生成 baseline 并与冻结 JSON 做精确比较。任何并发变更都会中止部署。

### 18.3 备份和切换顺序

正式执行：

1. 创建 `backups\<timestamp>-image-picker`；
2. 写 `deployment-state.json: backup-started`；
3. 备份旧 router 和目标文件；
4. 写 `baseline-sha256.json`、`candidate-sha256.json`；
5. CAS 复核；
6. 写 `backup-complete-cas-verified`；
7. 用受保护 stop script 停止旧 router；
8. 验证旧 PID 消失且 health 不可达；
9. 再次 CAS；
10. 同卷 Move 旧 router 至 `router-runtime-before-image-picker`；
11. Move staging router 到正式 `router`；
12. 原子替换 manifest、README、validators；
13. 最后切换 `models.json`，它是菜单开关；
14. 写 `candidate-installed-models-switched`；
15. 启动新 router；
16. 验 health、PID/命令行、树哈希和所有目标文件；
17. 验正式菜单和共享官方名称；
18. 再验受保护文件哈希；
19. 写 `committed` 和新 PID。

`generated-images` 与 `router`、`backups` 同级，明确排除在部署备份、Move 和普通更新清理之外。

### 18.4 一个已修复的部署坑

初版 JSON 原子更新使用：

```powershell
[IO.File]::Replace($temp, $target, $null, $true)
```

当前 .NET 对空 backup path 抛出 `The path is empty`。该次失败发生在停路由和正式替换前，正式状态未变。

最终改成同目录：

```powershell
[IO.File]::Move($temp, $target, $true)
```

并在前后做 SHA-256 验证。

## 19. 回滚的两种含义

### 19.1 部署过程中自动回滚

若 `apply-image-picker.ps1` 在激活阶段失败，会：

1. 写 `rollback-started`；
2. 停止候选 router；
3. 将失败 router 留在 backup 作为证据；
4. 优先将 `router-runtime-before-image-picker` Move 回正式目录；
5. 否则从 backup/router 恢复；
6. 恢复 manifest、README、validators、models；
7. 验 router 树；
8. 重启并验 health/PID；
9. 写 `rolled-back`。

### 19.2 `rollback.ps1` 是完全退出双路由

`work/install/rollback.ps1` 不是“恢复上一个 router snapshot”。它会：

- 停止本机 router；
- 删除 HKCU 自启动；
- 备份当前 config；
- 恢复最初实施前的 `config.toml`；
- 让客户端回到订阅直连。

因此，不要为了回到上一版 image-picker 直接运行 generic rollback。

已提交后若要恢复某个 router/catalog snapshot，目前没有专用一键脚本。后续会话应基于目标 backup 的 baseline/candidate manifests，先备份当前版本，再写一个受审计的 snapshot restore。

备份可信度：

- `20260812-123150-image-picker`：当前最终 committed 事务；
- `20260812-121636-image-picker`：首次图片下拉 committed 事务；
- `20260812-121436-image-picker`：只到 `backup-started`，未发生正式替换，不能当已提交版本恢复源。

## 20. 启动、停止和自启动

状态：

```powershell
& "$env:LOCALAPPDATA\OpenAI\CodexDualRouter\status.ps1"
```

停止：

```powershell
& "$env:LOCALAPPDATA\OpenAI\CodexDualRouter\stop-router.ps1"
```

启动：

```powershell
& "$env:LOCALAPPDATA\OpenAI\CodexDualRouter\start-router.ps1"
```

安全特征：

- PID 文件必须可解析；
- PID 必须是 `node.exe`；
- 命令行必须包含正式 `router\src\main.mjs`；
- 不匹配时拒绝杀进程；
- stale PID 只清理 PID 文件；
- Node 要求 24+；
- 启动最多等待约 5 秒 health；
- 启动失败只停止已验证属于本路由的进程。

自启动使用当前用户：

```text
HKCU\Software\Microsoft\Windows\CurrentVersion\Run\CodexDualRouter
```

## 21. 验证矩阵

### 21.1 路由单元测试

```powershell
Push-Location .\work\router
try { npm test } finally { Pop-Location }
```

当前：`37 passed, 0 failed`。

### 21.2 独立安全黑盒

```powershell
python .\work\security\router_security_harness.py `
  --router-command node .\work\security\actual_router_test_launcher.mjs
```

当前：`29 passed, 0 failed`。全部使用合成凭据和回环伪上游，不读取正式 key/auth，不产生第三方费用。

29 项覆盖：

1. 仅回环监听
2. 未知路径拒绝
3. 未知模型拒绝
4. 官方目录保留且追加 Solov
5. 动态官方模型可 POST
6. 官方目录错误不降级成 Solov-only
7. Solov 文字身份隔离
8. 四图片模型前缀和身份隔离
9. 图片拒绝官方/未知模型
10. 图片 SSRF/redirect
11. 图片成功和错误语义
12. 图片 prompt、隔离和 SSE
13. 只取最新 user input_text
14. 歧义/多模态拒绝
15. 非法上游图片和状态
16. prompt 不能指定路径
17. output root 替换失败关闭
18. 取消后零文件
19. 最终为普通私有文件
20. 8 路并发唯一原子文件
21. 日志无 prompt/Base64/凭据
22. OpenAI 不收 Solov Key
23. AgentAssertion 官方透传
24. 普通路由 SSRF
25. 不跟随 redirect
26. SSE 增量流式
27. 取消传播
28. 401 语义
29. 429、Retry-After、request ID 语义

### 21.3 bundled app-server 全链合成成功

```powershell
pwsh -NoProfile -File .\work\validate-full-chain-image-event.ps1 `
  -SolovStatus 200
```

验证：

- 图片模型 visible；
- 官方目录合并；
- 只调用 1 次伪 Solov；
- `solov::` 正确剥离；
- ChatGPT 身份不泄漏；
- agentMessage Markdown 保留；
- PNG 位于受控目录；
- turn completed；
- 无真实 auth/key/外网。

### 21.4 bundled app-server 确定性 403

```powershell
pwsh -NoProfile -File .\work\validate-full-chain-image-event.ps1 `
  -SolovStatus 403
```

验证：

- 伪 Solov 只调用 1 次；
- turn failed；
- error 可见；
- 无 `Reconnecting`；
- 零图片文件；
- 不泄漏伪上游私有正文。

### 21.5 正式菜单

```powershell
$install = "$env:LOCALAPPDATA\OpenAI\CodexDualRouter"

& "$install\validate-live-picker.ps1" `
  -MinimumOfficialModels 1 `
  -MinimumSolovModels 11 `
  -MinimumSolovTextModels 7 `
  -MinimumSolovImageModels 4 `
  -ExpectedSolovTextModels 7 `
  -ExpectedSolovImageModels 4 `
  -UseCurrentConfigCopy
```

该命令读取当前 ChatGPT 登录的实时目录，但不会调用 Solov 生成接口。

### 21.6 正式文字响应

```powershell
& "$install\validate-live-responses.ps1"
```

会真实调用官方和 Solov 文字上游。当前记录：

- 官方 `gpt-5.4-mini` 成功；
- Solov 请求正确到达 `xm.solov.cc`，但当前账户返回 HTTP 403，余额 `-$3.082328`。

### 21.7 正式付费图片

```powershell
& "$install\validate-live-image-picker.ps1" `
  -Model 'solov::gpt-image-1'
```

只应在确认 Solov 余额后显式运行。它会发真实图片请求，可能计费。部署脚本只安装它，绝不自动执行。

当前正式验收因同一余额状态返回 403，没有生成新文件。历史上 `gpt-image-1` 直连和独立本机图片路由均成功返回过 PNG，但这不证明当前余额已恢复。

## 22. 常见问题定位

### 22.1 错误 URL 显示 `127.0.0.1:43120/responses`

这是预期行为，表示请求进入了本机路由。真正上游要看：

- 模型是否带 `solov::`；
- 路由结构化日志的 `route`；
- 上游返回的真实状态。

不要因为错误 UI 显示回环 URL 就判定请求没有去 `xm.solov.cc`。

### 22.2 `token quota is not enough` 或 `用户额度不足`

如果模型是 `solov::...`，这通常是第三方账户在模型执行前的额度校验，不是 ChatGPT 订阅错误，也不是本机端口故障。

先检查：

1. 当前选中模型；
2. router 日志中的 `route=solov` 或 `solov_image`；
3. 第三方后台余额；
4. 是否使用了同一枚预期 key。

图片确定性 403 现在只会调用一次；Solov 文字分支仍保留普通 Responses 上游状态，客户端可能显示重连。

### 22.3 官方模型突然少了

先运行 `validate-live-picker.ps1`，不要只看第一次 `model/list`。官方目录由 ChatGPT 实时返回，也可能因账号、客户端版本或服务端策略发生变化。

确认：

- config 没有 `model_catalog_json`；
- `model_provider="openai"`；
- router `/health` 正常；
- `/models` 日志是 official 200；
- validator 有界重试后的最终数量。

### 22.4 Solov 菜单完全消失

检查：

- 正式 `models.json` 是否为 11 项；
- `DUAL_ROUTER_CATALOG` 是否指向正式 `models.json`；
- router 是否在目录更新后重启；
- 本地 catalog 是否只含 `solov::` slug；
- validator 是否等待目录刷新。

### 22.5 图片任务完成但界面无图

检查：

- 路由是否仍返回了 native `image_generation_call`，而不是 agentMessage Markdown；
- `generated-images` 中最终 PNG 是否存在；
- Markdown 是否是绝对本机路径并使用 `/`；
- app-server 是否产生 `item/completed: agentMessage`；
- 用户是否手动删除了历史 PNG。

### 22.6 图片出现 5/5 重连

正式当前 400/401/403/404/409/422 已 fail-fast。如果仍出现：

- 确认正式 `router.mjs` SHA 与最新 candidate 一致；
- 查日志 outcome 是否为 `terminal_upstream_status`；
- 429、5xx、网络错误仍会正常重试；
- 不要把所有 429 都改成终态，先确认是余额配额还是短时限流。

### 22.7 路由健康但请求失败

`/health` 只证明进程和端口存活，不证明：

- ChatGPT 登录有效；
- Solov key 有余额；
- 目标模型当前可用；
- 上游没有限流/过载。

应结合模型、route、HTTP status 和上游余额判断。

## 23. 扩展到另一个第三方 Provider

建议按以下顺序，而不是直接追加模型名：

1. 为新 Provider 分配不可冲突的 slug 前缀，例如 `vendorx::`。
2. 固定生产 base URL、协议、hostname、port 和 base path。
3. 为其创建独立凭据来源，禁止复用 ChatGPT auth。
4. 建独立 request header allowlist，从零构造，不采用“删除几个已知头”的黑名单。
5. 探测 `/models`，生成无密钥 manifest。
6. 对每个文字模型做 Responses + reasoning + tool smoke。
7. 只把实际成功模型加入本地目录。
8. 扩展 catalog parser，使 slug 只属于对应命名空间。
9. 扩展 `resolveRoute()`，保持未知模型本机拒绝。
10. 为目录错误、身份隔离、SSRF、redirect、401/429、SSE 和取消增加黑盒测试。
11. 若有图片/音频等非文字接口，为每种协议单独写适配器，不要假定目录可见等于协议兼容。
12. 先做完全回环的 bundled app-server 全链测试，再做一次真实付费烟测。
13. 用事务部署，最后切换 `models.json`。

需要接受一个架构限制：客户端模型菜单本身没有逐项 Provider 路由语义，因此新 Provider 仍需要统一回环路由，或者修改/自建客户端。

## 24. 扩展图片模型

加入一个新图片模型至少要同时更新：

1. `solov-model-manifest.json` 的 upstream evidence；
2. `image_picker_include=true`；
3. `build_catalog.ps1` 图片顺序和显示名；
4. `config.mjs` 固定图片 allowlist；
5. 图片路由单元测试；
6. 安全黑盒的严格前缀和路径断言；
7. bundled app-server model/list；
8. Images API 直接烟测；
9. 成功/确定性失败全链合成；
10. 一次显式真实付费验收。

不要因为 `/v1/models` 列出了模型就直接放进菜单。至少要确认：

- 真实 endpoint；
- 请求 schema；
- 返回格式；
- Base64/URL 形式；
- 图片格式；
- 尺寸/质量参数；
- 错误和计费语义。

当前四个图片模型中，`gpt-image-1` 有直接 HTTP 200 smoke 证据；另外三个是上游 advertised 且通过本地固定适配目录验证，但没有分别完成付费成功烟测。文档和 UI 不应把四者都描述成“当前逐一实测成功”。

## 25. 当前已知限制

1. 本机适配层依赖 Codex app-server 和模型目录协议，客户端大版本升级后必须重跑全链测试。
2. Solov `/responses/compact` 未验证。
3. 图片仅支持文字生成，不支持编辑、变体、输入图片或文件。
4. 图片参数当前固定为 1024×1024、low、PNG、n=1。
5. 成功图片长期保留，没有容量/保留期管理器。
6. 上游成功后回程失败仍缺少严格幂等保护。
7. 429/5xx/网络错误可能触发客户端重试。
8. 同一 Windows 用户下的极窄 reparse TOCTOU 不能由纯 Node 完全消除。
9. Windows `chmod` 不是 ACL 证明。
10. 第三方余额、模型可用性和价格是动态外部状态。
11. 当前 Solov 真实文字/图片验收被余额 403 阻止。
12. 三个额外图片模型尚未逐一完成付费成功烟测。

## 26. 给其他会话的最短接手顺序

另一个会话接手时，建议按下面顺序，不要直接改代码：

1. 阅读本文。
2. 阅读 `outputs\Codex双路由使用与恢复说明.md` 了解现场状态。
3. 运行 `status.ps1`。
4. 读取最新 `deployment-state.json`、`baseline-sha256.json`、`candidate-sha256.json`。
5. 运行正式菜单 validator。
6. 运行 37 项 Node tests。
7. 运行 29 项合成安全黑盒。
8. 运行成功和 403 两种 bundled app-server 全链合成。
9. 只读比较正式树与工作区 SHA。
10. 明确本次任务是目录、文字路由、图片适配、安全、部署还是上游余额问题。
11. 所有修改先 `apply-image-picker.ps1 -PreflightOnly`。
12. 涉及真实图片的验证必须明确只发一次，并在余额确认后执行。

## 27. 最终验收快照

最终实现的已验证事实：

- 正式事务为 `committed`；
- 路由 PID/监听/health 一致；
- 正式 router 和 catalog 与工作区候选 SHA 一致；
- 目录为官方实时模型 + Solov 7 text + 4 image；
- config、auth、encrypted key hashes 保持原基线；
- 固定上游仍是 ChatGPT Codex 和 `xm.solov.cc/v1`；
- `generated-images` 当前 0 文件、0 tmp；
- 日志敏感模式扫描 0 命中；
- Node tests 37/37；
- 安全黑盒 29/29；
- bundled 成功图片全链只调用 1 次伪上游并返回可见 agentMessage；
- bundled 确定性 403 全链只调用 1 次伪上游、无重连、零文件；
- 官方真实文字请求成功；
- Solov 真实文字和图片当前因第三方余额 HTTP 403 未成功。

这组结论应被表述为“本机路由、目录、隔离、兼容和失败语义已经完成；第三方真实成功仍受当前账户余额和服务状态约束”。

---

## 28. 可直接发给另一个会话的接手提示

下面这段可以直接复制给另一个 Codex 会话。它会先建立正确边界，再决定是否修改：

```text
请先完整阅读以下技术交接文档，不要根据聊天摘要猜测实现：
C:\Users\<USER>\Documents\Codex\2026-08-12\chatgpt-api\outputs\Codex双路由与图片模型下拉实现技术交接.md

工作区：
C:\Users\<USER>\Documents\Codex\2026-08-12\chatgpt-api

正式安装：
C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter

第一阶段只做只读核对：
1. 检查正式 /health、PID、43120 监听进程和启动命令行是否一致。
2. 检查正式 router、models.json、manifest 与最新 committed candidate 清单是否一致。
3. 确认 config.toml、auth.json、secrets/solov.dpapi、start/stop/rollback 脚本未被修改。
4. 不读取、回显或迁移明文 API Key；不要让 Solov 收到 ChatGPT 身份头。
5. 不要把原生订阅模型改名，也不要用静态目录覆盖官方实时模型目录。
6. 如需修改，先在 work/ 下完成实现，并依次运行 router 单测、安全黑盒、合成全链测试和部署预检。
7. 只有我明确授权后才执行正式部署或真实付费图片请求。

请先报告：当前运行状态、代码/正式版本是否一致、你准备修改的精确文件和风险；然后等待我的方向。
```

如果另一个会话要直接继续开发，可以把最后一句改为：

```text
完成只读核对后，在不修改 auth、订阅登录、加密密钥和原生官方模型命名的前提下，完成指定改动、全套验证、事务部署与部署后审计。
```
