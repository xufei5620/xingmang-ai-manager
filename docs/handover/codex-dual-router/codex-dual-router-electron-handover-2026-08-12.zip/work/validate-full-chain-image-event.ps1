[CmdletBinding()]
param(
    [int]$TimeoutSeconds = 45,
    [ValidateSet(200, 403)]
    [int]$SolovStatus = 200
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$Mode = if ($SolovStatus -eq 403) { 'Terminal403' } else { 'Success' }

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

function Send-AppMessage {
    param([Diagnostics.Process]$Process, [hashtable]$Message)
    $Process.StandardInput.WriteLine(($Message | ConvertTo-Json -Compress -Depth 30))
    $Process.StandardInput.Flush()
}

function Read-AppLine {
    param(
        [Diagnostics.Process]$Process,
        [Collections.Generic.List[object]]$Messages,
        [DateTime]$Deadline
    )
    $remaining = [Math]::Max(1, [int]($Deadline - [DateTime]::UtcNow).TotalMilliseconds)
    $task = $Process.StandardOutput.ReadLineAsync()
    if (-not $task.Wait($remaining)) { throw 'Timed out waiting for app-server output.' }
    $line = $task.Result
    if ($null -eq $line) { throw 'app-server exited unexpectedly.' }
    try { $message = $line | ConvertFrom-Json -Depth 100 } catch { return $null }
    $Messages.Add($message) | Out-Null
    return $message
}

function Read-AppResponse {
    param(
        [Diagnostics.Process]$Process,
        [Collections.Generic.List[object]]$Messages,
        [int]$Id,
        [DateTime]$Deadline
    )
    while ([DateTime]::UtcNow -lt $Deadline) {
        $message = Read-AppLine -Process $Process -Messages $Messages -Deadline $Deadline
        if ($null -ne $message -and $message.PSObject.Properties['id'] -and $message.id -eq $Id) {
            return $message
        }
    }
    throw "Timed out waiting for app-server response $Id."
}

function Read-AppNotification {
    param(
        [Diagnostics.Process]$Process,
        [Collections.Generic.List[object]]$Messages,
        [string]$Method,
        [DateTime]$Deadline
    )
    $existing = $Messages | Where-Object { $_.PSObject.Properties['method'] -and $_.method -ceq $Method } | Select-Object -Last 1
    if ($null -ne $existing) { return $existing }
    while ([DateTime]::UtcNow -lt $Deadline) {
        $message = Read-AppLine -Process $Process -Messages $Messages -Deadline $Deadline
        if ($null -ne $message -and $message.PSObject.Properties['method'] -and $message.method -ceq $Method) {
            return $message
        }
    }
    throw "Timed out waiting for app-server notification $Method."
}

$launcherPath = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'full_chain_image_probe.mjs'))
$catalogPath = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'catalog\model-catalog.json'))
Assert-True (Test-Path -LiteralPath $launcherPath -PathType Leaf) "Launcher not found: $launcherPath"
Assert-True (Test-Path -LiteralPath $catalogPath -PathType Leaf) "Catalog not found: $catalogPath"

$package = Get-AppxPackage -Name 'OpenAI.Codex' | Sort-Object Version -Descending | Select-Object -First 1
Assert-True ($null -ne $package) 'OpenAI.Codex is not installed.'
$sourceExe = Join-Path $package.InstallLocation 'app\resources\codex.exe'
Assert-True (Test-Path -LiteralPath $sourceExe -PathType Leaf) "Bundled codex.exe not found: $sourceExe"

$tempBase = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
$tempRoot = Join-Path $tempBase ('codex-full-chain-image-' + [Guid]::NewGuid().ToString('N'))
$isolatedHome = Join-Path $tempRoot 'home'
$probeRoot = Join-Path $tempRoot 'probe'
$copiedExe = Join-Path $tempRoot 'codex.exe'
$routerProcess = $null
$appServer = $null
$messages = [Collections.Generic.List[object]]::new()
$routerSummary = $null
$imagePath = $null
$imageBytes = $null

try {
    [IO.Directory]::CreateDirectory($isolatedHome) | Out-Null
    [IO.Directory]::CreateDirectory($probeRoot) | Out-Null
    [IO.File]::WriteAllBytes($copiedExe, [IO.File]::ReadAllBytes($sourceExe))

    $routerInfo = [Diagnostics.ProcessStartInfo]::new()
    $routerInfo.FileName = 'node'
    $routerInfo.WorkingDirectory = $PSScriptRoot
    $routerInfo.UseShellExecute = $false
    $routerInfo.CreateNoWindow = $true
    $routerInfo.RedirectStandardInput = $true
    $routerInfo.RedirectStandardOutput = $true
    $routerInfo.RedirectStandardError = $true
    $routerInfo.Environment['FULL_CHAIN_PROBE_MODE'] = '1'
    $routerInfo.Environment['PROBE_ROOT'] = $probeRoot
    $routerInfo.Environment['PROBE_SOLOV_STATUS'] = if ($Mode -ceq 'Terminal403') { '403' } else { '200' }
    $routerInfo.ArgumentList.Add($launcherPath)
    $routerProcess = [Diagnostics.Process]::new()
    $routerProcess.StartInfo = $routerInfo
    Assert-True ($routerProcess.Start()) 'Failed to start the isolated full-chain router.'
    $readyTask = $routerProcess.StandardOutput.ReadLineAsync()
    Assert-True ($readyTask.Wait(10000)) 'The full-chain router did not become ready.'
    Assert-True ($readyTask.Result.StartsWith('READY ', [StringComparison]::Ordinal)) 'Unexpected router startup output.'
    $ready = $readyTask.Result.Substring(6) | ConvertFrom-Json
    $routerUrl = [string]$ready.routerUrl
    $outputRoot = [IO.Path]::GetFullPath([string]$ready.outputRoot)
    $canonicalProbeRoot = [IO.Path]::GetFullPath($probeRoot).TrimEnd([IO.Path]::DirectorySeparatorChar)
    Assert-True ($outputRoot.StartsWith($canonicalProbeRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) 'Router output root escaped the controlled probe root.'
    $modelsRequest = [Net.Http.HttpRequestMessage]::new([Net.Http.HttpMethod]::Get, ($routerUrl + '/models?client_version=0.147.0-alpha.6.6'))
    $modelsRequest.Headers.Authorization = [Net.Http.Headers.AuthenticationHeaderValue]::new('Bearer', '<SYNTHETIC_API_KEY>')
    $httpClient = [Net.Http.HttpClient]::new()
    try {
        $modelsResponse = $httpClient.Send($modelsRequest)
        Assert-True ($modelsResponse.StatusCode -eq [Net.HttpStatusCode]::OK) "Router /models returned $($modelsResponse.StatusCode)."
        $mergedModels = $modelsResponse.Content.ReadAsStringAsync().GetAwaiter().GetResult() | ConvertFrom-Json -Depth 100
        Assert-True (@($mergedModels.models | Where-Object slug -ceq 'gpt-5.4-mini').Count -eq 1) 'Merged /models omitted the fake official model.'
        Assert-True (@($mergedModels.models | Where-Object slug -ceq 'solov::gpt-image-1').Count -eq 1) 'Merged /models omitted the local image model.'
    }
    finally {
        $modelsRequest.Dispose()
        $httpClient.Dispose()
    }

    $appInfo = [Diagnostics.ProcessStartInfo]::new()
    $appInfo.FileName = $copiedExe
    $appInfo.WorkingDirectory = $tempRoot
    $appInfo.UseShellExecute = $false
    $appInfo.CreateNoWindow = $true
    $appInfo.RedirectStandardInput = $true
    $appInfo.RedirectStandardOutput = $true
    $appInfo.RedirectStandardError = $true
    $appInfo.Environment['CODEX_HOME'] = $isolatedHome
    $appInfo.Environment['DO_NOT_TRACK'] = '1'
    $appInfo.Environment['OTEL_SDK_DISABLED'] = 'true'
    $syntheticAuth = [ordered]@{
        OPENAI_API_KEY = '<SYNTHETIC_API_KEY>'
    } | ConvertTo-Json -Compress
    [IO.File]::WriteAllText((Join-Path $isolatedHome 'auth.json'), $syntheticAuth, [Text.UTF8Encoding]::new($false))
    foreach ($argument in @(
        '--config', 'model_provider="openai"',
        '--config', ('openai_base_url="' + $routerUrl + '"'),
        '--config', ('model_catalog_json=' + ($catalogPath | ConvertTo-Json -Compress)),
        'app-server'
    )) { $appInfo.ArgumentList.Add($argument) }
    $appServer = [Diagnostics.Process]::new()
    $appServer.StartInfo = $appInfo
    Assert-True ($appServer.Start()) 'Failed to start the isolated bundled app-server.'

    $deadline = [DateTime]::UtcNow.AddSeconds($TimeoutSeconds)
    Send-AppMessage -Process $appServer -Message ([ordered]@{
        id = 1; method = 'initialize'; params = [ordered]@{
            clientInfo = [ordered]@{ name = 'full-chain-image-probe'; title = 'Full Chain Image Probe'; version = '1.0.0' }
            capabilities = [ordered]@{ experimentalApi = $true }
        }
    })
    $initialize = Read-AppResponse -Process $appServer -Messages $messages -Id 1 -Deadline $deadline
    Assert-True ($null -eq $initialize.PSObject.Properties['error']) 'initialize returned an error.'
    Send-AppMessage -Process $appServer -Message ([ordered]@{ method = 'initialized'; params = @{} })

    Send-AppMessage -Process $appServer -Message ([ordered]@{
        id = 2; method = 'model/list'; params = [ordered]@{ cursor = $null; includeHidden = $false; limit = 100 }
    })
    $modelList = Read-AppResponse -Process $appServer -Messages $messages -Id 2 -Deadline $deadline
    Assert-True ($null -eq $modelList.PSObject.Properties['error']) 'model/list returned an error.'
    $selected = @($modelList.result.data | Where-Object model -ceq 'solov::gpt-image-1')
    Assert-True ($selected.Count -eq 1 -and $selected[0].hidden -eq $false) 'The image model was not visible in model/list.'

    Send-AppMessage -Process $appServer -Message ([ordered]@{
        id = 3; method = 'thread/start'; params = [ordered]@{
            model = 'solov::gpt-image-1'; modelProvider = 'openai'; cwd = $tempRoot
            approvalPolicy = 'never'; ephemeral = $true
        }
    })
    $threadStart = Read-AppResponse -Process $appServer -Messages $messages -Id 3 -Deadline $deadline
    Assert-True ($null -eq $threadStart.PSObject.Properties['error']) 'thread/start returned an error.'
    Assert-True ([string]$threadStart.result.model -ceq 'solov::gpt-image-1') 'thread/start changed the selected model.'
    $threadId = [string]$threadStart.result.thread.id

    Send-AppMessage -Process $appServer -Message ([ordered]@{
        id = 4; method = 'turn/start'; params = [ordered]@{
            threadId = $threadId
            input = @([ordered]@{ type = 'text'; text = '<SYNTHETIC_IMAGE_INPUT>' })
        }
    })
    $turnStart = Read-AppResponse -Process $appServer -Messages $messages -Id 4 -Deadline $deadline
    Assert-True ($null -eq $turnStart.PSObject.Properties['error']) 'turn/start returned an error.'
    $turnCompleted = Read-AppNotification -Process $appServer -Messages $messages -Method 'turn/completed' -Deadline $deadline
    $eventSummary = @($messages | Where-Object { $_.PSObject.Properties['method'] } | ForEach-Object {
        $itemType = if ($_.PSObject.Properties['params'] -and $_.params.PSObject.Properties['item']) { [string]$_.params.item.type } else { '' }
        [string]$_.method + $(if ([string]::IsNullOrWhiteSpace($itemType)) { '' } else { ':' + $itemType })
    })
    $safeErrors = @($messages | Where-Object { $_.PSObject.Properties['method'] -and $_.method -ceq 'error' } | ForEach-Object {
        $text = if ($_.params.PSObject.Properties['error']) { [string]$_.params.error.message } elseif ($_.params.PSObject.Properties['message']) { [string]$_.params.message } else { '' }
        if ($text.Length -gt 300) { $text = $text.Substring(0, 300) }
        $text
    })
    $agentEvents = @($messages | Where-Object {
        $_.PSObject.Properties['method'] -and $_.method -ceq 'item/completed' -and $_.params.item.type -ceq 'agentMessage'
    })
    if ($Mode -ceq 'Terminal403') {
        Assert-True ($turnCompleted.params.turn.status -ceq 'failed') "The terminal-403 turn status was $($turnCompleted.params.turn.status). Events: $($eventSummary -join ', '). Errors: $($safeErrors -join ' | ')."
        Assert-True ($agentEvents.Count -eq 0) "A terminal image failure unexpectedly emitted $($agentEvents.Count) agent messages."
        Assert-True (@(Get-ChildItem -LiteralPath $outputRoot -File).Count -eq 0) 'A terminal image failure unexpectedly created an image file.'
        $safeErrorText = $safeErrors -join ' | '
        Assert-True ($safeErrorText.Contains('image_provider_access_denied', [StringComparison]::Ordinal) -or $safeErrorText.Contains('image provider denied', [StringComparison]::OrdinalIgnoreCase)) "The stable terminal image error was not visible. Errors: $safeErrorText"
        Assert-True (-not $safeErrorText.Contains('synthetic-private-upstream-code', [StringComparison]::Ordinal)) 'Private upstream error details leaked through app-server.'
        $serializedMessages = $messages | ConvertTo-Json -Compress -Depth 100
        Assert-True (-not $serializedMessages.Contains('Reconnecting', [StringComparison]::OrdinalIgnoreCase)) 'The terminal image failure triggered a reconnect event.'
    }
    else {
        Assert-True ($turnCompleted.params.turn.status -ceq 'completed') "The full-chain turn status was $($turnCompleted.params.turn.status). Events: $($eventSummary -join ', '). Errors: $($safeErrors -join ' | ')."
        Assert-True ($agentEvents.Count -eq 1) "Expected one completed agentMessage, got $($agentEvents.Count)."
        $markdown = [string]$agentEvents[0].params.item.text
        Assert-True ($markdown.StartsWith('![Generated image](<', [StringComparison]::Ordinal) -and $markdown.EndsWith('>)', [StringComparison]::Ordinal)) 'The final agentMessage was not the expected image Markdown.'
        $imagePath = $markdown.Substring('![Generated image](<'.Length, $markdown.Length - '![Generated image](<'.Length - 2).Replace('/', '\')
        $imagePath = [IO.Path]::GetFullPath($imagePath)
        Assert-True ($imagePath.StartsWith($outputRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) 'The Markdown image path escaped outputRoot.'
        Assert-True (Test-Path -LiteralPath $imagePath -PathType Leaf) 'The Markdown image file did not exist.'
        $imageBytes = [IO.File]::ReadAllBytes($imagePath)
        Assert-True ($imageBytes.Length -eq 68) "Unexpected PNG length: $($imageBytes.Length)."
        Assert-True ([Convert]::ToHexString($imageBytes[0..7]) -ceq '89504E470D0A1A0A') 'The persisted image did not have a PNG signature.'
        Assert-True (@(Get-ChildItem -LiteralPath $outputRoot -File).Count -eq 1) 'The controlled output root did not contain exactly one file.'
    }

    $routerProcess.StandardInput.WriteLine('shutdown')
    $routerProcess.StandardInput.Flush()
    $summaryDeadline = [DateTime]::UtcNow.AddSeconds(10)
    while ([DateTime]::UtcNow -lt $summaryDeadline) {
        $remaining = [Math]::Max(1, [int]($summaryDeadline - [DateTime]::UtcNow).TotalMilliseconds)
        $lineTask = $routerProcess.StandardOutput.ReadLineAsync()
        if (-not $lineTask.Wait($remaining)) { break }
        $line = $lineTask.Result
        if ($null -eq $line) { break }
        if ($line.StartsWith('SUMMARY ', [StringComparison]::Ordinal)) {
            $routerSummary = $line.Substring(8) | ConvertFrom-Json -Depth 30
            break
        }
    }
    Assert-True ($null -ne $routerSummary) 'The router did not return its shutdown summary.'
    Assert-True ($routerSummary.openAiModelsRequestCount -ge 1) 'The fake OpenAI /models endpoint was not used.'
    Assert-True ($routerSummary.solovRequestCount -eq 1) "Expected exactly one fake Solov image request, got $($routerSummary.solovRequestCount)."
    Assert-True ($routerSummary.capturedSolovRequest.path -ceq '/solov/images/generations') 'The router used the wrong Solov path.'
    Assert-True ($routerSummary.capturedSolovRequest.authorizationMatchesSyntheticKey -eq $true) 'The synthetic Solov authorization was not forwarded correctly.'
    Assert-True ($routerSummary.capturedSolovRequest.chatgptAccountIdAbsent -eq $true) 'ChatGPT account identity leaked to the fake Solov endpoint.'
    Assert-True ($routerSummary.capturedSolovRequest.payload.model -ceq 'gpt-image-1') 'The prefixed picker model was not mapped to the correct upstream model.'
    if ($Mode -ceq 'Terminal403') {
        Assert-True ($routerSummary.files.Count -eq 0) 'Terminal image failure left an output file.'
        Assert-True ($routerSummary.logsContainPrivateUpstreamError -eq $false) 'Private upstream error details leaked into router logs.'
    }
    else {
        Assert-True ($routerSummary.files.Count -eq 1 -and $routerSummary.files[0].path -ceq $imagePath) 'Router output summary did not match the Markdown file.'
    }
    Assert-True ($routerSummary.logsContainSyntheticKey -eq $false -and $routerSummary.logsContainGeneratedPath -eq $false) 'Router logs contained a synthetic key or generated path.'

    [pscustomobject]@{
        ExitCode = 0
        PackageVersion = $package.Version.ToString()
        AppServerBinaryVersion = (& $copiedExe --version | Out-String).Trim()
        SelectedModel = [string]$threadStart.result.model
        ProbeMode = $Mode
        ModelVisible = $true
        FakeOpenAiModelsRequests = [int]$routerSummary.openAiModelsRequestCount
        FakeSolovImageRequests = [int]$routerSummary.solovRequestCount
        SolovPath = [string]$routerSummary.capturedSolovRequest.path
        UpstreamImageModel = [string]$routerSummary.capturedSolovRequest.payload.model
        NotificationMethod = if ($Mode -ceq 'Terminal403') { 'error' } else { [string]$agentEvents[0].method }
        ItemType = if ($Mode -ceq 'Terminal403') { $null } else { [string]$agentEvents[0].params.item.type }
        MarkdownPreserved = ($Mode -ceq 'Success')
        ImagePathInsideOutputRoot = ($Mode -ceq 'Success')
        ImageExists = ($Mode -ceq 'Success')
        PngBytes = if ($Mode -ceq 'Terminal403') { 0 } else { $imageBytes.Length }
        PngSignatureValid = ($Mode -ceq 'Success')
        TurnStatus = [string]$turnCompleted.params.turn.status
        RealAuthRead = $false
        NetworkUpstreams = 'loopback-only'
        SensitivePromptCaptureWritten = $false
        CleanupExpected = $true
    }
}
finally {
    if ($null -ne $appServer -and -not $appServer.HasExited) {
        $appServer.Kill($true)
        $appServer.WaitForExit(5000) | Out-Null
    }
    if ($null -ne $routerProcess -and -not $routerProcess.HasExited) {
        try {
            $routerProcess.StandardInput.WriteLine('shutdown')
            $routerProcess.StandardInput.Flush()
            if (-not $routerProcess.WaitForExit(5000)) { $routerProcess.Kill($true) }
        }
        catch { $routerProcess.Kill($true) }
        $routerProcess.WaitForExit(5000) | Out-Null
    }
    $resolvedRoot = [IO.Path]::GetFullPath($tempRoot)
    $expectedPrefix = $tempBase.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if ($resolvedRoot.StartsWith($expectedPrefix, [StringComparison]::OrdinalIgnoreCase) -and
        [IO.Path]::GetFileName($resolvedRoot).StartsWith('codex-full-chain-image-', [StringComparison]::Ordinal) -and
        [IO.Directory]::Exists($resolvedRoot)) {
        Get-ChildItem -LiteralPath $resolvedRoot -Force -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
            try { $_.Attributes = [IO.FileAttributes]::Normal } catch {}
        }
        [IO.Directory]::Delete($resolvedRoot, $true)
    }
}
