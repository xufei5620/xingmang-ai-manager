[CmdletBinding()]
param(
    [string]$InstallRoot = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$pidPath = Join-Path $InstallRoot 'run\router.pid'
$routerEntry = [IO.Path]::GetFullPath((Join-Path $InstallRoot 'router\src\main.mjs'))

if (-not (Test-Path -LiteralPath $pidPath -PathType Leaf)) {
    Write-Output 'Codex dual router is not running (no PID file).'
    exit 0
}

$storedPid = 0
if (-not [int]::TryParse(([IO.File]::ReadAllText($pidPath)).Trim(), [ref]$storedPid)) {
    throw "Invalid router PID file: $pidPath"
}

$process = Get-CimInstance Win32_Process -Filter "ProcessId = $storedPid" -ErrorAction SilentlyContinue
if ($null -eq $process) {
    Remove-Item -LiteralPath $pidPath -Force
    Write-Output 'Removed stale router PID file.'
    exit 0
}

if ($process.Name -ne 'node.exe' -or
    [string]::IsNullOrWhiteSpace($process.CommandLine) -or
    $process.CommandLine.IndexOf($routerEntry, [StringComparison]::OrdinalIgnoreCase) -lt 0) {
    throw "PID $storedPid does not belong to the Codex dual router; nothing was stopped."
}

Stop-Process -Id $storedPid -Force
Remove-Item -LiteralPath $pidPath -Force -ErrorAction SilentlyContinue
Write-Output "Stopped Codex dual router process $storedPid."
