# Codex dual-upstream loopback router

This is a small, dependency-free Node.js router for a Codex desktop setup in
which the built-in `openai` provider still owns the session, while explicit
`solov::` model IDs use the Solov Responses or Image API.

The production executable has two hard-coded upstreams:

- OpenAI subscription traffic: `https://chatgpt.com/backend-api/codex`
- Solov traffic: `https://xm.solov.cc/v1`

It listens only on IPv4 `127.0.0.1`, never follows redirects, and accepts model
traffic only on `POST /responses`, `POST /responses/compact`, and
`POST /images/generations`. Text requests require inbound OpenAI/ChatGPT
authentication (`Bearer` or `AgentAssertion`). The separate image route accepts
only four explicit `solov::gpt-image-*` IDs and still requires a syntactically
valid local bearer credential. Unknown paths and models fail closed.

## Requirements

- Node.js 24 or newer. The implementation uses Node's native zstd support.
- `SOLOV_API_KEY` in the process environment when the Solov route is used.
  The value is never written to a file or included in logs.
- `DUAL_ROUTER_CATALOG` pointing to a local file named `models.json`. The file
  is validated and loaded once at startup. It must contain only unique
  `solov::` model entries; those entries are appended to the live official
  catalog returned by ChatGPT.

No package installation is required.

## Run tests

```powershell
Set-Location work/router
npm test
```

Tests use fake values and loopback-only fake upstreams. They make no request to
OpenAI or Solov.

## Start

```powershell
$env:SOLOV_API_KEY = '<load this from your preferred secret store>'
$env:DUAL_ROUTER_CATALOG = 'C:\path\to\models.json'
npm start
```

Optional non-secret settings:

- `DUAL_ROUTER_PORT` (default `43120`)
- `DUAL_ROUTER_OPENAI_MODELS` (comma-separated startup seed allowlist, used
  until the first successful official catalog refresh)
- `DUAL_ROUTER_HTTPS_PROXY` for machines that require a local system proxy.
  Its only accepted form is `http://127.0.0.1:<port>` (for example,
  `http://127.0.0.1:10808`). Authentication, paths, queries, fragments, other
  hosts, and HTTPS proxy URLs are rejected at startup.

The Solov text route allowlist is derived exclusively from the validated local
catalog, so a text model cannot be routed to Solov unless it is also present in
the menu catalog. Four image entries use a separate fixed allowlist and appear
in the same desktop model picker with a `· Solov Image` suffix.

## Request behavior

- A normal allowed model ID, such as `gpt-5.6-sol`, is sent to the ChatGPT Codex
  backend. A zstd request body is forwarded unchanged.
- An allowed model ID such as `solov::gpt-5.6-terra` is decoded if necessary,
  rewritten to `gpt-5.6-terra`, and sent as ordinary JSON to Solov.
- When a picker-selected image model is sent to `POST /responses`, the router
  extracts only the latest text-only user prompt, calls the fixed Solov
  `/v1/images/generations` endpoint, validates the single returned PNG, saves it
  atomically under the fixed local `generated-images` directory, and returns a
  Responses assistant message containing an absolute local-image Markdown
  reference. This is the image-display path consumed by the current desktop
  runtime. Tools, instructions, earlier messages, and ChatGPT identity headers
  are not sent to Solov.
- Deterministic Image API rejections (400, 401, 403, 404, 409, and 422) are
  converted to a sanitized terminal Responses failure so the desktop runtime
  does not retry a paid image request five times. Rate limits, 5xx responses,
  and network failures retain retryable transport semantics.
- `POST /images/generations` accepts only `solov::gpt-image-1`,
  `solov::gpt-image-1.5`, `solov::gpt-image-2`, or
  `solov::gpt-image-2-2026-04-21`. The prefix is removed and the request is
  sent only to the fixed Solov `/v1/images/generations` endpoint. Standard
  `data[0].b64_json` responses are passed through unchanged.
- OpenAI authentication and `x-openai-*` / `x-codex-*` headers are never sent
  to Solov. The Solov key is never sent to OpenAI.
- SSE response bytes are streamed without buffering or interpretation.
- When `DUAL_ROUTER_HTTPS_PROXY` is set, both fixed HTTPS upstreams use HTTP
  CONNECT through that loopback proxy. The CONNECT authority cannot be changed
  by a request; TLS still verifies the real upstream hostname and certificate
  with the real hostname as SNI.
- `GET /models` forwards the authenticated request to the fixed ChatGPT Codex
  backend, parses a bounded JSON response, preserves every official model entry
  and its order, then appends the startup-loaded Solov-only entries. A valid
  official response atomically refreshes the OpenAI model allowlist. Official
  errors are passed through safely, and malformed, redirected, compressed, or
  oversized catalogs fail closed; the router never falls back to a Solov-only
  catalog. The endpoint accepts no query key other than an optional, single
  `client_version`.
- `GET /health` returns only `{ "status": "ok" }` and needs no credential.
- A `GET /responses` WebSocket upgrade probe receives an explicit `426` so
  older clients can fall back to ordinary HTTP streaming; it is never sent to
  either upstream. A normal `GET /responses` remains rejected.
- Solov `/responses/compact` is deliberately rejected until that endpoint has
  passed a compatibility test. OpenAI `/responses/compact` remains available.

The separate `POST /images/generations` route remains available for scripts.
The installed `generate-solov-image.ps1` helper calls it locally and decodes
the returned base64 image without exposing the Solov key.

Successfully delivered picker images remain in `generated-images` so older
tasks do not lose their referenced image. Temporary files are never returned
and are removed on failed publication or interrupted delivery.

This directory deliberately does not edit `~/.codex/config.toml`, does not read
`auth.json`, and contains no real credential.
