[CmdletBinding()]
param([int]$Port = 43120)

$ErrorActionPreference = 'Stop'
$health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -Method Get -TimeoutSec 3
$health
