[CmdletBinding()]
param(
    [string]$WorkspaceRoot = 'C:\Users\<USER>\Documents\Codex\2026-08-12\chatgpt-api',
    [string]$InstallRoot = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter',
    [string]$ConfigPath = 'C:\Users\<USER>\.codex\config.toml',
    [string]$AuthPath = 'C:\Users\<USER>\.codex\auth.json',
    [string]$BackupRoot,
    [int]$Port = 43120,
    [switch]$PreflightOnly
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Assert-True {
    param([bool]$Condition, [string]$Message)
    if (-not $Condition) { throw $Message }
}

function Assert-File {
    param([string]$Path)
    Assert-True (Test-Path -LiteralPath $Path -PathType Leaf) "Required file not found: $Path"
}

function Assert-Directory {
    param([string]$Path)
    Assert-True (Test-Path -LiteralPath $Path -PathType Container) "Required directory not found: $Path"
}

function Assert-WithinDirectory {
    param([string]$Path, [string]$Parent, [string]$Label)
    $fullPath = [IO.Path]::GetFullPath($Path)
    $fullParent = [IO.Path]::GetFullPath($Parent).TrimEnd('\') + '\'
    Assert-True ($fullPath.StartsWith($fullParent, [StringComparison]::OrdinalIgnoreCase)) "$Label is outside the expected directory: $fullPath"
}

function Assert-NoReparsePoints {
    param([string]$Path, [string]$Label)
    $items = @((Get-Item -LiteralPath $Path -Force)) + @(Get-ChildItem -LiteralPath $Path -Recurse -Force)
    foreach ($item in $items) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "$Label contains a reparse point: $($item.FullName)"
        }
    }
}

function Assert-PowerShellSyntax {
    param([string]$Path)
    Assert-File $Path
    $parseTokens = $null
    $parseErrors = $null
    [Management.Automation.Language.Parser]::ParseFile($Path, [ref]$parseTokens, [ref]$parseErrors) | Out-Null
    if (@($parseErrors).Count -gt 0) {
        $messages = @($parseErrors | ForEach-Object { $_.Message }) -join '; '
        throw "PowerShell syntax validation failed for $Path. $messages"
    }
}

function Get-TreeHashRecords {
    param([string]$Root)
    Assert-Directory $Root
    $resolvedRoot = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    @(
        Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -Force |
            Sort-Object FullName |
            ForEach-Object {
                [ordered]@{
                    relative_path = $_.FullName.Substring($resolvedRoot.Length + 1).Replace('\', '/')
                    length = [int64]$_.Length
                    sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash
                }
            }
    )
}

function Get-FileHashRecord {
    param([string]$Path)
    Assert-File $Path
    $item = Get-Item -LiteralPath $Path -Force
    [ordered]@{
        length = [int64]$item.Length
        sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash
    }
}

function Get-OptionalFileHashRecord {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        return [ordered]@{ exists = $false }
    }
    Assert-File $Path
    $record = Get-FileHashRecord -Path $Path
    return [ordered]@{
        exists = $true
        length = $record.length
        sha256 = $record.sha256
    }
}

function Assert-TreeMatches {
    param([string]$Source, [string]$Target, [string]$Label)
    $sourceJson = (Get-TreeHashRecords -Root $Source) | ConvertTo-Json -Compress -Depth 10
    $targetJson = (Get-TreeHashRecords -Root $Target) | ConvertTo-Json -Compress -Depth 10
    Assert-True ($sourceJson -ceq $targetJson) "$Label differs from the source tree."
}

function Copy-FileVerified {
    param([string]$Source, [string]$Target)
    Assert-File $Source
    Assert-True (-not (Test-Path -LiteralPath $Target)) "Refusing to overwrite backup/staging file: $Target"
    Copy-Item -LiteralPath $Source -Destination $Target
    Assert-File $Target
    $sourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Source).Hash
    $targetHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Target).Hash
    Assert-True ($sourceHash -ceq $targetHash) "Copied file hash mismatch: $Target"
}

function Set-FileAtomically {
    param([string]$Source, [string]$Target, [string]$TransactionNonce)
    Assert-File $Source
    if (Test-Path -LiteralPath $Target) { Assert-File $Target }
    $targetDirectory = Split-Path -Parent $Target
    $temporaryTarget = Join-Path $targetDirectory ('.image-picker-new-' + $TransactionNonce + '-' + [IO.Path]::GetFileName($Target))
    Assert-True (-not (Test-Path -LiteralPath $temporaryTarget)) "Atomic replacement temp already exists: $temporaryTarget"
    try {
        [IO.File]::Copy($Source, $temporaryTarget, $false)
        $sourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Source).Hash
        $temporaryHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $temporaryTarget).Hash
        Assert-True ($sourceHash -ceq $temporaryHash) "Atomic replacement staging hash mismatch: $Target"
        if (Test-Path -LiteralPath $Target -PathType Leaf) {
            [IO.File]::Move($temporaryTarget, $Target, $true)
        }
        else {
            [IO.File]::Move($temporaryTarget, $Target)
        }
        $targetHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Target).Hash
        Assert-True ($sourceHash -ceq $targetHash) "Atomic replacement target hash mismatch: $Target"
    }
    finally {
        if (Test-Path -LiteralPath $temporaryTarget -PathType Leaf) {
            Remove-Item -LiteralPath $temporaryTarget -Force
        }
    }
}

function Write-JsonAtomically {
    param([string]$Path, [object]$Value, [string]$TransactionNonce)
    $parent = Split-Path -Parent $Path
    Assert-Directory $parent
    $temporaryPath = Join-Path $parent ('.image-picker-json-' + $TransactionNonce + '-' + [IO.Path]::GetFileName($Path))
    Assert-True (-not (Test-Path -LiteralPath $temporaryPath)) "JSON temp already exists: $temporaryPath"
    try {
        $json = $Value | ConvertTo-Json -Depth 30
        [IO.File]::WriteAllText($temporaryPath, $json + [Environment]::NewLine, [Text.UTF8Encoding]::new($false))
        if (Test-Path -LiteralPath $Path -PathType Leaf) {
            [IO.File]::Move($temporaryPath, $Path, $true)
        }
        else {
            [IO.File]::Move($temporaryPath, $Path)
        }
    }
    finally {
        if (Test-Path -LiteralPath $temporaryPath -PathType Leaf) {
            Remove-Item -LiteralPath $temporaryPath -Force
        }
    }
}

function Remove-OwnedStagingDirectory {
    param([string]$Path, [string]$ExpectedParent)
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $fullPath = [IO.Path]::GetFullPath($Path)
    $fullParent = [IO.Path]::GetFullPath($ExpectedParent).TrimEnd('\') + '\'
    $leaf = [IO.Path]::GetFileName($fullPath)
    if ($fullPath.StartsWith($fullParent, [StringComparison]::OrdinalIgnoreCase) -and
        $leaf.StartsWith('codex-image-picker-stage-', [StringComparison]::Ordinal)) {
        [IO.Directory]::Delete($fullPath, $true)
    }
    else {
        throw "Refusing to remove unexpected staging path: $fullPath"
    }
}

function Test-RouterHealth {
    try {
        $health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/health" -Method Get -TimeoutSec 2
        return $health.status -ceq 'ok'
    }
    catch { return $false }
}

function Get-ValidatedRouterProcess {
    param([string]$Root)
    $pidPath = Join-Path $Root 'run\router.pid'
    $routerEntry = [IO.Path]::GetFullPath((Join-Path $Root 'router\src\main.mjs'))
    Assert-File $pidPath
    $storedPid = 0
    Assert-True ([int]::TryParse(([IO.File]::ReadAllText($pidPath)).Trim(), [ref]$storedPid)) "Invalid router PID file: $pidPath"
    $process = Get-CimInstance Win32_Process -Filter "ProcessId = $storedPid" -ErrorAction SilentlyContinue
    Assert-True ($null -ne $process) "Router process $storedPid was not found."
    Assert-True ($process.Name -ceq 'node.exe') "PID $storedPid is not node.exe."
    Assert-True (-not [string]::IsNullOrWhiteSpace($process.CommandLine)) "PID $storedPid has no command line."
    Assert-True ($process.CommandLine.IndexOf($routerEntry, [StringComparison]::OrdinalIgnoreCase) -ge 0) "PID $storedPid is not the expected Codex dual router."
    return $process
}

function Get-LiveBaseline {
    [ordered]@{
        schema = 1
        router = @(Get-TreeHashRecords -Root $installedRouter)
        targets = [ordered]@{
            models_json = Get-FileHashRecord -Path $installedCatalog
            manifest_json = Get-FileHashRecord -Path $installedManifest
            readme_md = Get-FileHashRecord -Path $installedReadme
            validate_live_picker = Get-FileHashRecord -Path $installedPickerValidator
            validate_standby = Get-FileHashRecord -Path $installedStandbyValidator
            validate_live_image_picker = Get-OptionalFileHashRecord -Path $installedLiveImageValidator
        }
        protected = [ordered]@{
            config_toml = Get-FileHashRecord -Path $ConfigPath
            auth_json = Get-FileHashRecord -Path $AuthPath
            encrypted_solov_key = Get-FileHashRecord -Path $secretPath
            start_router = Get-FileHashRecord -Path $startScript
            stop_router = Get-FileHashRecord -Path $stopScript
            rollback = Get-FileHashRecord -Path $rollbackScript
        }
    }
}

function Assert-LiveBaselineUnchanged {
    param([string]$ExpectedJson, [string]$Stage)
    $currentJson = (Get-LiveBaseline) | ConvertTo-Json -Compress -Depth 30
    Assert-True ($currentJson -ceq $ExpectedJson) "Live installation changed after the baseline was captured ($Stage); refusing the CAS deployment."
}

function Compare-SharedOfficialNames {
    param([object[]]$Before, [object[]]$After)
    $beforeById = @{}
    foreach ($model in @($Before)) { $beforeById[[string]$model.Id] = [string]$model.Name }
    $shared = 0
    foreach ($model in @($After)) {
        $id = [string]$model.Id
        if ($beforeById.ContainsKey($id)) {
            $shared++
            Assert-True ($beforeById[$id] -ceq [string]$model.Name) "Official model display name changed for $id."
        }
    }
    return $shared
}

$resolvedWorkspace = (Resolve-Path -LiteralPath $WorkspaceRoot).Path
$resolvedInstall = (Resolve-Path -LiteralPath $InstallRoot).Path
$expectedInstall = [IO.Path]::GetFullPath('C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter')
Assert-True ($resolvedInstall.Equals($expectedInstall, [StringComparison]::OrdinalIgnoreCase)) "Unexpected installation target: $resolvedInstall"
Assert-True ($Port -eq 43120) 'The production image picker must remain on port 43120.'

$backupParent = Join-Path $resolvedInstall 'backups'
$generatedImages = Join-Path $resolvedInstall 'generated-images'
Assert-Directory $backupParent
if ([string]::IsNullOrWhiteSpace($BackupRoot)) {
    $BackupRoot = Join-Path $backupParent ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-image-picker')
}
$resolvedBackup = [IO.Path]::GetFullPath($BackupRoot)
Assert-WithinDirectory -Path $resolvedBackup -Parent $backupParent -Label 'Backup root'
Assert-True (-not (Test-Path -LiteralPath $resolvedBackup)) "Backup target already exists: $resolvedBackup"
Assert-True (-not $resolvedBackup.Equals([IO.Path]::GetFullPath($generatedImages), [StringComparison]::OrdinalIgnoreCase)) 'The backup must never target generated-images.'

$sourceRouter = Join-Path $resolvedWorkspace 'work\router'
$sourceCatalog = Join-Path $resolvedWorkspace 'work\catalog\model-catalog.json'
$sourceManifest = Join-Path $resolvedWorkspace 'work\catalog\solov-model-manifest.json'
$sourceCatalogValidator = Join-Path $resolvedWorkspace 'work\catalog\validate_catalog.ps1'
$sourceReadme = Join-Path $resolvedWorkspace 'work\install\README.md'
$sourcePickerValidator = Join-Path $resolvedWorkspace 'work\install\validate-live-picker.ps1'
$sourceStandbyValidator = Join-Path $resolvedWorkspace 'work\install\validate-standby.ps1'
$sourceLiveImageValidator = Join-Path $resolvedWorkspace 'work\install\validate-live-image-picker.ps1'
$installedRouter = Join-Path $resolvedInstall 'router'
$installedCatalog = Join-Path $resolvedInstall 'models.json'
$installedManifest = Join-Path $resolvedInstall 'solov-model-manifest.json'
$installedReadme = Join-Path $resolvedInstall 'README.md'
$installedPickerValidator = Join-Path $resolvedInstall 'validate-live-picker.ps1'
$installedStandbyValidator = Join-Path $resolvedInstall 'validate-standby.ps1'
$installedLiveImageValidator = Join-Path $resolvedInstall 'validate-live-image-picker.ps1'
$stopScript = Join-Path $resolvedInstall 'stop-router.ps1'
$startScript = Join-Path $resolvedInstall 'start-router.ps1'
$rollbackScript = Join-Path $resolvedInstall 'rollback.ps1'
$secretPath = Join-Path $resolvedInstall 'secrets\solov.dpapi'

foreach ($directory in @($sourceRouter, $installedRouter)) { Assert-Directory $directory }
foreach ($file in @(
    $sourceCatalog, $sourceManifest, $sourceCatalogValidator, $sourceReadme,
    $sourcePickerValidator, $sourceStandbyValidator, $sourceLiveImageValidator, $installedCatalog,
    $installedManifest, $installedReadme, $installedPickerValidator,
    $installedStandbyValidator, $stopScript, $startScript, $rollbackScript,
    $ConfigPath, $AuthPath, $secretPath
)) { Assert-File $file }
Assert-NoReparsePoints -Path $sourceRouter -Label 'Source router'
Assert-NoReparsePoints -Path $installedRouter -Label 'Installed router'

$configText = [IO.File]::ReadAllText($ConfigPath)
Assert-True ($configText -notmatch '(?m)^\s*model_catalog_json\s*=') 'The live config must not contain model_catalog_json.'
Assert-True ($configText -match '(?m)^\s*model_provider\s*=\s*"openai"\s*$') 'The live config must keep model_provider = "openai".'
Assert-True ($configText -match '(?m)^\s*openai_base_url\s*=\s*"http://127\.0\.0\.1:43120"\s*$') 'The live config must keep the loopback router URL.'

$catalog = Get-Content -Raw -LiteralPath $sourceCatalog | ConvertFrom-Json
$catalogModels = @($catalog.models)
$expectedImageIds = @(
    'solov::gpt-image-1',
    'solov::gpt-image-1.5',
    'solov::gpt-image-2',
    'solov::gpt-image-2-2026-04-21'
)
$catalogImages = @($catalogModels | Where-Object { ([string]$_.slug) -cin $expectedImageIds })
$catalogText = @($catalogModels | Where-Object { ([string]$_.slug) -cnotin $expectedImageIds })
Assert-True ($catalogModels.Count -eq 11) "Candidate catalog must contain 11 models; got $($catalogModels.Count)."
Assert-True ($catalogText.Count -eq 7) "Candidate catalog must contain 7 text models; got $($catalogText.Count)."
Assert-True ($catalogImages.Count -eq 4) "Candidate catalog must contain all 4 image models; got $($catalogImages.Count)."
Assert-True (-not ($catalogModels | Where-Object { -not ([string]$_.slug).StartsWith('solov::', [StringComparison]::Ordinal) })) 'Candidate catalog contains a non-Solov model.'
Assert-True (-not ($catalogImages | Where-Object { -not ([string]$_.display_name).EndsWith(' · Solov Image', [StringComparison]::Ordinal) })) 'Candidate image display name is missing the provider suffix.'

$nodePath = (Get-Command node.exe -ErrorAction Stop).Source
$nonce = [Guid]::NewGuid().ToString('N')
$stagingParent = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
$stagingRoot = Join-Path $stagingParent ('codex-image-picker-stage-' + $nonce)
$stagingRouter = Join-Path $stagingRoot 'router'
Assert-WithinDirectory -Path $stagingRoot -Parent $stagingParent -Label 'Staging root'
Assert-True (-not (Test-Path -LiteralPath $stagingRoot)) "Unexpected staging path already exists: $stagingRoot"
Assert-True ([IO.Path]::GetPathRoot($stagingRoot).Equals([IO.Path]::GetPathRoot($resolvedInstall), [StringComparison]::OrdinalIgnoreCase)) 'Staging and installation must be on the same volume for atomic directory moves.'

$beforeMenu = $null
$baseline = $null
$baselineJson = $null
$candidateManifest = $null
$oldProcess = $null
$backupCreated = $false
$stopAttempted = $false
$mutationStarted = $false
$oldRouterMoved = $false
$candidateRouterInstalled = $false
$deploymentStatePath = $null

try {
    [IO.Directory]::CreateDirectory($stagingRoot) | Out-Null
    Copy-Item -LiteralPath $sourceRouter -Destination $stagingRouter -Recurse
    Copy-FileVerified -Source $sourceCatalog -Target (Join-Path $stagingRoot 'models.json')
    Copy-FileVerified -Source $sourceManifest -Target (Join-Path $stagingRoot 'solov-model-manifest.json')
    Copy-FileVerified -Source $sourceReadme -Target (Join-Path $stagingRoot 'README.md')
    Copy-FileVerified -Source $sourcePickerValidator -Target (Join-Path $stagingRoot 'validate-live-picker.ps1')
    Copy-FileVerified -Source $sourceStandbyValidator -Target (Join-Path $stagingRoot 'validate-standby.ps1')
    Copy-FileVerified -Source $sourceLiveImageValidator -Target (Join-Path $stagingRoot 'validate-live-image-picker.ps1')
    Assert-NoReparsePoints -Path $stagingRoot -Label 'Staging tree'
    Assert-TreeMatches -Source $sourceRouter -Target $stagingRouter -Label 'Staging router'

    foreach ($powerShellScript in @(
        $sourceCatalogValidator,
        (Join-Path $stagingRoot 'validate-live-picker.ps1'),
        (Join-Path $stagingRoot 'validate-standby.ps1'),
        (Join-Path $stagingRoot 'validate-live-image-picker.ps1')
    )) {
        Assert-PowerShellSyntax -Path $powerShellScript
    }

    foreach ($relativePath in @('src\config.mjs', 'src\main.mjs', 'src\router.mjs', 'test\router.test.mjs')) {
        & $nodePath --check (Join-Path $stagingRouter $relativePath)
        Assert-True ($LASTEXITCODE -eq 0) "Node syntax validation failed: $relativePath"
    }
    Push-Location $stagingRouter
    try {
        & $nodePath --test --test-concurrency=1
        Assert-True ($LASTEXITCODE -eq 0) "Staging router tests failed with exit code $LASTEXITCODE."
    }
    finally { Pop-Location }

    $catalogValidation = & $sourceCatalogValidator `
        -CatalogPath (Join-Path $stagingRoot 'models.json') `
        -ManifestPath (Join-Path $stagingRoot 'solov-model-manifest.json')
    $catalogRuntimeValidation = @($catalogValidation | Where-Object {
        $null -ne $_.PSObject.Properties['PickerModelsVisible']
    } | Select-Object -Last 1)
    Assert-True ($catalogRuntimeValidation.Count -eq 1) 'Catalog runtime validation did not return its picker result.'

    Assert-True (Test-RouterHealth) "The current router is not healthy on 127.0.0.1:$Port."
    $oldProcess = Get-ValidatedRouterProcess -Root $resolvedInstall
    $beforeMenu = & $sourcePickerValidator `
        -InstallRoot $resolvedInstall `
        -Port $Port `
        -MinimumOfficialModels 1 `
        -MinimumSolovModels 7 `
        -MinimumSolovTextModels 7 `
        -MinimumSolovImageModels 0 `
        -UseCurrentConfigCopy

    $candidateManifest = [ordered]@{
        schema = 1
        created_utc = [DateTime]::UtcNow.ToString('o')
        router = @(Get-TreeHashRecords -Root $stagingRouter)
        files = [ordered]@{
            models_json = Get-FileHashRecord -Path (Join-Path $stagingRoot 'models.json')
            manifest_json = Get-FileHashRecord -Path (Join-Path $stagingRoot 'solov-model-manifest.json')
            readme_md = Get-FileHashRecord -Path (Join-Path $stagingRoot 'README.md')
            validate_live_picker = Get-FileHashRecord -Path (Join-Path $stagingRoot 'validate-live-picker.ps1')
            validate_standby = Get-FileHashRecord -Path (Join-Path $stagingRoot 'validate-standby.ps1')
            validate_live_image_picker = Get-FileHashRecord -Path (Join-Path $stagingRoot 'validate-live-image-picker.ps1')
        }
        catalog_validation = [ordered]@{
            models = $catalogRuntimeValidation[0].ModelListReturned
            text_models = $catalogRuntimeValidation[0].TextModelsVisible
            image_models = $catalogRuntimeValidation[0].ImageModelsVisible
            picker_models_visible = $catalogRuntimeValidation[0].PickerModelsVisible
        }
    }

    # Freeze the exact live tree after all candidate tests. This snapshot is the CAS baseline.
    $baseline = Get-LiveBaseline
    $baselineJson = $baseline | ConvertTo-Json -Compress -Depth 30

    if ($PreflightOnly) {
        [pscustomobject]@{
            PreflightOnly = $true
            ProductionChanged = $false
            CandidateRouterFiles = @($candidateManifest.router).Count
            CandidateModels = $catalogModels.Count
            CandidateTextModels = $catalogText.Count
            CandidateImageModels = $catalogImages.Count
            CurrentOfficialModelsObserved = $beforeMenu.OfficialModels
            CurrentSolovTextModels = $beforeMenu.SolovTextModels
            StagingLocation = 'temporary directory (removed)'
            GeneratedImagesExcluded = $true
            CandidateSha256 = $candidateManifest.files
        }
        return
    }

    [IO.Directory]::CreateDirectory($resolvedBackup) | Out-Null
    $backupCreated = $true
    $deploymentStatePath = Join-Path $resolvedBackup 'deployment-state.json'
    Write-JsonAtomically -Path $deploymentStatePath -TransactionNonce $nonce -Value ([ordered]@{
        schema = 1
        phase = 'backup-started'
        updated_utc = [DateTime]::UtcNow.ToString('o')
        generated_images_excluded = $true
    })

    Copy-Item -LiteralPath $installedRouter -Destination (Join-Path $resolvedBackup 'router') -Recurse
    Copy-FileVerified -Source $installedCatalog -Target (Join-Path $resolvedBackup 'models.json')
    Copy-FileVerified -Source $installedManifest -Target (Join-Path $resolvedBackup 'solov-model-manifest.json')
    Copy-FileVerified -Source $installedReadme -Target (Join-Path $resolvedBackup 'README.md')
    Copy-FileVerified -Source $installedPickerValidator -Target (Join-Path $resolvedBackup 'validate-live-picker.ps1')
    Copy-FileVerified -Source $installedStandbyValidator -Target (Join-Path $resolvedBackup 'validate-standby.ps1')
    if (Test-Path -LiteralPath $installedLiveImageValidator -PathType Leaf) {
        Copy-FileVerified -Source $installedLiveImageValidator -Target (Join-Path $resolvedBackup 'validate-live-image-picker.ps1')
    }
    Copy-FileVerified -Source $ConfigPath -Target (Join-Path $resolvedBackup 'config.toml')
    Assert-TreeMatches -Source $installedRouter -Target (Join-Path $resolvedBackup 'router') -Label 'Backup router'
    Write-JsonAtomically -Path (Join-Path $resolvedBackup 'baseline-sha256.json') -Value $baseline -TransactionNonce $nonce
    Write-JsonAtomically -Path (Join-Path $resolvedBackup 'candidate-sha256.json') -Value $candidateManifest -TransactionNonce $nonce

    # The backup may take time. Re-read every mutable/protected input immediately before shutdown.
    Assert-LiveBaselineUnchanged -ExpectedJson $baselineJson -Stage 'immediately before stop'
    Write-JsonAtomically -Path $deploymentStatePath -TransactionNonce $nonce -Value ([ordered]@{
        schema = 1
        phase = 'backup-complete-cas-verified'
        updated_utc = [DateTime]::UtcNow.ToString('o')
        generated_images_excluded = $true
    })

    $stopAttempted = $true
    & $stopScript -InstallRoot $resolvedInstall
    for ($attempt = 0; $attempt -lt 40; $attempt++) {
        $oldStillExists = $null -ne (Get-Process -Id $oldProcess.ProcessId -ErrorAction SilentlyContinue)
        if (-not $oldStillExists -and -not (Test-RouterHealth)) { break }
        Start-Sleep -Milliseconds 100
    }
    Assert-True ($null -eq (Get-Process -Id $oldProcess.ProcessId -ErrorAction SilentlyContinue)) "The old router process $($oldProcess.ProcessId) did not exit."
    Assert-True (-not (Test-RouterHealth)) "Port $Port still serves a router after shutdown."
    Assert-LiveBaselineUnchanged -ExpectedJson $baselineJson -Stage 'after verified stop'

    $mutationStarted = $true
    $runtimeBackup = Join-Path $resolvedBackup 'router-runtime-before-image-picker'
    Move-Item -LiteralPath $installedRouter -Destination $runtimeBackup
    $oldRouterMoved = $true
    Move-Item -LiteralPath $stagingRouter -Destination $installedRouter
    $candidateRouterInstalled = $true

    # Install support files while stopped. The catalog is the final switch.
    Set-FileAtomically -Source (Join-Path $stagingRoot 'solov-model-manifest.json') -Target $installedManifest -TransactionNonce $nonce
    Set-FileAtomically -Source (Join-Path $stagingRoot 'README.md') -Target $installedReadme -TransactionNonce $nonce
    Set-FileAtomically -Source (Join-Path $stagingRoot 'validate-live-picker.ps1') -Target $installedPickerValidator -TransactionNonce $nonce
    Set-FileAtomically -Source (Join-Path $stagingRoot 'validate-standby.ps1') -Target $installedStandbyValidator -TransactionNonce $nonce
    Set-FileAtomically -Source (Join-Path $stagingRoot 'validate-live-image-picker.ps1') -Target $installedLiveImageValidator -TransactionNonce $nonce
    Set-FileAtomically -Source (Join-Path $stagingRoot 'models.json') -Target $installedCatalog -TransactionNonce $nonce

    Write-JsonAtomically -Path $deploymentStatePath -TransactionNonce $nonce -Value ([ordered]@{
        schema = 1
        phase = 'candidate-installed-models-switched'
        updated_utc = [DateTime]::UtcNow.ToString('o')
        generated_images_excluded = $true
    })

    & $startScript -InstallRoot $resolvedInstall -Port $Port
    Assert-True (Test-RouterHealth) "The image-picker router is not healthy on 127.0.0.1:$Port."
    $newProcess = Get-ValidatedRouterProcess -Root $resolvedInstall
    Assert-TreeMatches -Source $sourceRouter -Target $installedRouter -Label 'Installed image-picker router'
    foreach ($pair in @(
        @((Join-Path $stagingRoot 'models.json'), $installedCatalog),
        @((Join-Path $stagingRoot 'solov-model-manifest.json'), $installedManifest),
        @((Join-Path $stagingRoot 'README.md'), $installedReadme),
        @((Join-Path $stagingRoot 'validate-live-picker.ps1'), $installedPickerValidator),
        @((Join-Path $stagingRoot 'validate-standby.ps1'), $installedStandbyValidator),
        @((Join-Path $stagingRoot 'validate-live-image-picker.ps1'), $installedLiveImageValidator)
    )) {
        Assert-True ((Get-FileHash -Algorithm SHA256 -LiteralPath $pair[0]).Hash -ceq (Get-FileHash -Algorithm SHA256 -LiteralPath $pair[1]).Hash) "Installed candidate hash mismatch: $($pair[1])"
    }

    $afterMenu = & $installedPickerValidator `
        -InstallRoot $resolvedInstall `
        -Port $Port `
        -MinimumOfficialModels 1 `
        -MinimumSolovModels 11 `
        -MinimumSolovTextModels 7 `
        -MinimumSolovImageModels 4 `
        -UseCurrentConfigCopy
    $sharedOfficialNamesChecked = Compare-SharedOfficialNames -Before @($beforeMenu.Official) -After @($afterMenu.Official)

    $afterBaseline = Get-LiveBaseline
    foreach ($protectedName in $baseline.protected.Keys) {
        $beforeProtectedJson = $baseline.protected[$protectedName] | ConvertTo-Json -Compress -Depth 5
        $afterProtectedJson = $afterBaseline.protected[$protectedName] | ConvertTo-Json -Compress -Depth 5
        Assert-True ($beforeProtectedJson -ceq $afterProtectedJson) "Protected file changed during deployment: $protectedName"
    }

    Write-JsonAtomically -Path $deploymentStatePath -TransactionNonce $nonce -Value ([ordered]@{
        schema = 1
        phase = 'committed'
        updated_utc = [DateTime]::UtcNow.ToString('o')
        router_process_id = $newProcess.ProcessId
        generated_images_excluded = $true
    })

    [pscustomobject]@{
        Activated = $true
        Router = "127.0.0.1:$Port"
        RouterProcessId = $newProcess.ProcessId
        OfficialModelsObservedBefore = $beforeMenu.OfficialModels
        OfficialModelsObservedAfter = $afterMenu.OfficialModels
        SharedOfficialNamesChecked = $sharedOfficialNamesChecked
        SolovTextModels = $afterMenu.SolovTextModels
        SolovImageModels = $afterMenu.SolovImageModels
        BackupRoot = $resolvedBackup
        CandidateManifest = Join-Path $resolvedBackup 'candidate-sha256.json'
        BaselineManifest = Join-Path $resolvedBackup 'baseline-sha256.json'
        GeneratedImagesExcluded = $true
        CatalogSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $installedCatalog).Hash
        ConfigSha256 = $baseline.protected.config_toml.sha256
        AuthSha256 = $baseline.protected.auth_json.sha256
        EncryptedKeySha256 = $baseline.protected.encrypted_solov_key.sha256
        ImageModels = @($afterMenu.SolovImages)
    }
}
catch {
    $activationError = $_
    if (-not $stopAttempted -and -not $mutationStarted) {
        throw
    }

    try {
        if ($backupCreated -and $null -ne $deploymentStatePath) {
            Write-JsonAtomically -Path $deploymentStatePath -TransactionNonce $nonce -Value ([ordered]@{
                schema = 1
                phase = 'rollback-started'
                updated_utc = [DateTime]::UtcNow.ToString('o')
                activation_error = $activationError.Exception.Message
                generated_images_excluded = $true
            })
        }

        & $stopScript -InstallRoot $resolvedInstall -ErrorAction SilentlyContinue

        if ($mutationStarted) {
            if (Test-Path -LiteralPath $installedRouter -PathType Container) {
                $failedRouter = Join-Path $resolvedBackup ('router.failed-' + $nonce)
                Assert-True (-not (Test-Path -LiteralPath $failedRouter)) "Failed-router evidence path already exists: $failedRouter"
                Move-Item -LiteralPath $installedRouter -Destination $failedRouter
            }

            $runtimeBackup = Join-Path $resolvedBackup 'router-runtime-before-image-picker'
            if ($oldRouterMoved -and (Test-Path -LiteralPath $runtimeBackup -PathType Container)) {
                Move-Item -LiteralPath $runtimeBackup -Destination $installedRouter
            }
            else {
                Copy-Item -LiteralPath (Join-Path $resolvedBackup 'router') -Destination $installedRouter -Recurse
            }

            Set-FileAtomically -Source (Join-Path $resolvedBackup 'solov-model-manifest.json') -Target $installedManifest -TransactionNonce $nonce
            Set-FileAtomically -Source (Join-Path $resolvedBackup 'README.md') -Target $installedReadme -TransactionNonce $nonce
            Set-FileAtomically -Source (Join-Path $resolvedBackup 'validate-live-picker.ps1') -Target $installedPickerValidator -TransactionNonce $nonce
            Set-FileAtomically -Source (Join-Path $resolvedBackup 'validate-standby.ps1') -Target $installedStandbyValidator -TransactionNonce $nonce
            $backedUpLiveImageValidator = Join-Path $resolvedBackup 'validate-live-image-picker.ps1'
            if (Test-Path -LiteralPath $backedUpLiveImageValidator -PathType Leaf) {
                Set-FileAtomically -Source $backedUpLiveImageValidator -Target $installedLiveImageValidator -TransactionNonce $nonce
            }
            elseif (Test-Path -LiteralPath $installedLiveImageValidator -PathType Leaf) {
                Remove-Item -LiteralPath $installedLiveImageValidator -Force
            }
            Set-FileAtomically -Source (Join-Path $resolvedBackup 'models.json') -Target $installedCatalog -TransactionNonce $nonce
            Assert-TreeMatches -Source (Join-Path $resolvedBackup 'router') -Target $installedRouter -Label 'Rolled-back router'
        }

        if (-not (Test-RouterHealth)) {
            & $startScript -InstallRoot $resolvedInstall -Port $Port
        }
        Assert-True (Test-RouterHealth) 'The restored router did not become healthy.'
        $null = Get-ValidatedRouterProcess -Root $resolvedInstall

        if ($backupCreated -and $null -ne $deploymentStatePath) {
            Write-JsonAtomically -Path $deploymentStatePath -TransactionNonce $nonce -Value ([ordered]@{
                schema = 1
                phase = 'rolled-back'
                updated_utc = [DateTime]::UtcNow.ToString('o')
                activation_error = $activationError.Exception.Message
                generated_images_excluded = $true
            })
        }
    }
    catch {
        throw "Image-picker activation failed and automatic rollback also failed. Activation: $($activationError.Exception.Message) Rollback: $($_.Exception.Message)"
    }
    throw "Image-picker activation failed; the previous router and catalog were restored. $($activationError.Exception.Message)"
}
finally {
    Remove-OwnedStagingDirectory -Path $stagingRoot -ExpectedParent $stagingParent
}
