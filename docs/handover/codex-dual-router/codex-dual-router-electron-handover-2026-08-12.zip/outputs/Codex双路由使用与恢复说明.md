# Codex 双路由使用与恢复说明

## 当前状态

已在本机完成动态模型目录安装，并保持 Codex 的默认身份为 `openai`。客户端不再用静态 `model_catalog_json` 替换官方目录；本机路由器会先读取 ChatGPT 实时官方目录，逐项保持原字段、名称和顺序，再在末尾追加已验证的 Solov 模型。

### ChatGPT 订阅模型

以下是 2026-08-12 使用当前桌面端登录实际返回的 7 个官方可见模型。名称未经本机配置改写：

| 请求模型 | 客户端原生显示名 |
| --- | --- |
| `gpt-5.6-sol` | `GPT-5.6-Sol` |
| `gpt-5.6-terra` | `GPT-5.6-Terra` |
| `gpt-5.6-luna` | `GPT-5.6-Luna` |
| `gpt-5.5` | `GPT-5.5` |
| `gpt-5.4` | `GPT-5.4` |
| `gpt-5.4-mini` | `GPT-5.4-Mini` |
| `gpt-5.3-codex-spark` | `GPT-5.3-Codex-Spark` |

官方目录由 ChatGPT 实时返回；以后账号可用模型发生变化时，本机路由器会沿用新的官方列表，不会用上述快照覆盖它。

### Solov 模型

Solov `/v1/models` 共返回 23 个模型。17 个文本候选逐个经过 `/v1/responses`、reasoning 和 function tool 烟测后，以下 7 个通过并加入菜单：

| 请求模型 | 客户端显示名 |
| --- | --- |
| `solov::gpt-5.6-sol` | `GPT-5.6 Sol · Solov` |
| `solov::gpt-5.6-terra` | `GPT-5.6 Terra · Solov` |
| `solov::gpt-5.5` | `GPT-5.5 · Solov` |
| `solov::gpt-5.4` | `GPT-5.4 · Solov` |
| `solov::gpt-5.4-mini` | `GPT-5.4 Mini · Solov` |
| `solov::gpt-5.3-codex-spark` | `GPT-5.3 Codex Spark · Solov` |
| `solov::codex-auto-review` | `Codex Auto Review · Solov` |

10 个文本模型连续两轮返回 HTTP 503，暂不加入菜单；图片、音频或 Realtime 模型不适用于 Codex 文本任务，因此不加入文字模型菜单。其中 4 个 GPT Image 模型已经通过下面的独立图片接口接入。无敏感信息的完整检测清单位于 `solov-model-manifest.json`。

### Solov 图片生成接口

本机路由器已单独开放 `POST http://127.0.0.1:43120/images/generations`，并固定转发至 `https://xm.solov.cc/v1/images/generations`。支持以下模型：

| 本机请求模型 | 转发给 Solov 的模型 |
| --- | --- |
| `solov::gpt-image-1` | `gpt-image-1` |
| `solov::gpt-image-1.5` | `gpt-image-1.5` |
| `solov::gpt-image-2` | `gpt-image-2` |
| `solov::gpt-image-2-2026-04-21` | `gpt-image-2-2026-04-21` |

这 4 个图片模型会以 `· Solov Image` 后缀加入同一个模型下拉菜单。选择后，客户端仍向本机 `/responses` 发送任务；路由器只提取最后一条纯文字用户提示，固定调用 Solov 图片接口，严格验证 PNG 后原子保存到安装目录的 `generated-images`，再以当前桌面端可以显示的本机图片消息返回。

这里没有直接把 Image API 的 Base64 伪装成普通文本。兼容性隔离测试证明，当前桌面核心能够解析原始 `image_generation_call`，但不会把它转换成桌面可见图片项；因此路由器会先验证完整 PNG 结构和校验和，以随机文件名安全落盘，再返回包含绝对本机路径的 assistant Markdown 图片消息。该格式已经通过同版本桌面核心的 `item/completed: agentMessage` 验证。

独立脚本接口仍然保留，可用安装目录中的脚本生成并保存 PNG：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\generate-solov-image.ps1" `
  -Prompt "A clean flat orange star on a white background, no text." `
  -Model "solov::gpt-image-1" `
  -Size "1024x1024" `
  -Quality "low" `
  -OutputPath "C:\path\to\output.png"
```

脚本只连接本机回环地址，路由器会剥离 `solov::` 前缀、隔离 ChatGPT 身份头并在内存中注入 Solov 密钥。Solov 返回的 `data[0].b64_json` 会在本机解码为 PNG。

## 开始使用

1. 完全退出并重新打开 ChatGPT/Codex 桌面客户端，让客户端重新读取模型目录。
2. 新建任务，在输入框的模型菜单中直接选择任一官方模型或带 `· Solov` 的第三方模型。
3. 同一条线路内也可以切换模型。跨 ChatGPT/Solov 线路时建议新建任务，避免把某个上游的私有会话状态带到另一个上游。

## 安全边界

- 路由器仅监听 `127.0.0.1:43120`，不会暴露到局域网。
- Solov 分支会删除 ChatGPT 的认证、账号、attestation 和 Codex 身份头，然后才注入 Solov 密钥。
- OpenAI 分支不会收到 Solov 密钥。
- Solov 密钥由 Windows DPAPI 加密，文件权限仅授予当前用户和 SYSTEM；密钥不在 `config.toml`、源码、模型清单或日志中。
- 上游固定为 ChatGPT Codex 与 Solov，未知模型、路径、重定向和任意目标地址都会被拒绝。
- 图片路由只允许上述 4 个 `solov::gpt-image-*` 模型；未加前缀、官方模型、查询参数、相邻路径和重定向均在本机失败关闭。
- 图片模型返回的文件名由 128 位随机值生成，请求不能指定路径；临时文件完整同步并以不覆盖方式发布后才会返回。成功图片会保留在 `generated-images`，以保证历史任务仍可显示。
- `generated-images` 不会随每次启动、普通升级或配置回滚自动清空。成功图片属于任务显示所依赖的持久文件；手动删除后，历史任务中的对应图片将无法继续显示。
- 当前 Windows 系统代理启用时，路由器只允许连接 `127.0.0.1` 上的本机 HTTP 代理，TLS 仍验证真实上游证书。
- 官方 `/models` 非 200、格式错误、重定向或超限时，路由器会失败关闭，不会用 Solov-only 目录冒充官方目录。

## 已验证项目

- 路由器单元测试：37/37 通过。
- 独立安全黑盒：29/29 通过，覆盖身份头隔离、路径注入、输出根替换、客户端取消、非法上游零文件、8 路并发唯一性、临时文件零残留、私有文件权限以及日志不记录提示词、Base64、凭据或绝对输出路径。
- 桌面端核心版本：`codex-cli 0.147.0-alpha.6.6`。
- 正式安装上的 `model/list`：官方 7 个、Solov 11 个（7 个文字 + 4 个图片），全部可见。
- ChatGPT 官方模型完整请求：`gpt-5.4-mini` 返回 `OK`。
- 正式切换后的 Solov 文字验收已正确路由到 `xm.solov.cc`，但上游于 2026-08-12 返回 HTTP 403：`用户额度不足，剩余额度: $-3.082328`；因此不能把此前的成功烟测当成当前余额状态。
- Solov 入选的 7 个模型均已通过 Responses、reasoning 和 function tool 请求。
- Solov 直连图片接口已返回 HTTP 200 和 1024×1024 PNG。
- 直连探测阶段首版解析器错误地预期 URL 字段，在已经收到正常 `b64_json` 后又重试一次，因此直连探测实际触发了 2 次低画质生成；正式本机图片路由验证只发起了 1 次请求。
- 正式本机图片路由已用 `solov::gpt-image-1` 返回 HTTP 200；测试文件为 `solov-image-router-test.png`，667,587 字节，SHA-256 为 `44C164C9E9F176A825ED5546DFD0DF20B6DA1F8343965E7D4CE7165AC8DD1D64`。
- 图片下拉正式验收也已正确进入 `solov_image` 路由并调用固定 Image API，但同样被 Solov 当前账户余额以 HTTP 403 拒绝，因而没有生成新文件；菜单与本机转换链路已用同版本客户端和合成上游完整验证，真实付费成功仍取决于 Solov 服务端恢复可用额度。
- 当前客户端原本会把图片 `/responses` 的 403 当作可重连传输：第一次验收出现初始请求加 5 次重连。现已将确定性的 400/401/403/404/409/422 转为合法的非重试 `response.failed`，同版本客户端合成 403 验证只调用 1 次上游、错误可见且无 `Reconnecting`；429、5xx 与网络错误仍保留可重试语义。成功首响的合成全链路同样只调用 1 次上游。
- 同版本 `codex-cli 0.147.0-alpha.6.6` 协议验证确认：直接返回 `image_generation_call` 只产生实验性 raw item，不会变成桌面图片项；当前实现改用已实测产生 `item/completed: agentMessage` 的绝对本机 PNG Markdown 路径。
- `auth.json` 未被安装流程修改；任务仍归属 `openai` Provider。

## 当前限制

- Solov 的 `/responses/compact` 尚未证明兼容，因此该线路会安全拒绝远程压缩；跨线路或超长任务请新建任务。
- 这是本机适配层，不是客户端原生的双 Provider 功能；客户端大版本升级后应重新运行兼容性测试。
- 当前返回 503 的 Solov 文本模型不会自动出现在菜单。需要重新烟测成功并更新 Solov-only 目录后才会加入。
- 当前只接入图片生成接口；图片编辑、变体、音频和 Realtime 接口仍未开放。

## 本机位置

- 安装目录：`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter`
- Solov-only 模型目录：`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\models.json`
- 无密钥验证清单：`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\solov-model-manifest.json`
- 图片生成脚本：`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\generate-solov-image.ps1`
- 下拉生成图片目录：`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\generated-images`
- 图片下拉失败重连修复前备份（当前最终事务）：`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\backups\20260812-123150-image-picker`
- 图片下拉首次正式切换备份：`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\backups\20260812-121636-image-picker`
- 第一次切换尝试的完整预停机备份（未发生正式文件替换）：`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\backups\20260812-121436-image-picker`
- 图片路由安装前备份：`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\backups\20260812-082045-image-route`
- 本次调整前备份：`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\backups\20260812-065034-model-catalog-expansion`
- 最初实施前配置备份：`C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\backups\20260812-060734\config.toml`

## 查看状态和复验

查看路由器状态：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\status.ps1"
```

复验当前菜单中的官方/Solov 数量和名称：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\validate-live-picker.ps1" -MinimumOfficialModels 2 -MinimumSolovModels 11 -MinimumSolovTextModels 7 -MinimumSolovImageModels 4 -ExpectedSolovTextModels 7 -ExpectedSolovImageModels 4 -UseCurrentConfigCopy
```

官方模型数量只设动态下限，不固定为 2026-08-12 的 7 个快照；Solov 则精确验证 7 个文字模型与 4 个图片模型。app-server 首次 `model/list` 偶尔会先返回内置缓存，因此脚本会有界重试，最多等待约 4 秒。

复验两条线路的完整模型响应：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\validate-live-responses.ps1"
```

## 完整恢复原状

下面的命令会停止本机路由器、移除自动启动项，并恢复最初实施前的 Codex 配置。恢复后重新打开桌面客户端即可直接使用原订阅线路。

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\rollback.ps1" -Confirm:$false
```
