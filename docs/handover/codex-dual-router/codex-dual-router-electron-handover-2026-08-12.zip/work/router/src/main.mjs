import {
  DEFAULT_OPENAI_MODELS,
  DEFAULT_PORT,
  LISTEN_HOST,
  parseExplicitModelList,
} from "./config.mjs";
import {
  closeServer,
  createRouter,
  listenRouter,
  loadCatalogFile,
  prepareImageOutputRoot,
} from "./router.mjs";
import { fileURLToPath } from "node:url";

function parsePort(value) {
  const port = value === undefined ? DEFAULT_PORT : Number(value);
  if (!Number.isInteger(port) || port < 1 || port > 65_535) {
    throw new Error("DUAL_ROUTER_PORT must be an integer from 1 through 65535.");
  }
  return port;
}

const port = parsePort(process.env.DUAL_ROUTER_PORT);
const allowedOpenAiModels = parseExplicitModelList(
  process.env.DUAL_ROUTER_OPENAI_MODELS,
  DEFAULT_OPENAI_MODELS,
);
const catalogBody = await loadCatalogFile(process.env.DUAL_ROUTER_CATALOG);
const imageOutputState = await prepareImageOutputRoot(
  fileURLToPath(new URL("../../generated-images/", import.meta.url)),
);

const logger = (entry) => process.stderr.write(`${JSON.stringify(entry)}\n`);
const server = createRouter({
  solovApiKey: process.env.SOLOV_API_KEY,
  catalogBody,
  imageOutputState,
  allowedOpenAiModels,
  httpsProxy: process.env.DUAL_ROUTER_HTTPS_PROXY,
  logger,
});

const address = await listenRouter(server, port);
logger({
  event: "router_started",
  host: LISTEN_HOST,
  port: address.port,
  solov_configured:
    typeof process.env.SOLOV_API_KEY === "string" &&
    process.env.SOLOV_API_KEY.length > 0,
});

let closing = false;
async function shutdown(signal) {
  if (closing) {
    return;
  }
  closing = true;
  logger({ event: "router_stopping", signal });
  await closeServer(server);
  process.exitCode = 0;
}

process.on("SIGINT", () => void shutdown("SIGINT"));
process.on("SIGTERM", () => void shutdown("SIGTERM"));
