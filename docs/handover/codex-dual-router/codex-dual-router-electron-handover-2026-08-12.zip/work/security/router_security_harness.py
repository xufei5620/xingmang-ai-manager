#!/usr/bin/env python3
"""Black-box security harness for the local mixed-provider router.

The harness starts three loopback-only fake servers (OpenAI, Solov, and an
SSRF trap), starts the router under test with synthetic credentials, and then
checks routing and isolation properties over HTTP.  It never reads Codex
configuration or real credentials.
"""

from __future__ import annotations

import argparse
import base64
import concurrent.futures
import http.client
import json
import os
import re
import select
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import zlib
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlsplit


LOOPBACK = "127.0.0.1"
OPENAI_MODEL_ALIAS = "gpt-test"
DYNAMIC_OPENAI_MODEL = "gpt-dynamic-catalog-only"
SOLOV_MODEL_ALIAS = "solov::deepseek-test"
OPENAI_UPSTREAM_MODEL = "gpt-test"
SOLOV_UPSTREAM_MODEL = "deepseek-test"
SOLOV_IMAGE_MODELS: tuple[str, ...] = (
    "gpt-image-1",
    "gpt-image-1.5",
    "gpt-image-2",
    "gpt-image-2-2026-04-21",
)
SOLOV_IMAGE_ALIASES: tuple[str, ...] = tuple(
    f"solov::{model}" for model in SOLOV_IMAGE_MODELS
)
SOLOV_TEST_KEY = "<SYNTHETIC_SOLOV_AUTH>"
CHATGPT_TEST_AUTH = "Bearer <SYNTHETIC_CHATGPT_AUTH>"
CHATGPT_TEST_ACCOUNT = "<SYNTHETIC_ACCOUNT>"
ATTESTATION_TEST_VALUE = "<SYNTHETIC_ATTESTATION>"
SSE_DELAY_SECONDS = 1.5

# These records intentionally contain nested and otherwise opaque fields.  The
# router must treat official model records as data, not reconstruct or rename
# them while appending the synthetic third-party record.
OFFICIAL_CATALOG_MODELS: tuple[dict[str, Any], ...] = (
    {
        "slug": OPENAI_MODEL_ALIAS,
        "display_name": "GPT Test Official",
        "description": "synthetic first official record",
        "priority": 70,
        "supported_reasoning_levels": [
            {"effort": "low", "description": "synthetic low"},
            {"effort": "high", "description": "synthetic high"},
        ],
        "opaque_security_sentinel": {"nested": [1, "two", False]},
    },
    {
        "slug": DYNAMIC_OPENAI_MODEL,
        "display_name": "GPT Dynamic Official",
        "description": "present only in the live official catalog",
        "priority": 30,
        "supported_reasoning_levels": [
            {"effort": "medium", "description": "synthetic medium"},
        ],
        "opaque_security_sentinel": {"nested": [None, {"keep": "exact"}]},
    },
)

SOLOV_CATALOG_MODELS: tuple[dict[str, Any], ...] = (
    {
        "slug": SOLOV_MODEL_ALIAS,
        "display_name": "DeepSeek Test \u00b7 Solov",
        "description": "synthetic compatible third-party model",
        "priority": 10,
        "supported_reasoning_levels": [
            {"effort": "medium", "description": "synthetic medium"},
        ],
    },
    *(
        {
            "slug": alias,
            "display_name": f"{model} \u00b7 Solov Image",
            "description": "synthetic image model exposed through Responses",
            "input_modalities": ["text"],
            "supports_parallel_tool_calls": False,
            "supports_search_tool": False,
        }
        for alias, model in zip(SOLOV_IMAGE_ALIASES, SOLOV_IMAGE_MODELS)
    ),
)

CATALOG_ERROR_CLIENT_VERSION = "security-harness-upstream-503"
IMAGE_SUCCESS_PAYLOAD: dict[str, Any] = {
    "created": 1_786_464_000,
    "data": [{"b64_json": "c3ludGhldGljLWltYWdlLWJ5dGVz"}],
    "usage": {"input_tokens": 3, "output_tokens": 7, "total_tokens": 10},
}
RESPONSES_IMAGE_PROMPT = "synthetic responses image prompt 91d41a"
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def _png_chunk(kind: bytes, data: bytes) -> bytes:
    return (
        struct.pack(">I", len(data))
        + kind
        + data
        + struct.pack(">I", zlib.crc32(kind + data) & 0xFFFFFFFF)
    )


def _synthetic_png_base64(label: str) -> str:
    """Return deterministic test data accepted by the router's PNG guard.

    The fake upstream never renders or writes an image.  The signature is
    sufficient for the router boundary test; the label makes concurrent
    responses distinguishable without using any real image data.
    """

    # One opaque RGB pixel plus a bounded text marker.  This is a structurally
    # valid PNG with canonical CRCs and a real zlib-compressed IDAT stream.
    ihdr = struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0)
    marker = b"Label\x00" + label.encode("utf-8")[:256]
    png = (
        PNG_SIGNATURE
        + _png_chunk(b"IHDR", ihdr)
        + _png_chunk(b"tEXt", marker)
        + _png_chunk(b"IDAT", zlib.compress(b"\x00\x12\x34\x56"))
        + _png_chunk(b"IEND", b"")
    )
    return base64.b64encode(png).decode("ascii")


RESPONSES_IMAGE_B64 = _synthetic_png_base64(RESPONSES_IMAGE_PROMPT)


class HarnessFailure(AssertionError):
    pass


@dataclass(frozen=True)
class RequestRecord:
    method: str
    path: str
    headers: dict[str, str]
    body: bytes
    json_body: Any


class CaptureState:
    def __init__(self, label: str) -> None:
        self.label = label
        self._lock = threading.Lock()
        self._requests: list[RequestRecord] = []
        self.cancelled = threading.Event()

    def append(self, record: RequestRecord) -> None:
        with self._lock:
            self._requests.append(record)

    def count(self) -> int:
        with self._lock:
            return len(self._requests)

    def last(self) -> RequestRecord:
        with self._lock:
            if not self._requests:
                raise HarnessFailure(f"{self.label} did not receive a request")
            return self._requests[-1]

    def snapshot(self) -> list[RequestRecord]:
        with self._lock:
            return list(self._requests)


def _read_request_body(handler: BaseHTTPRequestHandler) -> bytes:
    transfer_encoding = handler.headers.get("Transfer-Encoding", "").lower()
    if "chunked" not in transfer_encoding:
        length = int(handler.headers.get("Content-Length", "0") or "0")
        return handler.rfile.read(length) if length else b""

    body = bytearray()
    while True:
        line = handler.rfile.readline().strip()
        if not line:
            continue
        size = int(line.split(b";", 1)[0], 16)
        if size == 0:
            while handler.rfile.readline() not in (b"\r\n", b"\n", b""):
                pass
            break
        body.extend(handler.rfile.read(size))
        handler.rfile.read(2)
    return bytes(body)


def _json_or_none(body: bytes) -> Any:
    try:
        return json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None


class FakeServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(
        self,
        address: tuple[str, int],
        label: str,
        state: CaptureState,
        redirect_url: str | None = None,
    ) -> None:
        super().__init__(address, FakeHandler)
        self.label = label
        self.state = state
        self.redirect_url = redirect_url

    def handle_error(self, _request: object, _client_address: object) -> None:
        # Connection resets are expected during the cancellation assertion.
        return


class FakeHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server: FakeServer

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def _capture(self, body: bytes) -> RequestRecord:
        record = RequestRecord(
            method=self.command,
            path=self.path,
            headers={key.lower(): value for key, value in self.headers.items()},
            body=body,
            json_body=_json_or_none(body),
        )
        self.server.state.append(record)
        return record

    def _send_json(
        self,
        status: int,
        payload: dict[str, Any],
        headers: dict[str, str] | None = None,
    ) -> None:
        encoded = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(encoded)
        self.wfile.flush()

    def _send_chunk(self, payload: bytes) -> None:
        self.wfile.write(f"{len(payload):X}\r\n".encode("ascii"))
        self.wfile.write(payload)
        self.wfile.write(b"\r\n")
        self.wfile.flush()

    def _send_sse(self, cancellation_probe: bool) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Transfer-Encoding", "chunked")
        self.end_headers()
        try:
            self._send_chunk(b'data: {"event":"first"}\n\n')
            if cancellation_probe:
                deadline = time.monotonic() + 5.0
                sequence = 0
                while time.monotonic() < deadline:
                    time.sleep(0.1)
                    readable, _, exceptional = select.select(
                        [self.connection], [], [self.connection], 0
                    )
                    if exceptional:
                        self.server.state.cancelled.set()
                        return
                    if readable:
                        try:
                            if self.connection.recv(1, socket.MSG_PEEK) == b"":
                                self.server.state.cancelled.set()
                                return
                        except (ConnectionResetError, OSError):
                            self.server.state.cancelled.set()
                            return
                    sequence += 1
                    self._send_chunk(f": heartbeat-{sequence}\n\n".encode("ascii"))
            else:
                time.sleep(SSE_DELAY_SECONDS)
                self._send_chunk(b'data: {"event":"second"}\n\n')
                self._send_chunk(b"data: [DONE]\n\n")
                self.wfile.write(b"0\r\n\r\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError):
            if cancellation_probe:
                self.server.state.cancelled.set()

    def do_GET(self) -> None:
        self._capture(b"")
        parsed = urlsplit(self.path)
        query = parse_qs(parsed.query, keep_blank_values=True)
        if (
            self.server.label == "openai-upstream"
            and parsed.path == "/models"
            and query.get("client_version") == [CATALOG_ERROR_CLIENT_VERSION]
        ):
            self._send_json(
                503,
                {"error": "synthetic official catalog unavailable"},
                {
                    "Retry-After": "11",
                    "X-Request-ID": "synthetic-catalog-request-503",
                },
            )
            return
        if self.server.label == "openai-upstream" and parsed.path == "/models":
            self._send_json(
                200,
                {"models": list(OFFICIAL_CATALOG_MODELS)},
                {"X-Request-ID": "synthetic-catalog-request-200"},
            )
            return
        self._send_json(200, {"server": self.server.label})

    def do_POST(self) -> None:
        body = _read_request_body(self)
        record = self._capture(body)

        if self.server.label == "ssrf-trap":
            self._send_json(200, {"trap": "hit"})
            return

        payload = record.json_body if isinstance(record.json_body, dict) else {}
        metadata = payload.get("metadata")
        behavior = metadata.get("router_security_test") if isinstance(metadata, dict) else None
        prompt = payload.get("prompt")
        if behavior is None and isinstance(prompt, str):
            behavior = {
                "<SYNTHETIC_REDIRECT_INPUT>": "redirect",
                "<SYNTHETIC_STATUS_INPUT>": "status-429",
            }.get(prompt)

        if behavior == "redirect":
            self.send_response(302)
            self.send_header("Location", self.server.redirect_url or "http://127.0.0.1/")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if behavior == "sse":
            self._send_sse(cancellation_probe=False)
            return
        if behavior == "cancel":
            self._send_sse(cancellation_probe=True)
            return
        if behavior == "status-401":
            self._send_json(
                401,
                {"error": "<SYNTHETIC_UNAUTHORIZED_BODY>"},
                {"WWW-Authenticate": 'Bearer realm="synthetic"'},
            )
            return
        if behavior == "status-429":
            self._send_json(
                429,
                {"error": "synthetic rate limit"},
                {"Retry-After": "7", "X-Request-ID": "synthetic-request-429"},
            )
            return

        if urlsplit(record.path).path.endswith("/images/generations"):
            if prompt == "router-security:responses-image-invalid-json":
                malformed = b'{"data":['
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(malformed)))
                self.end_headers()
                self.wfile.write(malformed)
                self.wfile.flush()
                return
            if prompt == "router-security:responses-image-invalid-shape":
                self._send_json(200, {"data": []})
                return
            if prompt == "router-security:responses-image-invalid-base64":
                self._send_json(200, {"data": [{"b64_json": "not+strict/base64!"}]})
                return
            if isinstance(prompt, str) and prompt.startswith("<SYNTHETIC_CONCURRENT_INPUT_"):
                encoded_prompt = _synthetic_png_base64(prompt)
                self._send_json(200, {"data": [{"b64_json": encoded_prompt}]})
                return
            if prompt == RESPONSES_IMAGE_PROMPT:
                self._send_json(
                    200,
                    {"data": [{"b64_json": RESPONSES_IMAGE_B64}]},
                    {"X-Request-ID": "synthetic-responses-image-request-200"},
                )
                return
            if prompt == "<SYNTHETIC_INPUT_PART_1>\n<SYNTHETIC_INPUT_PART_2>":
                self._send_json(
                    200,
                    {"data": [{"b64_json": _synthetic_png_base64(prompt)}]},
                )
                return
            if isinstance(prompt, str) and prompt.startswith("<SYNTHETIC_PATH_INPUT>"):
                self._send_json(
                    200,
                    {"data": [{"b64_json": _synthetic_png_base64(prompt)}]},
                )
                return
            if isinstance(prompt, str) and prompt.startswith("<SYNTHETIC_STORAGE_INPUT"):
                self._send_json(
                    200,
                    {"data": [{"b64_json": _synthetic_png_base64(prompt)}]},
                )
                return
            if prompt == "<SYNTHETIC_CANCEL_INPUT>":
                time.sleep(1.0)
                self._send_json(
                    200,
                    {"data": [{"b64_json": _synthetic_png_base64(prompt)}]},
                )
                return
            self._send_json(
                200,
                IMAGE_SUCCESS_PAYLOAD,
                {"X-Request-ID": "synthetic-image-request-200"},
            )
            return

        self._send_json(
            200,
            {
                "server": self.server.label,
                "model": payload.get("model"),
                "ok": True,
            },
        )


class RunningFakeServer:
    def __init__(self, label: str, redirect_url: str | None = None) -> None:
        self.state = CaptureState(label)
        self.server = FakeServer((LOOPBACK, 0), label, self.state, redirect_url)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    @property
    def url(self) -> str:
        host, port = self.server.server_address[:2]
        return f"http://{host}:{port}"

    def start(self) -> None:
        self.thread.start()

    def stop(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)


def _reserve_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind((LOOPBACK, 0))
        return int(sock.getsockname()[1])


def _router_request(
    port: int,
    body: dict[str, Any],
    headers: dict[str, str] | None = None,
    path: str = "/responses",
    timeout: float = 8.0,
) -> tuple[int, dict[str, str], bytes]:
    encoded = json.dumps(body, separators=(",", ":")).encode("utf-8")
    request_headers = {
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream",
        "Content-Length": str(len(encoded)),
        "Connection": "close",
    }
    request_headers.update(headers or {})
    connection = http.client.HTTPConnection(LOOPBACK, port, timeout=timeout)
    try:
        connection.request("POST", path, body=encoded, headers=request_headers)
        response = connection.getresponse()
        response_body = response.read()
        return (
            response.status,
            {key.lower(): value for key, value in response.getheaders()},
            response_body,
        )
    finally:
        connection.close()


def _router_get(
    port: int,
    path: str,
    headers: dict[str, str] | None = None,
    timeout: float = 8.0,
) -> tuple[int, dict[str, str], bytes]:
    request_headers = {
        "Accept": "application/json",
        "Connection": "close",
    }
    request_headers.update(headers or {})
    connection = http.client.HTTPConnection(LOOPBACK, port, timeout=timeout)
    try:
        connection.request("GET", path, headers=request_headers)
        response = connection.getresponse()
        response_body = response.read()
        return (
            response.status,
            {key.lower(): value for key, value in response.getheaders()},
            response_body,
        )
    finally:
        connection.close()


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise HarnessFailure(message)


def _serialized_record(record: RequestRecord) -> str:
    return json.dumps(
        {
            "headers": record.headers,
            "body": record.body.decode("utf-8", errors="replace"),
        },
        sort_keys=True,
    )


def _parse_sse_json_events(body: bytes) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for raw_line in body.splitlines():
        if not raw_line.startswith(b"data:"):
            continue
        raw_data = raw_line[5:].strip()
        if raw_data in {b"", b"[DONE]"}:
            continue
        try:
            event = json.loads(raw_data.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise HarnessFailure(f"invalid JSON in SSE data line: {raw_data[:200]!r}") from exc
        _assert(isinstance(event, dict), "SSE data event is not an object")
        events.append(event)
    return events


def _markdown_image_path_from_item(item: dict[str, Any]) -> Path:
    _assert(item.get("type") == "message", "Responses image output is not an assistant message")
    _assert(item.get("role") == "assistant", "Responses image output has wrong role")
    content = item.get("content")
    _assert(isinstance(content, list) and len(content) == 1, "wrong image message content")
    output = content[0]
    _assert(
        isinstance(output, dict) and output.get("type") == "output_text",
        "Responses image message has no output_text",
    )
    text_value = output.get("text")
    _assert(isinstance(text_value, str), "Responses image output_text is missing")
    match = re.fullmatch(r"!\[Generated image\]\(([^\r\n]+)\)", text_value)
    _assert(match is not None, f"unsafe image Markdown {text_value!r}")
    raw_path = match.group(1)
    if raw_path.startswith("<") and raw_path.endswith(">"):
        raw_path = raw_path[1:-1]
    _assert("<" not in raw_path and ">" not in raw_path, "unsafe path wrapper")
    return Path(raw_path.replace("/", os.sep))


def _wait_for_tcp(port: int, process: subprocess.Popen[str], timeout: float = 8.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            stdout, stderr = process.communicate(timeout=1)
            raise HarnessFailure(
                f"router exited before listening (code {process.returncode})\n"
                f"stdout:\n{stdout}\nstderr:\n{stderr}"
            )
        try:
            with socket.create_connection((LOOPBACK, port), timeout=0.2):
                return
        except OSError:
            time.sleep(0.05)
    raise HarnessFailure(f"router did not listen on {LOOPBACK}:{port} within {timeout}s")


def _parse_endpoint(endpoint: str) -> tuple[str, int] | None:
    endpoint = endpoint.strip()
    if endpoint.startswith("[") and "]:" in endpoint:
        host, port_text = endpoint[1:].rsplit("]:", 1)
    elif ":" in endpoint:
        host, port_text = endpoint.rsplit(":", 1)
    else:
        return None
    try:
        return host, int(port_text)
    except ValueError:
        return None


def _listener_addresses(port: int) -> list[str]:
    if os.name != "nt":
        return []
    completed = subprocess.run(
        ["netstat", "-ano", "-p", "tcp"],
        check=False,
        capture_output=True,
        text=True,
        timeout=5,
    )
    addresses: list[str] = []
    for line in completed.stdout.splitlines():
        fields = line.split()
        if len(fields) < 4 or fields[0].upper() != "TCP":
            continue
        local = _parse_endpoint(fields[1])
        remote = _parse_endpoint(fields[2])
        if local is None or remote is None or local[1] != port:
            continue
        if remote[1] == 0:
            addresses.append(local[0])
    return addresses


class RouterSecurityHarness:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.trap = RunningFakeServer("ssrf-trap")
        self.openai: RunningFakeServer | None = None
        self.solov: RunningFakeServer | None = None
        self.router_port = _reserve_port()
        self.router_process: subprocess.Popen[str] | None = None
        self.results: list[tuple[str, bool, str]] = []
        self._temporary_directory = tempfile.TemporaryDirectory(
            prefix="codex-dual-router-security-"
        )
        self.router_log_path = Path(self._temporary_directory.name) / "router-events.jsonl"
        self.image_output_root = Path(self._temporary_directory.name) / "generated-images"

    def start(self) -> None:
        self.trap.start()
        redirect_url = f"{self.trap.url}/redirect-target"
        self.openai = RunningFakeServer("openai-upstream", redirect_url)
        self.solov = RunningFakeServer("solov-upstream", redirect_url)
        self.openai.start()
        self.solov.start()

        fixture = Path(__file__).with_name("router_test_fixture.py")
        if self.args.self_test_router or not self.args.router_command:
            command = [sys.executable, str(fixture)]
        else:
            replacements = {
                "host": LOOPBACK,
                "port": str(self.router_port),
                "openai_upstream": self.openai.url,
                "solov_upstream": f"{self.solov.url}/v1",
                "solov_key": SOLOV_TEST_KEY,
                "openai_model": OPENAI_MODEL_ALIAS,
                "solov_model": SOLOV_MODEL_ALIAS,
            }
            command = [token.format(**replacements) for token in self.args.router_command]

        environment = os.environ.copy()
        environment.update(
            {
                "ROUTER_HOST": LOOPBACK,
                "ROUTER_PORT": str(self.router_port),
                "OPENAI_UPSTREAM_BASE_URL": self.openai.url,
                "SOLOV_UPSTREAM_BASE_URL": f"{self.solov.url}/v1",
                "SOLOV_API_KEY": SOLOV_TEST_KEY,
                "OPENAI_MODEL_ALIASES": f"{OPENAI_MODEL_ALIAS}={OPENAI_UPSTREAM_MODEL}",
                "SOLOV_MODEL_ALIASES": f"{SOLOV_MODEL_ALIAS}={SOLOV_UPSTREAM_MODEL}",
                "SOLOV_IMAGE_MODEL_ALIASES": ",".join(
                    f"{alias}={model}"
                    for alias, model in zip(SOLOV_IMAGE_ALIASES, SOLOV_IMAGE_MODELS)
                ),
                "ROUTER_TEST_SOLOV_CATALOG_JSON": json.dumps(
                    {"models": list(SOLOV_CATALOG_MODELS)},
                    separators=(",", ":"),
                ),
                "ROUTER_TEST_MODE": "1",
                "ROUTER_TEST_LOG_PATH": str(self.router_log_path),
                "ROUTER_TEST_IMAGE_OUTPUT_ROOT": str(self.image_output_root.resolve()),
            }
        )
        self.router_process = subprocess.Popen(
            command,
            cwd=self.args.router_cwd,
            env=environment,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        _wait_for_tcp(self.router_port, self.router_process)

    def stop(self) -> None:
        if self.router_process is not None:
            if self.router_process.poll() is None:
                self.router_process.terminate()
                try:
                    self.router_process.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    self.router_process.kill()
                    self.router_process.communicate(timeout=3)
        if self.openai is not None:
            self.openai.stop()
        if self.solov is not None:
            self.solov.stop()
        self.trap.stop()
        self._temporary_directory.cleanup()

    @property
    def _openai(self) -> RunningFakeServer:
        assert self.openai is not None
        return self.openai

    @property
    def _solov(self) -> RunningFakeServer:
        assert self.solov is not None
        return self.solov

    def _no_upstream_delta(self, before: tuple[int, int, int]) -> None:
        after = (
            self._openai.state.count(),
            self._solov.state.count(),
            self.trap.state.count(),
        )
        _assert(after == before, f"unexpected upstream request: before={before}, after={after}")

    def test_loopback_only(self) -> None:
        listeners = _listener_addresses(self.router_port)
        if listeners:
            unsafe = sorted({address for address in listeners if address not in {LOOPBACK, "::1"}})
            _assert(not unsafe, f"router has non-loopback listeners: {unsafe}")
            _assert(LOOPBACK in listeners, f"expected an IPv4 loopback listener, found {listeners}")

        non_loopback_addresses = {
            info[4][0]
            for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)
            if not info[4][0].startswith("127.")
        }
        for address in non_loopback_addresses:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(0.3)
                _assert(
                    sock.connect_ex((address, self.router_port)) != 0,
                    f"router accepted a connection through non-loopback address {address}",
                )
        _assert(bool(listeners or non_loopback_addresses), "unable to prove listener binding")

    def test_unknown_path_rejected(self) -> None:
        before = (self._openai.state.count(), self._solov.state.count(), self.trap.state.count())
        status, _, _ = _router_request(
            self.router_port,
            {"model": OPENAI_MODEL_ALIAS, "input": "test"},
            path="/v1/not-a-router-route",
        )
        _assert(status in {400, 404, 405}, f"unknown path returned unsafe status {status}")
        self._no_upstream_delta(before)

    def test_unknown_model_rejected(self) -> None:
        before = (self._openai.state.count(), self._solov.state.count(), self.trap.state.count())
        status, _, body = _router_request(
            self.router_port,
            {"model": "unknown/model-that-must-not-route", "input": "test"},
            headers={"Authorization": CHATGPT_TEST_AUTH},
        )
        _assert(
            status in {400, 404, 422},
            f"unknown model returned unsafe status {status}: {body[:500]!r}",
        )
        self._no_upstream_delta(before)

    def test_models_merge_preserves_official_catalog_and_auth(self) -> None:
        solov_before = self._solov.state.count()
        catalog_path = "/models?client_version=security-harness.1"
        headers = {
            "Authorization": CHATGPT_TEST_AUTH,
            "ChatGPT-Account-ID": CHATGPT_TEST_ACCOUNT,
            "X-OAI-Attestation": ATTESTATION_TEST_VALUE,
            "Originator": "codex-desktop-test-originator",
            "Session-ID": "<SYNTHETIC_SESSION>",
            "X-Codex-Installation-ID": "catalog-installation-test-not-real",
        }
        status, _, body = _router_get(
            self.router_port,
            catalog_path,
            headers=headers,
        )
        _assert(status == 200, f"merged model catalog returned {status}: {body[:500]!r}")
        try:
            payload = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise HarnessFailure(f"merged model catalog is not JSON: {exc}") from exc
        _assert(isinstance(payload, dict), "merged model catalog is not an object")
        models = payload.get("models")
        _assert(isinstance(models, list), "merged model catalog has no models array")

        official_count = len(OFFICIAL_CATALOG_MODELS)
        _assert(
            models[:official_count] == list(OFFICIAL_CATALOG_MODELS),
            "official model records or their order changed during catalog merge",
        )
        appended = models[official_count:]
        _assert(
            appended == list(SOLOV_CATALOG_MODELS),
            f"catalog tail was not exactly the configured Solov append set: {appended!r}",
        )
        _assert(
            all(
                isinstance(model, dict)
                and isinstance(model.get("slug"), str)
                and model["slug"].startswith("solov::")
                and isinstance(model.get("display_name"), str)
                and (
                    model["display_name"].endswith(" \u00b7 Solov")
                    or model["display_name"].endswith(" \u00b7 Solov Image")
                )
                for model in appended
            ),
            "one or more appended models lacked the Solov slug namespace or provider suffix",
        )
        _assert(
            all(
                not model["slug"].startswith("solov::")
                and not model["display_name"].endswith(" \u00b7 Solov")
                for model in models[:official_count]
            ),
            "an official model was relabeled as Solov",
        )

        _assert(
            self._solov.state.count() == solov_before,
            "GET /models contacted the Solov upstream instead of using the local append catalog",
        )
        record = self._openai.state.last()
        _assert(record.method == "GET", f"official catalog used {record.method} instead of GET")
        _assert(record.path == catalog_path, f"official catalog query changed to {record.path!r}")
        for name, expected in {
            "authorization": CHATGPT_TEST_AUTH,
            "chatgpt-account-id": CHATGPT_TEST_ACCOUNT,
            "x-oai-attestation": ATTESTATION_TEST_VALUE,
            "originator": "codex-desktop-test-originator",
            "session-id": "<SYNTHETIC_SESSION>",
            "x-codex-installation-id": "catalog-installation-test-not-real",
        }.items():
            _assert(record.headers.get(name) == expected, f"official catalog header {name} changed")
        _assert(SOLOV_TEST_KEY not in _serialized_record(record), "official GET /models leaked Solov key")

    def test_dynamic_official_model_posts_after_catalog_refresh(self) -> None:
        status, _, body = _router_get(
            self.router_port,
            "/models?client_version=security-harness.dynamic",
            headers={"Authorization": CHATGPT_TEST_AUTH},
        )
        _assert(status == 200, f"official catalog refresh returned {status}: {body[:500]!r}")

        status, _, body = _router_request(
            self.router_port,
            {"model": DYNAMIC_OPENAI_MODEL, "input": "dynamic model test"},
            headers={
                "Authorization": CHATGPT_TEST_AUTH,
                "ChatGPT-Account-ID": CHATGPT_TEST_ACCOUNT,
            },
        )
        _assert(status == 200, f"catalog-discovered official model returned {status}: {body[:500]!r}")
        record = self._openai.state.last()
        _assert(record.method == "POST", "dynamic official model did not reach OpenAI as POST")
        _assert(
            isinstance(record.json_body, dict)
            and record.json_body.get("model") == DYNAMIC_OPENAI_MODEL,
            "catalog-discovered official model slug changed before POST",
        )
        _assert(record.headers.get("authorization") == CHATGPT_TEST_AUTH, "dynamic POST auth changed")
        _assert(SOLOV_TEST_KEY not in _serialized_record(record), "dynamic official POST leaked Solov key")

    def test_models_official_error_has_no_solov_fallback(self) -> None:
        # Seed the dynamic official allowlist first; an error must neither expose
        # a Solov-only catalog nor destroy the last known-good official set.
        status, _, body = _router_get(
            self.router_port,
            "/models?client_version=security-harness.seed",
            headers={"Authorization": CHATGPT_TEST_AUTH},
        )
        _assert(status == 200, f"catalog seed returned {status}: {body[:500]!r}")

        solov_before = self._solov.state.count()
        error_path = f"/models?client_version={CATALOG_ERROR_CLIENT_VERSION}"
        status, response_headers, body = _router_get(
            self.router_port,
            error_path,
            headers={
                "Authorization": CHATGPT_TEST_AUTH,
                "ChatGPT-Account-ID": CHATGPT_TEST_ACCOUNT,
            },
        )
        _assert(status == 503, f"official catalog 503 changed to {status}: {body[:500]!r}")
        _assert(response_headers.get("retry-after") == "11", "catalog Retry-After was not preserved")
        _assert(
            response_headers.get("x-request-id") == "synthetic-catalog-request-503",
            "catalog error request ID was not preserved",
        )
        _assert(
            body == b'{"error":"synthetic official catalog unavailable"}',
            f"official catalog error body changed or was replaced: {body[:500]!r}",
        )
        _assert(SOLOV_TEST_KEY.encode("utf-8") not in body, "catalog error leaked Solov key")
        _assert(SOLOV_MODEL_ALIAS.encode("utf-8") not in body, "catalog error fell back to Solov-only data")
        _assert(
            self._solov.state.count() == solov_before,
            "official catalog failure contacted the Solov upstream",
        )
        error_record = self._openai.state.last()
        _assert(error_record.method == "GET" and error_record.path == error_path, "wrong error request")
        _assert(
            error_record.headers.get("authorization") == CHATGPT_TEST_AUTH,
            "official catalog error probe changed ChatGPT auth",
        )
        _assert(SOLOV_TEST_KEY not in _serialized_record(error_record), "erroring official GET leaked key")

        status, _, body = _router_request(
            self.router_port,
            {"model": DYNAMIC_OPENAI_MODEL, "input": "cache survives error"},
            headers={"Authorization": CHATGPT_TEST_AUTH},
        )
        _assert(
            status == 200,
            f"official catalog error erased the last known-good dynamic model set: {status} {body[:500]!r}",
        )

    def test_solov_identity_header_isolation(self) -> None:
        headers = {
            "Authorization": CHATGPT_TEST_AUTH,
            "ChatGPT-Account-ID": CHATGPT_TEST_ACCOUNT,
            "X-OAI-Attestation": ATTESTATION_TEST_VALUE,
            "Originator": "codex-desktop-test-originator",
            "X-Codex-Installation-ID": "installation-test-not-real",
            "X-Codex-Turn-State": "turn-state-test-not-real",
            "X-OpenAI-Subagent": "subagent-test-not-real",
            "X-OpenAI-Internal-Codex-Responses-Lite": "responses-lite-test-not-real",
            "X-Stainless-Arch": "stainless-test-not-real",
            "X-Client-Request-ID": "client-request-test-not-real",
            "Session-ID": "<SYNTHETIC_SESSION>",
            "Thread-ID": "<SYNTHETIC_THREAD>",
            "Baggage": "baggage-test-not-real",
            "Traceparent": "00-00000000000000000000000000000001-0000000000000001-01",
        }
        status, _, _ = _router_request(
            self.router_port,
            {"model": SOLOV_MODEL_ALIAS, "input": "test"},
            headers=headers,
        )
        _assert(status == 200, f"Solov branch returned {status}")
        record = self._solov.state.last()
        _assert(
            record.headers.get("authorization") == f"Bearer {SOLOV_TEST_KEY}",
            "Solov upstream did not receive exactly the synthetic Solov credential",
        )
        forbidden_headers = {
            "chatgpt-account-id",
            "x-oai-attestation",
            "originator",
            "session-id",
            "thread-id",
            "baggage",
            "traceparent",
            "x-codex-installation-id",
            "x-codex-turn-state",
            "x-openai-subagent",
            "x-openai-internal-codex-responses-lite",
            "x-stainless-arch",
            "x-client-request-id",
        }
        leaked_names = sorted(forbidden_headers.intersection(record.headers))
        _assert(not leaked_names, f"Solov upstream received first-party identity headers: {leaked_names}")
        leaked_prefixes = sorted(
            name
            for name in record.headers
            if name.startswith(("x-codex-", "x-oai-", "x-openai-", "x-stainless-"))
        )
        _assert(not leaked_prefixes, f"Solov upstream received first-party header prefixes: {leaked_prefixes}")
        serialized = _serialized_record(record)
        for sentinel in (
            CHATGPT_TEST_AUTH,
            CHATGPT_TEST_ACCOUNT,
            ATTESTATION_TEST_VALUE,
            "installation-test-not-real",
            "turn-state-test-not-real",
            "subagent-test-not-real",
            "responses-lite-test-not-real",
            "stainless-test-not-real",
            "client-request-test-not-real",
            "<SYNTHETIC_SESSION>",
            "<SYNTHETIC_THREAD>",
            "baggage-test-not-real",
        ):
            _assert(sentinel not in serialized, f"Solov request leaked sentinel {sentinel!r}")
        _assert(
            isinstance(record.json_body, dict)
            and record.json_body.get("model") == SOLOV_UPSTREAM_MODEL,
            "Solov model alias was not rewritten to the allowlisted upstream model",
        )

    def test_solov_image_models_prefix_stripping_and_isolation(self) -> None:
        identity_headers = {
            "Authorization": CHATGPT_TEST_AUTH,
            "ChatGPT-Account-ID": CHATGPT_TEST_ACCOUNT,
            "X-OAI-Attestation": ATTESTATION_TEST_VALUE,
            "Originator": "codex-desktop-image-test-originator",
            "X-Codex-Installation-ID": "image-installation-test-not-real",
            "X-Codex-Turn-State": "image-turn-state-test-not-real",
            "X-OpenAI-Subagent": "image-subagent-test-not-real",
            "X-OpenAI-Internal-Codex-Responses-Lite": "image-responses-lite-test-not-real",
            "X-Stainless-Arch": "image-stainless-test-not-real",
            "X-Client-Request-ID": "image-client-request-test-not-real",
            "Session-ID": "<SYNTHETIC_SESSION>",
            "Thread-ID": "<SYNTHETIC_THREAD>",
            "Baggage": "image-baggage-test-not-real",
            "Traceparent": "00-00000000000000000000000000000002-0000000000000002-01",
        }
        forbidden_headers = {
            "chatgpt-account-id",
            "x-oai-attestation",
            "originator",
            "session-id",
            "thread-id",
            "baggage",
            "traceparent",
            "x-codex-installation-id",
            "x-codex-turn-state",
            "x-openai-subagent",
            "x-openai-internal-codex-responses-lite",
            "x-stainless-arch",
            "x-client-request-id",
        }
        sentinels = (
            CHATGPT_TEST_AUTH,
            CHATGPT_TEST_ACCOUNT,
            ATTESTATION_TEST_VALUE,
            "image-installation-test-not-real",
            "image-turn-state-test-not-real",
            "image-subagent-test-not-real",
            "image-responses-lite-test-not-real",
            "image-stainless-test-not-real",
            "image-client-request-test-not-real",
            "<SYNTHETIC_SESSION>",
            "<SYNTHETIC_THREAD>",
            "image-baggage-test-not-real",
        )

        for alias, upstream_model in zip(SOLOV_IMAGE_ALIASES, SOLOV_IMAGE_MODELS):
            before = self._solov.state.count()
            status, _, body = _router_request(
                self.router_port,
                {
                    "model": alias,
                    "prompt": f"<SYNTHETIC_IMAGE_INPUT_FOR> {upstream_model}",
                    "size": "1024x1024",
                },
                headers=identity_headers,
                path="/images/generations",
            )
            _assert(status == 200, f"image model {alias} returned {status}: {body[:500]!r}")
            _assert(
                self._solov.state.count() == before + 1,
                f"image model {alias} did not make exactly one Solov request",
            )
            record = self._solov.state.last()
            _assert(
                record.method == "POST" and record.path == "/v1/images/generations",
                f"image model {alias} reached the wrong upstream path {record.path!r}",
            )
            _assert(
                isinstance(record.json_body, dict)
                and record.json_body.get("model") == upstream_model,
                f"image model prefix was not stripped exactly for {alias}",
            )
            _assert(
                record.headers.get("authorization") == f"Bearer {SOLOV_TEST_KEY}",
                f"image model {alias} did not receive exactly the synthetic Solov key",
            )
            leaked_names = sorted(forbidden_headers.intersection(record.headers))
            _assert(
                not leaked_names,
                f"image request leaked first-party identity headers: {leaked_names}",
            )
            leaked_prefixes = sorted(
                name
                for name in record.headers
                if name.startswith(("x-codex-", "x-oai-", "x-openai-", "x-stainless-"))
            )
            _assert(
                not leaked_prefixes,
                f"image request leaked first-party header prefixes: {leaked_prefixes}",
            )
            serialized = _serialized_record(record)
            for sentinel in sentinels:
                _assert(sentinel not in serialized, f"image request leaked sentinel {sentinel!r}")

    def test_solov_image_unknown_and_official_models_rejected(self) -> None:
        for model in (
            "gpt-image-1",
            "solov::unknown-image-model",
            SOLOV_MODEL_ALIAS,
            OPENAI_MODEL_ALIAS,
        ):
            before = (
                self._openai.state.count(),
                self._solov.state.count(),
                self.trap.state.count(),
            )
            status, _, body = _router_request(
                self.router_port,
                {"model": model, "prompt": "<SYNTHETIC_REJECTED_INPUT>"},
                headers={"Authorization": CHATGPT_TEST_AUTH},
                path="/images/generations",
            )
            _assert(
                status in {400, 404, 422},
                f"disallowed image-route model {model!r} returned unsafe status {status}: {body[:500]!r}",
            )
            self._no_upstream_delta(before)

    def test_solov_image_ssrf_and_redirect_resistance(self) -> None:
        trap_url = f"{self.trap.url}/must-not-be-requested-by-image-route"
        before = (
            self._openai.state.count(),
            self._solov.state.count(),
            self.trap.state.count(),
        )
        status, _, _ = _router_request(
            self.router_port,
            {"model": trap_url, "prompt": "must not route"},
            headers={
                "Authorization": CHATGPT_TEST_AUTH,
                "X-Upstream-URL": trap_url,
                "X-Forwarded-Host": urlsplit(trap_url).netloc,
            },
            path=f"/images/generations?upstream={trap_url}",
        )
        _assert(status in {400, 404, 422}, f"image SSRF probe returned unsafe status {status}")
        self._no_upstream_delta(before)

        trap_before = self.trap.state.count()
        status, _, body = _router_request(
            self.router_port,
            {"model": SOLOV_IMAGE_ALIASES[0], "prompt": trap_url},
            headers={
                "Authorization": CHATGPT_TEST_AUTH,
                "X-Upstream-URL": trap_url,
                "X-Forwarded-Host": urlsplit(trap_url).netloc,
                "Forwarded": f"host={urlsplit(trap_url).netloc}",
                "X-Original-URL": trap_url,
            },
            path="/images/generations",
        )
        _assert(status == 200, f"allowlisted image SSRF-resistance probe returned {status}: {body[:500]!r}")
        _assert(self.trap.state.count() == trap_before, "image route honored caller-controlled URL")
        record = self._solov.state.last()
        override_names = {"x-upstream-url", "x-forwarded-host", "forwarded", "x-original-url"}
        leaked = sorted(override_names.intersection(record.headers))
        _assert(not leaked, f"image routing override headers reached Solov: {leaked}")

        trap_before = self.trap.state.count()
        status, _, _ = _router_request(
            self.router_port,
            {
                "model": SOLOV_IMAGE_ALIASES[0],
                "prompt": "<SYNTHETIC_REDIRECT_INPUT>",
            },
            headers={"Authorization": CHATGPT_TEST_AUTH},
            path="/images/generations",
        )
        _assert(
            status in {301, 302, 303, 307, 308, 502},
            f"image upstream redirect became unsafe status {status}",
        )
        _assert(self.trap.state.count() == trap_before, "image route followed an upstream redirect")

    def test_solov_image_response_passthrough(self) -> None:
        status, headers, body = _router_request(
            self.router_port,
            {
                "model": SOLOV_IMAGE_ALIASES[1],
                "prompt": "<SYNTHETIC_IMAGE_INPUT>",
            },
            headers={"Authorization": CHATGPT_TEST_AUTH},
            path="/images/generations",
        )
        expected = json.dumps(IMAGE_SUCCESS_PAYLOAD, separators=(",", ":")).encode("utf-8")
        _assert(status == 200, f"image success status changed to {status}")
        _assert(body == expected, f"image success body changed: {body[:500]!r}")
        _assert(
            headers.get("x-request-id") == "synthetic-image-request-200",
            "image success request ID was not preserved",
        )
        _assert("application/json" in headers.get("content-type", ""), "image content type changed")
        _assert(SOLOV_TEST_KEY.encode("utf-8") not in body, "image response exposed Solov key")

        status, headers, body = _router_request(
            self.router_port,
            {
                "model": SOLOV_IMAGE_ALIASES[2],
                "prompt": "<SYNTHETIC_STATUS_INPUT>",
            },
            headers={"Authorization": CHATGPT_TEST_AUTH},
            path="/images/generations",
        )
        _assert(status == 429, f"image upstream 429 changed to {status}")
        _assert(headers.get("retry-after") == "7", "image Retry-After was not preserved")
        _assert(headers.get("x-request-id") == "synthetic-request-429", "image request ID missing")
        _assert(body == b'{"error":"synthetic rate limit"}', f"image 429 body changed: {body!r}")
        _assert(SOLOV_TEST_KEY.encode("utf-8") not in body, "image error exposed Solov key")

    def _responses_image_request(
        self,
        prompt: str,
        *,
        model: str = SOLOV_IMAGE_ALIASES[0],
        input_payload: Any | None = None,
        extra: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> tuple[int, dict[str, str], bytes]:
        payload: dict[str, Any] = {
            "model": model,
            "stream": True,
            "input": prompt if input_payload is None else input_payload,
        }
        payload.update(extra or {})
        return _router_request(
            self.router_port,
            payload,
            headers={"Authorization": CHATGPT_TEST_AUTH, **(headers or {})},
        )

    def test_responses_image_text_prompt_and_sse_contract(self) -> None:
        identity_headers = {
            "ChatGPT-Account-ID": CHATGPT_TEST_ACCOUNT,
            "X-OAI-Attestation": ATTESTATION_TEST_VALUE,
            "Originator": "<SYNTHETIC_ORIGINATOR>",
            "X-Codex-Installation-ID": "<SYNTHETIC_INSTALLATION>",
            "Session-ID": "<SYNTHETIC_SESSION>",
            "Thread-ID": "<SYNTHETIC_THREAD>",
            "Baggage": "<SYNTHETIC_BAGGAGE>",
        }
        before = self._solov.state.count()
        status, headers, body = self._responses_image_request(
            RESPONSES_IMAGE_PROMPT,
            # Real Codex sends these fields even when catalog metadata disables
            # tools.  The image bridge must ignore them, never relay them.
            extra={
                "instructions": "<SYNTHETIC_IGNORED_INPUT>",
                "tools": [
                    {"type": "function", "name": "synthetic_tool"},
                    {"type": "web_search"},
                ],
                "tool_choice": "auto",
                "parallel_tool_calls": True,
                "include": ["reasoning.encrypted_content"],
                "client_metadata": {"must_not_reach_solov": True},
            },
            headers=identity_headers,
        )
        _assert(status == 200, f"Responses image bridge returned {status}: {body[:500]!r}")
        _assert(
            "text/event-stream" in headers.get("content-type", "").lower(),
            f"Responses image bridge returned wrong content type {headers.get('content-type')!r}",
        )
        events = _parse_sse_json_events(body)
        _assert(
            [event.get("type") for event in events]
            == [
                "response.created",
                "response.output_item.added",
                "response.output_item.done",
                "response.completed",
            ],
            f"unexpected image SSE sequence: {[event.get('type') for event in events]!r}",
        )
        _assert(
            [event.get("sequence_number") for event in events] == [0, 1, 2, 3],
            "image SSE sequence numbers are not stable and contiguous",
        )
        created_id = events[0].get("response", {}).get("id")
        completed = events[3].get("response", {})
        added_item = events[1].get("item", {})
        item = events[2].get("item", {})
        _assert(isinstance(created_id, str) and created_id.startswith("resp_"), "unsafe response id")
        _assert(completed.get("id") == created_id, "created/completed response IDs differ")
        _assert(added_item == item, "added/done image message items differ")
        image_path = _markdown_image_path_from_item(item)
        _assert(completed.get("output") == [item], "completed response did not contain same item")
        _assert(RESPONSES_IMAGE_B64.encode("ascii") not in body, "SSE exposed image base64")
        _assert(image_path.is_absolute(), "image Markdown did not use an absolute path")
        _assert(image_path.parent.resolve() == self.image_output_root.resolve(), "image escaped output root")
        _assert(re.fullmatch(r"solov-image-[0-9a-f]{32}\.png", image_path.name) is not None, "unsafe image leaf")
        _assert(image_path.is_file() and not image_path.is_symlink(), "published image is not a regular file")
        expected_bytes = base64.b64decode(RESPONSES_IMAGE_B64)
        _assert(image_path.read_bytes() == expected_bytes, "published PNG bytes changed")
        temporary = [path for path in self.image_output_root.iterdir() if path.suffix == ".tmp"]
        _assert(not temporary, f"successful image left temporary files: {temporary!r}")
        _assert(self._solov.state.count() == before + 1, "image bridge made wrong upstream count")

        record = self._solov.state.last()
        _assert(record.path == "/v1/images/generations", f"wrong image upstream path {record.path!r}")
        _assert(
            record.json_body
            == {
                "model": SOLOV_IMAGE_MODELS[0],
                "prompt": RESPONSES_IMAGE_PROMPT,
                "n": 1,
                "size": "1024x1024",
                "quality": "low",
                "output_format": "png",
            },
            f"Responses fields leaked into Image request: {record.json_body!r}",
        )
        _assert(
            record.headers.get("authorization") == f"Bearer {SOLOV_TEST_KEY}",
            "image bridge did not use exactly synthetic Solov auth",
        )
        forbidden_headers = {
            "chatgpt-account-id",
            "x-oai-attestation",
            "originator",
            "session-id",
            "thread-id",
            "baggage",
            "x-codex-installation-id",
        }
        _assert(
            not forbidden_headers.intersection(record.headers),
            "image bridge leaked first-party identity headers",
        )

    def test_responses_image_latest_user_input_text_only(self) -> None:
        input_payload = [
            {
                "type": "message",
                "role": "developer",
                "content": [{"type": "input_text", "text": "developer text must be ignored"}],
            },
            {
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": "older user text must be ignored"}],
            },
            {
                "type": "message",
                "role": "assistant",
                "content": [{"type": "output_text", "text": "assistant text must be ignored"}],
            },
            {
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": RESPONSES_IMAGE_PROMPT}],
            },
        ]
        status, _, body = self._responses_image_request(
            RESPONSES_IMAGE_PROMPT,
            input_payload=input_payload,
        )
        _assert(status == 200, f"structured Codex image prompt returned {status}: {body[:500]!r}")
        record = self._solov.state.last()
        _assert(
            isinstance(record.json_body, dict)
            and record.json_body.get("prompt") == RESPONSES_IMAGE_PROMPT,
            "image prompt was contaminated by history/instructions",
        )
        serialized = _serialized_record(record)
        for sentinel in (
            "developer text must be ignored",
            "older user text must be ignored",
            "assistant text must be ignored",
        ):
            _assert(sentinel not in serialized, f"image prompt included {sentinel!r}")

        multi_part = [
            {
                "type": "message",
                "role": "user",
                "content": [
                    {"type": "input_text", "text": "<SYNTHETIC_INPUT_PART_1>"},
                    {"type": "input_text", "text": "<SYNTHETIC_INPUT_PART_2>"},
                ],
            }
        ]
        status, _, body = self._responses_image_request(
            "unused",
            input_payload=multi_part,
        )
        _assert(status == 200, f"multiple input_text parts returned {status}: {body[:500]!r}")
        _assert(
            self._solov.state.last().json_body.get("prompt")
            == "<SYNTHETIC_INPUT_PART_1>\n<SYNTHETIC_INPUT_PART_2>",
            "multiple safe input_text parts were not joined deterministically",
        )

    def test_responses_image_rejects_ambiguous_or_multimodal_prompt(self) -> None:
        invalid_inputs: tuple[tuple[str, Any, dict[str, Any]], ...] = (
            ("missing input", None, {}),
            ("empty string", "   ", {}),
            ("too long", "x" * 32_001, {}),
            ("object input", {"text": "not allowed"}, {}),
            ("no user message", [{"type": "message", "role": "developer", "content": []}], {}),
            (
                "input image",
                [{
                    "type": "message",
                    "role": "user",
                    "content": [{"type": "input_image", "image_url": "https://attacker.invalid/a"}],
                }],
                {},
            ),
            (
                "input file",
                [{
                    "type": "message",
                    "role": "user",
                    "content": [{"type": "input_file", "file_id": "file-secret"}],
                }],
                {},
            ),
        )
        for label, input_payload, extra in invalid_inputs:
            before = (
                self._openai.state.count(),
                self._solov.state.count(),
                self.trap.state.count(),
            )
            payload: dict[str, Any] = {
                "model": SOLOV_IMAGE_ALIASES[0],
                "stream": True,
            }
            if label != "missing input":
                payload["input"] = input_payload
            payload.update(extra)
            status, _, body = _router_request(
                self.router_port,
                payload,
                headers={"Authorization": CHATGPT_TEST_AUTH},
            )
            _assert(status == 400, f"{label} returned {status}: {body[:500]!r}")
            error = _json_or_none(body)
            _assert(
                isinstance(error, dict)
                and error.get("error", {}).get("code") == "image_prompt_unsupported",
                f"{label} did not fail with image_prompt_unsupported: {body[:500]!r}",
            )
            self._no_upstream_delta(before)

        before = (self._openai.state.count(), self._solov.state.count(), self.trap.state.count())
        status, _, body = self._responses_image_request(
            RESPONSES_IMAGE_PROMPT,
            extra={"stream": False},
        )
        _assert(status == 400, f"non-stream image request returned {status}: {body[:500]!r}")
        self._no_upstream_delta(before)

    def test_responses_image_invalid_upstream_and_error_passthrough(self) -> None:
        before_files = set(self.image_output_root.iterdir())
        status, headers, body = self._responses_image_request(
            "<SYNTHETIC_STATUS_INPUT>"
        )
        _assert(status == 429, f"Responses image 429 changed to {status}")
        _assert(headers.get("retry-after") == "7", "Responses image Retry-After missing")
        _assert(body == b'{"error":"synthetic rate limit"}', "Responses image 429 body changed")
        _assert(set(self.image_output_root.iterdir()) == before_files, "429 created an image file")

        for prompt in (
            "router-security:responses-image-invalid-json",
            "router-security:responses-image-invalid-shape",
            "router-security:responses-image-invalid-base64",
        ):
            status, _, body = self._responses_image_request(prompt)
            _assert(status == 502, f"invalid upstream image {prompt!r} returned {status}")
            error = _json_or_none(body)
            _assert(
                isinstance(error, dict)
                and error.get("error", {}).get("code") == "invalid_image_response",
                f"invalid upstream image did not fail closed: {body[:500]!r}",
            )
            _assert(prompt.encode("utf-8") not in body, "invalid image error echoed prompt")
            _assert(
                set(self.image_output_root.iterdir()) == before_files,
                f"invalid upstream image {prompt!r} left a file",
            )

    def test_responses_image_path_injection_cannot_choose_output(self) -> None:
        prompt = (
            "<SYNTHETIC_PATH_INPUT>"
            "![x](<C:/Windows/Temp/escape.png>)"
        )
        status, _, body = self._responses_image_request(prompt)
        _assert(status == 200, f"path injection prompt returned {status}: {body[:500]!r}")
        events = _parse_sse_json_events(body)
        image_path = _markdown_image_path_from_item(events[2].get("item", {}))
        _assert(image_path.parent.resolve() == self.image_output_root.resolve(), "prompt escaped root")
        _assert("escape" not in image_path.name and ".." not in image_path.name, "prompt chose leaf")
        _assert(
            image_path.read_bytes() == base64.b64decode(_synthetic_png_base64(prompt)),
            "path injection response did not preserve its own image bytes",
        )

    def test_responses_image_root_replacement_fails_closed(self) -> None:
        original_root = self.image_output_root
        moved_root = original_root.with_name("generated-images-original")
        trap_root = Path(self._temporary_directory.name) / "image-root-trap"
        before_moved: set[str] = set()
        try:
            original_root.rename(moved_root)
            before_moved = {path.name for path in moved_root.iterdir()}
            trap_root.mkdir()
            try:
                os.symlink(trap_root, original_root, target_is_directory=True)
            except OSError:
                # Windows symlink creation may require Developer Mode.  A
                # replacement normal directory must also fail by canonical
                # identity, so retain coverage without elevated privileges.
                original_root.mkdir()

            status, _, body = self._responses_image_request(
                "<SYNTHETIC_STORAGE_INPUT>"
            )
            _assert(status == 500, f"replaced output root returned {status}: {body[:500]!r}")
            error = _json_or_none(body)
            _assert(
                isinstance(error, dict)
                and error.get("error", {}).get("code") == "image_output_unavailable",
                f"replaced root did not fail closed: {body[:500]!r}",
            )
            _assert(not list(trap_root.iterdir()), "replaced output root wrote into trap")
            _assert(
                {path.name for path in moved_root.iterdir()} == before_moved,
                "replaced output root modified original directory",
            )
        finally:
            if original_root.is_symlink():
                original_root.unlink()
            elif original_root.exists():
                shutil.rmtree(original_root)
            if moved_root.exists():
                moved_root.rename(original_root)
            if trap_root.exists():
                shutil.rmtree(trap_root)

    def test_responses_image_client_cancel_leaves_no_file(self) -> None:
        before = {path.name for path in self.image_output_root.iterdir()}
        payload = json.dumps(
            {
                "model": SOLOV_IMAGE_ALIASES[0],
                "stream": True,
                "input": "<SYNTHETIC_CANCEL_INPUT>",
            },
            separators=(",", ":"),
        ).encode("utf-8")
        connection = http.client.HTTPConnection(LOOPBACK, self.router_port, timeout=3)
        connection.connect()
        assert connection.sock is not None
        request = (
            f"POST /responses HTTP/1.1\r\nHost: {LOOPBACK}:{self.router_port}\r\n"
            "Content-Type: application/json\r\n"
            f"Content-Length: {len(payload)}\r\n"
            f"Authorization: {CHATGPT_TEST_AUTH}\r\nConnection: close\r\n\r\n"
        ).encode("ascii") + payload
        connection.sock.sendall(request)
        connection.sock.shutdown(socket.SHUT_RDWR)
        connection.close()
        time.sleep(1.3)
        _assert(
            {path.name for path in self.image_output_root.iterdir()} == before,
            "cancelled Responses image left a final or temporary file",
        )

    def test_responses_image_file_permissions_are_private(self) -> None:
        prompt = "<SYNTHETIC_STORAGE_INPUT>"
        status, _, body = self._responses_image_request(prompt)
        _assert(status == 200, f"permission image request returned {status}: {body[:500]!r}")
        image_path = _markdown_image_path_from_item(
            _parse_sse_json_events(body)[2].get("item", {})
        )
        if os.name != "nt":
            _assert(image_path.stat().st_mode & 0o777 == 0o600, "image mode is not 0600")
            _assert(self.image_output_root.stat().st_mode & 0o777 == 0o700, "root mode is not 0700")
        _assert(image_path.is_file() and not image_path.is_symlink(), "published image is not private regular file")

    def test_responses_image_concurrency_and_atomic_files(self) -> None:
        prompts = [f"<SYNTHETIC_CONCURRENT_INPUT_{index:02d}>" for index in range(8)]

        def issue(prompt: str) -> tuple[str, int, bytes]:
            status, _, body = self._responses_image_request(prompt)
            return prompt, status, body

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
            results = list(executor.map(issue, prompts))

        response_ids: set[str] = set()
        item_ids: set[str] = set()
        image_paths: set[Path] = set()
        for prompt, status, body in results:
            _assert(status == 200, f"concurrent image request returned {status}: {body[:500]!r}")
            events = _parse_sse_json_events(body)
            _assert(len(events) == 4, "concurrent image response had wrong event count")
            response_id = events[0].get("response", {}).get("id")
            item = events[2].get("item", {})
            image_path = _markdown_image_path_from_item(item)
            _assert(
                image_path.read_bytes() == base64.b64decode(_synthetic_png_base64(prompt)),
                "concurrent response crossed or published partial bytes",
            )
            _assert(isinstance(response_id, str), "concurrent response id missing")
            _assert(isinstance(item.get("id"), str), "concurrent item id missing")
            response_ids.add(response_id)
            item_ids.add(item["id"])
            image_paths.add(image_path)
        _assert(len(response_ids) == len(prompts), "concurrent response IDs collided")
        _assert(len(item_ids) == len(prompts), "concurrent image item IDs collided")
        _assert(len(image_paths) == len(prompts), "concurrent image paths collided")
        _assert(
            not [path for path in self.image_output_root.iterdir() if path.suffix == ".tmp"],
            "concurrent image generation left temporary files",
        )

    def test_responses_image_logs_exclude_prompt_and_base64(self) -> None:
        # Give asynchronous log writes a bounded moment to flush.
        time.sleep(0.1)
        if not self.router_log_path.exists():
            raise HarnessFailure("test launcher did not produce the structured router log")
        log_bytes = self.router_log_path.read_bytes()
        for forbidden in (
            RESPONSES_IMAGE_PROMPT.encode("utf-8"),
            RESPONSES_IMAGE_B64.encode("ascii"),
            SOLOV_TEST_KEY.encode("utf-8"),
            CHATGPT_TEST_AUTH.encode("utf-8"),
            str(self.image_output_root).encode("utf-8"),
            str(self.image_output_root).replace("\\", "/").encode("utf-8"),
        ):
            _assert(forbidden not in log_bytes, "router structured log exposed prompt/base64/credential")
        for raw_line in log_bytes.splitlines():
            try:
                entry = json.loads(raw_line.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise HarnessFailure(f"router log is not JSONL: {raw_line[:200]!r}") from exc
            _assert(
                set(entry).issubset(
                    {"event", "route", "method", "path", "status", "outcome", "duration_ms"}
                ),
                f"router log contains unexpected potentially sensitive fields: {sorted(entry)!r}",
            )

    def test_openai_never_receives_solov_key(self) -> None:
        status, _, _ = _router_request(
            self.router_port,
            {"model": OPENAI_MODEL_ALIAS, "input": "test"},
            headers={
                "Authorization": CHATGPT_TEST_AUTH,
                "ChatGPT-Account-ID": CHATGPT_TEST_ACCOUNT,
                "X-OAI-Attestation": ATTESTATION_TEST_VALUE,
                "Originator": "codex-desktop-test-originator",
                "Session-ID": "<SYNTHETIC_SESSION>",
                "Thread-ID": "<SYNTHETIC_THREAD>",
                "X-Codex-Turn-State": "turn-state-test-not-real",
                "X-OpenAI-Subagent": "subagent-test-not-real",
            },
        )
        _assert(status == 200, f"OpenAI branch returned {status}")
        record = self._openai.state.last()
        _assert(record.headers.get("authorization") == CHATGPT_TEST_AUTH, "ChatGPT auth changed")
        _assert(record.headers.get("chatgpt-account-id") == CHATGPT_TEST_ACCOUNT, "account id missing")
        _assert(
            record.headers.get("x-oai-attestation") == ATTESTATION_TEST_VALUE,
            "OpenAI attestation header was not transparently forwarded",
        )
        for name, expected in {
            "originator": "codex-desktop-test-originator",
            "session-id": "<SYNTHETIC_SESSION>",
            "thread-id": "<SYNTHETIC_THREAD>",
            "x-codex-turn-state": "turn-state-test-not-real",
            "x-openai-subagent": "subagent-test-not-real",
        }.items():
            _assert(record.headers.get(name) == expected, f"OpenAI header {name} was not preserved")
        _assert(SOLOV_TEST_KEY not in _serialized_record(record), "OpenAI request leaked Solov key")
        _assert(
            isinstance(record.json_body, dict)
            and record.json_body.get("model") == OPENAI_UPSTREAM_MODEL,
            "OpenAI model alias was not rewritten to the allowlisted upstream model",
        )

    def test_agent_assertion_passthrough(self) -> None:
        agent_assertion = "AgentAssertion <SYNTHETIC_AGENT_ASSERTION>"
        status, _, _ = _router_request(
            self.router_port,
            {"model": OPENAI_MODEL_ALIAS, "input": "test"},
            headers={
                "Authorization": agent_assertion,
                "ChatGPT-Account-ID": CHATGPT_TEST_ACCOUNT,
                "X-OAI-Attestation": ATTESTATION_TEST_VALUE,
            },
        )
        _assert(status == 200, f"AgentAssertion OpenAI request returned {status}")
        record = self._openai.state.last()
        _assert(
            record.headers.get("authorization") == agent_assertion,
            "AgentAssertion authorization was not transparently forwarded",
        )

    def test_ssrf_overrides_rejected(self) -> None:
        trap_url = f"{self.trap.url}/must-not-be-requested"
        before = (self._openai.state.count(), self._solov.state.count(), self.trap.state.count())
        status, _, _ = _router_request(
            self.router_port,
            {"model": trap_url, "input": "test"},
            headers={"X-Upstream-URL": trap_url, "X-Forwarded-Host": urlsplit(trap_url).netloc},
            path=f"/responses?upstream={trap_url}",
        )
        _assert(status in {400, 404, 422}, f"URL-shaped model returned unsafe status {status}")
        self._no_upstream_delta(before)

        trap_before = self.trap.state.count()
        status, _, _ = _router_request(
            self.router_port,
            {"model": OPENAI_MODEL_ALIAS, "input": trap_url},
            headers={
                "Authorization": CHATGPT_TEST_AUTH,
                "X-Upstream-URL": trap_url,
                "X-Forwarded-Host": urlsplit(trap_url).netloc,
                "Forwarded": f"host={urlsplit(trap_url).netloc}",
                "X-Original-URL": trap_url,
            },
        )
        _assert(status == 200, f"allowlisted OpenAI model returned {status}")
        _assert(self.trap.state.count() == trap_before, "router honored a caller-controlled upstream URL")
        record = self._openai.state.last()
        override_names = {"x-upstream-url", "x-forwarded-host", "forwarded", "x-original-url"}
        leaked = sorted(override_names.intersection(record.headers))
        _assert(not leaked, f"routing override headers reached upstream: {leaked}")

    def test_upstream_redirect_not_followed(self) -> None:
        trap_before = self.trap.state.count()
        status, _, _ = _router_request(
            self.router_port,
            {
                "model": OPENAI_MODEL_ALIAS,
                "input": "test",
                "metadata": {"router_security_test": "redirect"},
            },
            headers={"Authorization": CHATGPT_TEST_AUTH},
        )
        _assert(status in {301, 302, 303, 307, 308, 502}, f"redirect became unsafe status {status}")
        _assert(self.trap.state.count() == trap_before, "router followed an upstream redirect")

    def test_sse_streaming_passthrough(self) -> None:
        body = json.dumps(
            {
                "model": OPENAI_MODEL_ALIAS,
                "input": "test",
                "metadata": {"router_security_test": "sse"},
            },
            separators=(",", ":"),
        ).encode("utf-8")
        connection = http.client.HTTPConnection(LOOPBACK, self.router_port, timeout=5)
        started = time.monotonic()
        try:
            connection.request(
                "POST",
                "/responses",
                body=body,
                headers={
                    "Content-Type": "application/json",
                    "Content-Length": str(len(body)),
                    "Authorization": CHATGPT_TEST_AUTH,
                    "Connection": "close",
                },
            )
            response = connection.getresponse()
            _assert(response.status == 200, f"SSE request returned {response.status}")
            content_type = response.getheader("Content-Type", "")
            _assert("text/event-stream" in content_type.lower(), f"wrong SSE content type {content_type!r}")
            first_line = response.readline()
            first_event_elapsed = time.monotonic() - started
            _assert(b'"event":"first"' in first_line, f"first SSE event changed: {first_line!r}")
            _assert(
                first_event_elapsed < SSE_DELAY_SECONDS * 0.75,
                f"SSE was buffered ({first_event_elapsed:.2f}s to first event)",
            )
            remainder = response.read()
            _assert(b'"event":"second"' in remainder, "second SSE event missing")
            _assert(b"data: [DONE]" in remainder, "SSE completion marker missing")
        finally:
            connection.close()

    def test_client_cancellation_propagates(self) -> None:
        self._openai.state.cancelled.clear()
        body = json.dumps(
            {
                "model": OPENAI_MODEL_ALIAS,
                "input": "test",
                "metadata": {"router_security_test": "cancel"},
            },
            separators=(",", ":"),
        ).encode("utf-8")
        connection = http.client.HTTPConnection(LOOPBACK, self.router_port, timeout=4)
        connection.request(
            "POST",
            "/responses",
            body=body,
            headers={
                "Content-Type": "application/json",
                "Content-Length": str(len(body)),
                "Authorization": CHATGPT_TEST_AUTH,
                "Connection": "close",
            },
        )
        response = connection.getresponse()
        _assert(response.status == 200, f"cancellation probe returned {response.status}")
        _assert(b'"event":"first"' in response.readline(), "cancellation probe did not start streaming")
        if connection.sock is not None:
            try:
                connection.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
        response.close()
        connection.close()
        _assert(
            self._openai.state.cancelled.wait(timeout=4.0),
            "upstream remained open after the client cancelled",
        )

    def test_401_passthrough(self) -> None:
        status, headers, body = _router_request(
            self.router_port,
            {
                "model": OPENAI_MODEL_ALIAS,
                "input": "test",
                "metadata": {"router_security_test": "status-401"},
            },
            headers={"Authorization": CHATGPT_TEST_AUTH},
        )
        _assert(status == 401, f"upstream 401 changed to {status}")
        _assert("bearer" in headers.get("www-authenticate", "").lower(), "WWW-Authenticate missing")
        _assert(b"<SYNTHETIC_UNAUTHORIZED_BODY>" in body, "401 body was not preserved")

    def test_429_passthrough(self) -> None:
        status, headers, body = _router_request(
            self.router_port,
            {
                "model": OPENAI_MODEL_ALIAS,
                "input": "test",
                "metadata": {"router_security_test": "status-429"},
            },
            headers={"Authorization": CHATGPT_TEST_AUTH},
        )
        _assert(status == 429, f"upstream 429 changed to {status}")
        _assert(headers.get("retry-after") == "7", "Retry-After was not preserved")
        _assert(headers.get("x-request-id") == "synthetic-request-429", "request id missing")
        _assert(b"synthetic rate limit" in body, "429 body was not preserved")

    def run(self) -> int:
        tests = [
            ("loopback-only listener", self.test_loopback_only),
            ("unknown path rejected", self.test_unknown_path_rejected),
            ("unknown model rejected", self.test_unknown_model_rejected),
            (
                "official catalog preserved and Solov models appended",
                self.test_models_merge_preserves_official_catalog_and_auth,
            ),
            (
                "catalog-discovered official model POST",
                self.test_dynamic_official_model_posts_after_catalog_refresh,
            ),
            (
                "official catalog error has no Solov fallback",
                self.test_models_official_error_has_no_solov_fallback,
            ),
            ("Solov identity-header isolation", self.test_solov_identity_header_isolation),
            (
                "four Solov image models strip prefix and isolate identity",
                self.test_solov_image_models_prefix_stripping_and_isolation,
            ),
            (
                "image route rejects unknown and official models",
                self.test_solov_image_unknown_and_official_models_rejected,
            ),
            (
                "image route SSRF and redirect resistance",
                self.test_solov_image_ssrf_and_redirect_resistance,
            ),
            (
                "image response and error pass-through",
                self.test_solov_image_response_passthrough,
            ),
            (
                "Responses image text prompt, isolation, and SSE contract",
                self.test_responses_image_text_prompt_and_sse_contract,
            ),
            (
                "Responses image extracts only latest user input_text",
                self.test_responses_image_latest_user_input_text_only,
            ),
            (
                "Responses image rejects ambiguous and multimodal prompts",
                self.test_responses_image_rejects_ambiguous_or_multimodal_prompt,
            ),
            (
                "Responses image invalid-upstream and status semantics",
                self.test_responses_image_invalid_upstream_and_error_passthrough,
            ),
            (
                "Responses image prompt cannot choose an output path",
                self.test_responses_image_path_injection_cannot_choose_output,
            ),
            (
                "Responses image output-root replacement fails closed",
                self.test_responses_image_root_replacement_fails_closed,
            ),
            (
                "Responses image cancellation leaves no file",
                self.test_responses_image_client_cancel_leaves_no_file,
            ),
            (
                "Responses image files remain private regular files",
                self.test_responses_image_file_permissions_are_private,
            ),
            (
                "Responses image concurrency publishes unique atomic files",
                self.test_responses_image_concurrency_and_atomic_files,
            ),
            (
                "Responses image logs exclude prompt, base64, and credentials",
                self.test_responses_image_logs_exclude_prompt_and_base64,
            ),
            ("OpenAI never receives Solov key", self.test_openai_never_receives_solov_key),
            ("AgentAssertion pass-through", self.test_agent_assertion_passthrough),
            ("SSRF override resistance", self.test_ssrf_overrides_rejected),
            ("upstream redirect not followed", self.test_upstream_redirect_not_followed),
            ("SSE streaming pass-through", self.test_sse_streaming_passthrough),
            ("client cancellation propagation", self.test_client_cancellation_propagates),
            ("401 pass-through", self.test_401_passthrough),
            ("429 pass-through", self.test_429_passthrough),
        ]
        for name, test in tests:
            try:
                test()
            except Exception as exc:  # Keep running to produce a complete audit report.
                self.results.append((name, False, str(exc)))
                print(f"[FAIL] {name}: {exc}", flush=True)
            else:
                self.results.append((name, True, ""))
                print(f"[PASS] {name}", flush=True)

        passed = sum(1 for _, ok, _ in self.results if ok)
        failed = len(self.results) - passed
        print(f"\nSummary: {passed} passed, {failed} failed", flush=True)
        return 0 if failed == 0 else 1


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--self-test-router",
        action="store_true",
        help="run against the bundled test-only router fixture (the default when no command is given)",
    )
    parser.add_argument(
        "--router-cwd",
        default=str(Path.cwd()),
        help="working directory for the router process",
    )
    parser.add_argument(
        "--router-command",
        nargs=argparse.REMAINDER,
        help=(
            "router command and arguments; receives synthetic test settings through environment "
            "variables and may use {host}, {port}, {openai_upstream}, {solov_upstream}, "
            "{solov_key}, {openai_model}, and {solov_model} placeholders"
        ),
    )
    return parser


def main() -> int:
    args = _build_parser().parse_args()
    harness = RouterSecurityHarness(args)
    try:
        harness.start()
        return harness.run()
    except Exception as exc:
        print(f"[HARNESS ERROR] {exc}", file=sys.stderr)
        return 2
    finally:
        harness.stop()


if __name__ == "__main__":
    raise SystemExit(main())
