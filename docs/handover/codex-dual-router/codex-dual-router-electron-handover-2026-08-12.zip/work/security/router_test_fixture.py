#!/usr/bin/env python3
"""Test-only reference router used to validate the black-box harness.

This file is intentionally small and only accepts synthetic settings injected
by router_security_harness.py.  It is not a production router.
"""

from __future__ import annotations

import http.client
import json
import os
import select
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlsplit


HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
}
ROUTING_OVERRIDE_HEADERS = {
    "forwarded",
    "x-forwarded-host",
    "x-forwarded-proto",
    "x-host",
    "x-original-url",
    "x-rewrite-url",
    "x-upstream-url",
}
SOLOV_SAFE_REQUEST_HEADERS = {"accept", "accept-language", "user-agent"}
_OFFICIAL_MODELS_LOCK = threading.Lock()
_DYNAMIC_OFFICIAL_MODELS: set[str] = set()


def _aliases(name: str) -> dict[str, str]:
    mappings: dict[str, str] = {}
    for item in os.environ.get(name, "").split(","):
        item = item.strip()
        if not item:
            continue
        alias, separator, upstream = item.partition("=")
        if not separator or not alias or not upstream:
            raise RuntimeError(f"invalid {name} entry: {item!r}")
        mappings[alias] = upstream
    return mappings


def _solov_catalog() -> dict[str, Any]:
    try:
        payload = json.loads(os.environ["ROUTER_TEST_SOLOV_CATALOG_JSON"])
    except (KeyError, json.JSONDecodeError) as exc:
        raise RuntimeError("invalid synthetic Solov catalog") from exc
    if not isinstance(payload, dict) or not isinstance(payload.get("models"), list):
        raise RuntimeError("invalid synthetic Solov catalog schema")
    return payload


def _official_model_is_dynamic(model: str) -> bool:
    with _OFFICIAL_MODELS_LOCK:
        return model in _DYNAMIC_OFFICIAL_MODELS


def _replace_dynamic_official_models(models: list[Any]) -> None:
    slugs = {
        model["slug"]
        for model in models
        if isinstance(model, dict)
        and isinstance(model.get("slug"), str)
        and not model["slug"].startswith("solov::")
    }
    with _OFFICIAL_MODELS_LOCK:
        _DYNAMIC_OFFICIAL_MODELS.clear()
        _DYNAMIC_OFFICIAL_MODELS.update(slugs)


def _read_body(handler: BaseHTTPRequestHandler) -> bytes:
    length = int(handler.headers.get("Content-Length", "0") or "0")
    return handler.rfile.read(length) if length else b""


class RouterHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, _format: str, *_args: object) -> None:
        return

    def _bytes_response(
        self,
        status: int,
        body: bytes,
        headers: list[tuple[str, str]] | None = None,
    ) -> None:
        self.send_response(status)
        for name, value in headers or []:
            lowered = name.lower()
            if lowered in HOP_BY_HOP_HEADERS | {"content-length", "connection", "server", "date"}:
                continue
            self.send_header(name, value)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
        self.close_connection = True

    def _json_error(self, status: int, message: str) -> None:
        body = json.dumps({"error": message}, separators=(",", ":")).encode("utf-8")
        self._bytes_response(status, body, [("Content-Type", "application/json")])

    def do_GET(self) -> None:
        if self.path == "/health":
            body = b'{"ok":true}'
            self._bytes_response(200, body, [("Content-Type", "application/json")])
            return

        parsed_request = urlsplit(self.path)
        if parsed_request.path != "/models":
            self._json_error(404, "route not found")
            return
        if not self.headers.get("Authorization", "").startswith(("Bearer ", "AgentAssertion ")):
            self._json_error(401, "OpenAI authentication is required")
            return

        self._relay_models(parsed_request.query)

    def _relay_models(self, raw_query: str) -> None:
        parsed = urlsplit(os.environ["OPENAI_UPSTREAM_BASE_URL"])
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            self._json_error(502, "invalid configured upstream")
            return
        connection_class = (
            http.client.HTTPSConnection if parsed.scheme == "https" else http.client.HTTPConnection
        )
        connection = connection_class(parsed.hostname, parsed.port, timeout=10)
        base_path = parsed.path.rstrip("/")
        upstream_path = f"{base_path}/models" if base_path else "/models"
        if raw_query:
            upstream_path = f"{upstream_path}?{raw_query}"
        headers: dict[str, str] = {}
        for name, value in self.headers.items():
            lowered = name.lower()
            if lowered in HOP_BY_HOP_HEADERS | ROUTING_OVERRIDE_HEADERS | {"host", "content-length"}:
                continue
            headers[name] = value
        try:
            connection.request("GET", upstream_path, headers=headers)
            response = connection.getresponse()
            response_body = response.read()
            response_headers = response.getheaders()
            if response.status != 200:
                self._bytes_response(response.status, response_body, response_headers)
                return
            try:
                payload = json.loads(response_body.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                self._json_error(502, "invalid official catalog")
                return
            if not isinstance(payload, dict) or not isinstance(payload.get("models"), list):
                self._json_error(502, "invalid official catalog")
                return
            official_models = payload["models"]
            if any(
                not isinstance(model, dict) or not isinstance(model.get("slug"), str)
                for model in official_models
            ):
                self._json_error(502, "invalid official catalog")
                return
            _replace_dynamic_official_models(official_models)
            payload["models"] = [*official_models, *_solov_catalog()["models"]]
            merged = json.dumps(payload, separators=(",", ":")).encode("utf-8")
            self._bytes_response(200, merged, response_headers)
        except (OSError, http.client.HTTPException):
            self._json_error(502, "upstream failure")
        finally:
            connection.close()

    def do_POST(self) -> None:
        parsed_request = urlsplit(self.path)
        if parsed_request.query or parsed_request.path not in {
            "/responses",
            "/images/generations",
        }:
            self._json_error(404, "route not found")
            return
        body = _read_body(self)
        try:
            payload = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._json_error(400, "invalid JSON")
            return
        if not isinstance(payload, dict) or not isinstance(payload.get("model"), str):
            self._json_error(400, "model is required")
            return

        model = payload["model"]
        openai_aliases = _aliases("OPENAI_MODEL_ALIASES")
        solov_aliases = _aliases("SOLOV_MODEL_ALIASES")
        solov_image_aliases = _aliases("SOLOV_IMAGE_MODEL_ALIASES")
        if parsed_request.path == "/images/generations":
            if model not in solov_image_aliases:
                self._json_error(400, "model is not allowlisted for image generation")
                return
            branch = "solov"
            upstream_base = os.environ["SOLOV_UPSTREAM_BASE_URL"]
            payload["model"] = solov_image_aliases[model]
        else:
            if model in openai_aliases or _official_model_is_dynamic(model):
                branch = "openai"
                upstream_base = os.environ["OPENAI_UPSTREAM_BASE_URL"]
                payload["model"] = openai_aliases.get(model, model)
            elif model in solov_aliases:
                branch = "solov"
                upstream_base = os.environ["SOLOV_UPSTREAM_BASE_URL"]
                payload["model"] = solov_aliases[model]
            else:
                self._json_error(400, "model is not allowlisted")
                return

        outgoing_body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        outgoing_headers = self._outgoing_headers(branch, len(outgoing_body))
        self._relay(
            upstream_base,
            parsed_request.path,
            outgoing_headers,
            outgoing_body,
        )

    def _outgoing_headers(self, branch: str, body_length: int) -> dict[str, str]:
        headers: dict[str, str] = {}
        for name, value in self.headers.items():
            lowered = name.lower()
            if lowered in HOP_BY_HOP_HEADERS | ROUTING_OVERRIDE_HEADERS | {"host", "content-length"}:
                continue
            if branch == "solov" and lowered not in SOLOV_SAFE_REQUEST_HEADERS:
                continue
            headers[name] = value
        if branch == "solov":
            headers["Authorization"] = f"Bearer {os.environ['SOLOV_API_KEY']}"
        headers["Content-Type"] = "application/json"
        headers["Content-Length"] = str(body_length)
        return headers

    def _relay(
        self,
        upstream_base: str,
        route_path: str,
        headers: dict[str, str],
        body: bytes,
    ) -> None:
        parsed = urlsplit(upstream_base)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            self._json_error(502, "invalid configured upstream")
            return
        connection_class = (
            http.client.HTTPSConnection if parsed.scheme == "https" else http.client.HTTPConnection
        )
        connection = connection_class(parsed.hostname, parsed.port, timeout=10)
        base_path = parsed.path.rstrip("/")
        upstream_path = f"{base_path}{route_path}" if base_path else route_path
        try:
            connection.request("POST", upstream_path, body=body, headers=headers)
            response = connection.getresponse()
            self.send_response(response.status)
            for name, value in response.getheaders():
                lowered = name.lower()
                if lowered in HOP_BY_HOP_HEADERS | {"content-length", "connection", "server", "date"}:
                    continue
                self.send_header(name, value)
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            while True:
                chunk = response.read1(4096)
                if not chunk:
                    break
                readable, _, exceptional = select.select(
                    [self.connection], [], [self.connection], 0
                )
                if exceptional:
                    if connection.sock is not None:
                        connection.sock.shutdown(socket.SHUT_RDWR)
                    break
                if readable:
                    try:
                        if self.connection.recv(1, socket.MSG_PEEK) == b"":
                            if connection.sock is not None:
                                connection.sock.shutdown(socket.SHUT_RDWR)
                            break
                    except (ConnectionResetError, OSError):
                        if connection.sock is not None:
                            try:
                                connection.sock.shutdown(socket.SHUT_RDWR)
                            except OSError:
                                pass
                        break
                try:
                    self.wfile.write(chunk)
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError, OSError):
                    break
        except (OSError, http.client.HTTPException):
            if not self.wfile.closed:
                try:
                    self._json_error(502, "upstream failure")
                except (BrokenPipeError, ConnectionResetError, OSError):
                    pass
        finally:
            connection.close()


def main() -> int:
    host = os.environ.get("ROUTER_HOST", "127.0.0.1")
    port = int(os.environ["ROUTER_PORT"])
    server = ThreadingHTTPServer((host, port), RouterHandler)
    server.daemon_threads = True
    try:
        server.serve_forever()
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
