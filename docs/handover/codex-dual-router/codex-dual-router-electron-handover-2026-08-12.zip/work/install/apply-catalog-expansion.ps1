[CmdletBinding()]
param(
    [string]$WorkspaceRoot = 'C:\Users\<USER>\Documents\Codex\2026-08-12\chatgpt-api',
    [string]$InstallRoot = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter',
    [string]$ConfigPath = 'C:\Users\<USER>\.codex\config.toml',
    [string]$BackupRoot = 'C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter\backups\20260812-065034-model-catalog-expansion',
    [int]$Port = 43120
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Assert-File {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Required file not found: $Path"
    }
}

$resolvedWorkspace = (Resolve-Path -LiteralPath $WorkspaceRoot).Path
$resolvedInstall = (Resolve-Path -LiteralPath $InstallRoot).Path
$resolvedBackup = (Resolve-Path -LiteralPath $BackupRoot).Path
$expectedInstall = [IO.Path]::GetFullPath('C:\Users\<USER>\AppData\Local\OpenAI\CodexDualRouter')
if (-not $resolvedInstall.Equals($expectedInstall, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Unexpected installation target: $resolvedInstall"
}

$sourceRouter = Join-Path $resolvedWorkspace 'work\router'
$sourceCatalog = Join-Path $resolvedWorkspace 'work\catalog\model-catalog.json'
$sourceManifest = Join-Path $resolvedWorkspace 'work\catalog\solov-model-manifest.json'
$sourceLiveValidator = Join-Path $resolvedWorkspace 'work\install\validate-live-picker.ps1'
$sourceStandbyValidator = Join-Path $resolvedWorkspace 'work\install\validate-standby.ps1'
$sourceResponseValidator = Join-Path $resolvedWorkspace 'work\install\validate-live-responses.ps1'
$stopScript = Join-Path $resolvedInstall 'stop-router.ps1'
$startScript = Join-Path $resolvedInstall 'start-router.ps1'
$installedCatalog = Join-Path $resolvedInstall 'models.json'

$copyMap = [ordered]@{
    (Join-Path $sourceRouter 'package.json') = (Join-Path $resolvedInstall 'router\package.json')
    (Join-Path $sourceRouter 'README.md') = (Join-Path $resolvedInstall 'router\README.md')
    (Join-Path $sourceRouter 'src\config.mjs') = (Join-Path $resolvedInstall 'router\src\config.mjs')
    (Join-Path $sourceRouter 'src\main.mjs') = (Join-Path $resolvedInstall 'router\src\main.mjs')
    (Join-Path $sourceRouter 'src\router.mjs') = (Join-Path $resolvedInstall 'router\src\router.mjs')
    (Join-Path $sourceRouter 'test\router.test.mjs') = (Join-Path $resolvedInstall 'router\test\router.test.mjs')
    $sourceCatalog = $installedCatalog
    $sourceManifest = (Join-Path $resolvedInstall 'solov-model-manifest.json')
    $sourceLiveValidator = (Join-Path $resolvedInstall 'validate-live-picker.ps1')
    $sourceStandbyValidator = (Join-Path $resolvedInstall 'validate-standby.ps1')
    $sourceResponseValidator = (Join-Path $resolvedInstall 'validate-live-responses.ps1')
}

foreach ($path in @($ConfigPath, $stopScript, $startScript, (Join-Path $resolvedBackup 'config.toml'), (Join-Path $resolvedBackup 'models.json'))) {
    Assert-File $path
}
foreach ($source in $copyMap.Keys) {
    Assert-File $source
}

$configText = [IO.File]::ReadAllText($ConfigPath)
if ($configText -match '(?m)^\s*model_catalog_json\s*=') {
    throw 'The live config still contains model_catalog_json; refusing to activate the dynamic merge.'
}
if ($configText -notmatch '(?m)^\s*model_provider\s*=\s*"openai"\s*$') {
    throw 'The live config must keep model_provider = "openai".'
}

$activated = $false
try {
    & $stopScript -InstallRoot $resolvedInstall
    foreach ($entry in $copyMap.GetEnumerator()) {
        Copy-Item -LiteralPath $entry.Key -Destination $entry.Value -Force
    }

    foreach ($entry in $copyMap.GetEnumerator()) {
        $sourceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $entry.Key).Hash
        $targetHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $entry.Value).Hash
        if ($sourceHash -cne $targetHash) {
            throw "Installed file hash mismatch: $($entry.Value)"
        }
    }

    & $startScript -InstallRoot $resolvedInstall -Port $Port
    $validation = & $sourceLiveValidator `
        -InstallRoot $resolvedInstall `
        -Port $Port `
        -MinimumOfficialModels 2 `
        -MinimumSolovModels 7
    $activated = $true

    [pscustomobject]@{
        Activated = $true
        Router = "127.0.0.1:$Port"
        OfficialModels = $validation.OfficialModels
        SolovModels = $validation.SolovModels
        Official = $validation.Official
        Solov = $validation.Solov
        CatalogSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $installedCatalog).Hash
        ConfigSha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $ConfigPath).Hash
    }
}
catch {
    $activationError = $_
    try {
        & $stopScript -InstallRoot $resolvedInstall -ErrorAction SilentlyContinue
        Copy-Item -LiteralPath (Join-Path $resolvedBackup 'config.toml') -Destination $ConfigPath -Force
        Copy-Item -LiteralPath (Join-Path $resolvedBackup 'models.json') -Destination $installedCatalog -Force
        foreach ($relativePath in @('package.json', 'README.md', 'src\config.mjs', 'src\main.mjs', 'src\router.mjs', 'test\router.test.mjs')) {
            Copy-Item `
                -LiteralPath (Join-Path $resolvedBackup ('router\' + $relativePath)) `
                -Destination (Join-Path $resolvedInstall ('router\' + $relativePath)) `
                -Force
        }
        & $startScript -InstallRoot $resolvedInstall -Port $Port
    }
    catch {
        throw "Activation failed and automatic rollback also failed. Activation: $($activationError.Exception.Message) Rollback: $($_.Exception.Message)"
    }
    throw "Activation failed; the previous router, catalog, and config were restored. $($activationError.Exception.Message)"
}
finally {
    if (-not $activated) {
        # The catch block owns rollback. This flag exists only to make the
        # successful terminal state explicit in review and test output.
    }
}
